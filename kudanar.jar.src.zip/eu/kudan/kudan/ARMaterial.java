/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ public class ARMaterial {
/*    */   private boolean mIsTransparent;
/*    */   private boolean mDepthOnly;
/*    */   private boolean mDepthWrite;
/*    */   private boolean mDepthTest;
/*    */   
/*    */   public ARMaterial() {
/* 12 */     this.mDepthWrite = true;
/* 13 */     this.mDepthTest = true;
/*    */   }
/*    */   
/*    */   public boolean getTransparent() {
/* 17 */     return this.mIsTransparent;
/*    */   }
/*    */   
/*    */   public void setTransparent(boolean transparent) {
/* 21 */     this.mIsTransparent = transparent;
/*    */   }
/*    */   
/*    */   public boolean getDepthOnly() {
/* 25 */     return this.mDepthOnly;
/*    */   }
/*    */   
/*    */   public void setDepthOnly(boolean depthOnly) {
/* 29 */     this.mDepthOnly = depthOnly;
/*    */   }
/*    */   
/*    */   public void setDepthWrite(boolean depthWrite) {
/* 33 */     this.mDepthWrite = depthWrite;
/*    */   }
/*    */   
/*    */   public boolean getDepthWrite() {
/* 37 */     return this.mDepthWrite;
/*    */   }
/*    */   
/*    */   public void setDepthTest(boolean depthTest) {
/* 41 */     this.mDepthTest = depthTest;
/*    */   }
/*    */   
/*    */   public boolean getDepthTest() {
/* 45 */     return this.mDepthTest;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node) {
/* 49 */     if (this.mIsTransparent) {
/* 50 */       GLES20.glEnable(3042);
/*    */       
/* 52 */       GLES20.glBlendFunc(770, 771);
/*    */     } else {
/* 54 */       GLES20.glDisable(3042);
/*    */     }
/* 56 */     if (this.mDepthOnly) {
/* 57 */       GLES20.glColorMask(false, false, false, false);
/*    */     } else {
/* 59 */       GLES20.glColorMask(true, true, true, true);
/*    */     }
/*    */     
/* 62 */     GLES20.glDepthMask(this.mDepthWrite);
/*    */     
/*    */ 
/*    */ 
/* 66 */     if (this.mDepthTest) {
/* 67 */       GLES20.glEnable(2929);
/*    */     } else {
/* 69 */       GLES20.glDisable(2929);
/*    */     }
/*    */     
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */