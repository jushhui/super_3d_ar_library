/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARBlendAnimationChannel {
/*    */   private int mNativeMem;
/*    */   private ARBlendShapeChannel mShapeChannel;
/*    */   
/*    */   public ARBlendAnimationChannel(ARBlendShapeChannel channel, int nativeMem) {
/*  8 */     this.mNativeMem = nativeMem;
/*  9 */     this.mShapeChannel = channel;
/*    */   }
/*    */   
/*    */   private native float getInfluenceN(int paramInt);
/*    */   
/* 14 */   public void update(int frameNo) { float influence = getInfluenceN(frameNo);
/*    */     
/* 16 */     this.mShapeChannel.setInfluence(influence);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARBlendAnimationChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */