/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class ARShaderManager
/*    */ {
/*    */   private static ARShaderManager shaderManager;
/*    */   
/*    */   public static ARShaderManager getInstance()
/*    */   {
/* 11 */     if (shaderManager == null) {
/* 12 */       shaderManager = new ARShaderManager();
/*    */     }
/* 14 */     return shaderManager;
/*    */   }
/*    */   
/*    */   public class ShaderProperties
/*    */   {
/*    */     private ARShaderProgram mShader;
/*    */     private boolean[] mProperties;
/*    */     
/*    */     public ShaderProperties(ARShaderProgram shader, boolean[] properties) {
/* 23 */       this.mShader = shader;
/* 24 */       this.mProperties = properties;
/*    */     }
/*    */     
/*    */     public ARShaderProgram getShader() {
/* 28 */       return this.mShader;
/*    */     }
/*    */     
/* 31 */     public boolean[] getProperties() { return this.mProperties; }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 36 */   private java.util.List<ShaderProperties> mShaders = new ArrayList();
/*    */   
/*    */ 
/*    */   public ARShaderProgram findShader(Class<?> type, boolean[] properties)
/*    */   {
/* 41 */     for (ShaderProperties shader : this.mShaders) {
/* 42 */       if (shader.getShader().getClass().equals(type)) {
/* 43 */         boolean found = true;
/* 44 */         for (int i = 0; i < properties.length; i++) {
/* 45 */           if (shader.getProperties()[i] != properties[i]) {
/* 46 */             found = false;
/* 47 */             break;
/*    */           }
/*    */         }
/* 50 */         if (found) {
/* 51 */           return shader.getShader();
/*    */         }
/*    */       }
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */   
/*    */   public void addShader(ARShaderProgram shader, boolean[] properties) {
/* 59 */     this.mShaders.add(new ShaderProperties(shader, properties));
/*    */   }
/*    */   
/*    */   public void reset() {
/* 63 */     this.mShaders = new ArrayList();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARShaderManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */