/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARVideoNode extends ARMeshNode
/*    */ {
/*    */   private ARVideoTexture mVideoTexture;
/*    */   
/*    */   public ARVideoTexture getVideoTexture()
/*    */   {
/*  9 */     return this.mVideoTexture;
/*    */   }
/*    */   
/*    */   public void setVideoTexture(ARVideoTexture videoTexture) {
/* 13 */     this.mVideoTexture = videoTexture;
/*    */   }
/*    */   
/*    */ 
/*    */   public ARVideoNode(ARVideoTexture videoTexture)
/*    */   {
/* 19 */     this.mVideoTexture = videoTexture;
/*    */     
/* 21 */     ARMesh mesh = new ARMesh();
/* 22 */     mesh.createTestMeshWithUvs(videoTexture.getWidth(), videoTexture.getHeight(), 0.0F, 1.0F, 0.0F, 1.0F);
/*    */     
/* 24 */     setMesh(mesh);
/*    */     
/* 26 */     ARVideoTextureMaterial material = new ARVideoTextureMaterial(videoTexture);
/* 27 */     setMaterial(material);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARVideoNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */