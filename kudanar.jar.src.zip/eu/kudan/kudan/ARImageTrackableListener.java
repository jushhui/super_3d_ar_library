package eu.kudan.kudan;

public abstract interface ARImageTrackableListener
{
  public abstract void didDetect(ARImageTrackable paramARImageTrackable);
  
  public abstract void didTrack(ARImageTrackable paramARImageTrackable);
  
  public abstract void didLose(ARImageTrackable paramARImageTrackable);
}


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARImageTrackableListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */