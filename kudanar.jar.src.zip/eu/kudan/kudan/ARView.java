/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.res.Configuration;
/*     */ import android.graphics.SurfaceTexture;
/*     */ import android.media.MediaPlayer;
/*     */ import android.opengl.GLSurfaceView;
/*     */ import android.util.AttributeSet;
/*     */ import android.util.Log;
/*     */ import android.view.OrientationEventListener;
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Quaternion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARView
/*     */   extends GLSurfaceView
/*     */ {
/*     */   private final OrientationEventListener mOrientationEventListener;
/*     */   private final ARSurfaceRenderer mRenderer;
/*     */   private ARViewPort mCameraViewPort;
/*     */   private ARViewPort mContentViewPort;
/*     */   private ARRenderTarget mRenderTarget;
/*     */   private ARCameraTextureMaterial mCamTextureMaterial;
/*     */   private ARMeshNode mCameraMeshNode;
/*     */   private ARMesh mCameraMesh;
/*     */   private SurfaceTexture mCameraSurfaceTexture;
/*     */   private ARTextureOES mCameraTexture;
/*     */   private MediaPlayer mMediaPlayer;
/*     */   private ARNode mTrackedNode;
/*     */   private ARActivity mActivity;
/*  41 */   boolean onLoad = true;
/*  42 */   boolean resetCameraMesh = false;
/*     */   
/*     */   public void setupNewCamera()
/*     */   {
/*  46 */     ARCameraStream cameraStream = ARCameraStream.getInstance();
/*  47 */     cameraStream.mArView = this;
/*     */     
/*     */ 
/*  50 */     this.mCameraMeshNode = new ARMeshNode();
/*  51 */     this.mCameraMesh = new ARMesh();
/*     */     
/*  53 */     this.mCameraMeshNode.setMesh(this.mCameraMesh);
/*     */     
/*  55 */     this.mCamTextureMaterial = new ARCameraTextureMaterial(this.mCameraTexture);
/*  56 */     this.mCamTextureMaterial.setDepthWrite(false);
/*  57 */     this.mCameraMeshNode.setMaterial(this.mCamTextureMaterial);
/*     */     
/*  59 */     cameraStream.setMaterial(this.mCamTextureMaterial);
/*  60 */     cameraStream.setTexture(this.mCameraTexture);
/*     */     
/*  62 */     this.mRenderTarget = new ARRenderTarget();
/*     */     
/*  64 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/*  66 */     this.mCameraViewPort = new ARViewPort();
/*  67 */     this.mRenderTarget.addViewPort(this.mCameraViewPort);
/*     */     
/*  69 */     this.mCameraViewPort.getCamera().addChild(this.mCameraMeshNode);
/*  70 */     this.mCameraViewPort.setZOrder(-100);
/*     */     
/*     */ 
/*     */ 
/*  74 */     this.mContentViewPort = new ARViewPort();
/*     */     
/*  76 */     this.mRenderTarget.addViewPort(this.mContentViewPort);
/*     */     
/*  78 */     ARImageTracker tracker = ARImageTracker.getInstance();
/*  79 */     tracker.initialise();
/*     */     
/*  81 */     this.mContentViewPort.getCamera().addChild(tracker.getBaseNode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setup()
/*     */   {
/*  96 */     this.mActivity.setup();
/*     */   }
/*     */   
/*     */   void setupViewports(boolean rebuildMesh)
/*     */   {
/* 101 */     int screenOrientation = this.mActivity.getRotation();
/*     */     
/*     */ 
/* 104 */     ARCameraStream cameraStream = ARCameraStream.getInstance();
/*     */     
/* 106 */     float halfWidth = getWidth() / 2;
/* 107 */     float halfHeight = getHeight() / 2;
/*     */     
/* 109 */     Matrix4f projection = new Matrix4f(-halfWidth, halfWidth, -halfHeight, halfHeight, 1.0F, -1.0F);
/*     */     
/* 111 */     this.mCameraViewPort.getCamera().setProjectionMatrix(projection);
/*     */     
/* 113 */     float screenAspect = getWidth() / getHeight();
/* 114 */     float cameraAspect = cameraStream.getWidth() / cameraStream.getHeight();
/*     */     
/* 116 */     Log.i("KudanAR", "screen: " + getWidth() + "x" + getHeight());
/*     */     
/* 118 */     this.mCameraViewPort.setViewportParms(0, 0, getWidth(), getHeight());
/*     */     
/*     */     float uv;
/*     */     
/* 122 */     if (screenAspect > cameraAspect)
/*     */     {
/* 124 */       cameraStream.rotateCameraPreview(0);
/*     */       
/*     */ 
/* 127 */       float camHeight = cameraStream.getWidth() / screenAspect;
/*     */       
/*     */ 
/* 130 */       uv = camHeight / cameraStream.getHeight();
/*     */     }
/*     */     else
/*     */     {
/* 134 */       cameraStream.rotateCameraPreview(90);
/*     */       
/*     */ 
/* 137 */       float camWidth = cameraStream.getWidth() * screenAspect;
/*     */       
/*     */ 
/* 140 */       uv = camWidth / cameraStream.getHeight();
/*     */     }
/*     */     
/* 143 */     float uv = 1.0F - uv;
/* 144 */     uv /= 2.0F;
/*     */     
/* 146 */     if (screenOrientation == 3) {
/* 147 */       this.mCameraMesh.createTestMeshWithUvs(2.0F, 2.0F, 1.0F, 0.0F, 1.0F - uv, uv, false, rebuildMesh);
/* 148 */     } else if (screenOrientation == 1) {
/* 149 */       this.mCameraMesh.createTestMeshWithUvs(2.0F, 2.0F, 0.0F, 1.0F, uv, 1.0F - uv, false, rebuildMesh);
/* 150 */     } else if (screenOrientation == 2) {
/* 151 */       this.mCameraMesh.createTestMeshWithUvs(2.0F, 2.0F, 1.0F - uv, uv, 1.0F, 0.0F, false, rebuildMesh);
/*     */     } else {
/* 153 */       this.mCameraMesh.createTestMeshWithUvs(2.0F, 2.0F, uv, 1.0F - uv, 0.0F, 1.0F, false, rebuildMesh);
/*     */     }
/*     */     
/*     */ 
/* 157 */     float width = getWidth();
/* 158 */     float height = getHeight();
/*     */     
/* 160 */     float cameraHeight = width / cameraAspect;
/* 161 */     float offsetY = (cameraHeight - getHeight()) / 2.0F;
/* 162 */     float offsetX = (height / cameraAspect - getWidth()) / 2.0F;
/*     */     
/*     */     Matrix4f projectionMatrix;
/*     */     Matrix4f projectionMatrix;
/* 166 */     if (screenOrientation == 1) {
/* 167 */       this.mContentViewPort.setViewportParms(0, (int)-offsetY, (int)width, (int)cameraHeight);
/* 168 */       projectionMatrix = new Matrix4f(546.0F, 546.0F, 320.0F, 240.0F);
/* 169 */     } else if (screenOrientation == 3) {
/* 170 */       this.mContentViewPort.setViewportParms(0, (int)-offsetY, (int)width, (int)cameraHeight);
/* 171 */       Matrix4f projectionMatrix = new Matrix4f(546.0F, 546.0F, 320.0F, 240.0F);
/*     */       
/* 173 */       projectionMatrix.multLocal(new Quaternion(new float[] { 0.0F, 0.0F, 3.1415F }));
/* 174 */     } else if (screenOrientation == 2) {
/* 175 */       this.mContentViewPort.setViewportParms((int)-offsetX, 0, (int)(height / cameraAspect), (int)height);
/*     */       
/* 177 */       Matrix4f projectionMatrix = new Matrix4f(546.0F, 546.0F, 320.0F, 240.0F, true);
/*     */       
/* 179 */       projectionMatrix.multLocal(new Quaternion(new float[] { 0.0F, 0.0F, 1.5708F }));
/*     */     } else {
/* 181 */       this.mContentViewPort.setViewportParms((int)-offsetX, 0, (int)(height / cameraAspect), (int)height);
/*     */       
/* 183 */       projectionMatrix = new Matrix4f(546.0F, 546.0F, 320.0F, 240.0F, true);
/*     */       
/* 185 */       projectionMatrix.multLocal(new Quaternion(new float[] { 0.0F, 0.0F, -1.5708F }));
/*     */     }
/*     */     
/* 188 */     this.mContentViewPort.getCamera().setProjectionMatrix(projectionMatrix);
/*     */   }
/*     */   
/*     */   void preRender()
/*     */   {
/* 193 */     if (this.resetCameraMesh)
/*     */     {
/* 195 */       setupViewports(true);
/*     */       
/* 197 */       this.resetCameraMesh = false;
/*     */     }
/*     */     
/* 200 */     this.mCameraSurfaceTexture.updateTexImage();
/*     */     
/* 202 */     float[] m = new float[16];
/* 203 */     this.mCameraSurfaceTexture.getTransformMatrix(m);
/*     */     
/* 205 */     this.mCamTextureMaterial.setUVTransform(m);
/*     */     
/* 207 */     ARCameraStream stream = ARCameraStream.getInstance();
/* 208 */     stream.setCameraTransform(m);
/*     */   }
/*     */   
/*     */   public ARView(Context context)
/*     */   {
/* 213 */     super(context);
/*     */     
/* 215 */     this.mRenderer = new ARSurfaceRenderer(this);
/* 216 */     this.mActivity = ((ARActivity)context);
/*     */     
/*     */ 
/* 219 */     this.mOrientationEventListener = new OrientationEventListener(this.mActivity, 
/* 220 */       3)
/*     */       {
/*     */         int mLastRotation;
/*     */         
/*     */ 
/*     */ 
/*     */         public void onOrientationChanged(int orientation)
/*     */         {
/* 227 */           int rotation = ARView.this.mActivity.getRotation();
/* 228 */           if (rotation != this.mLastRotation) {
/* 229 */             Log.i("KudanAR", "Orientation changed >>> " + rotation);
/*     */             
/* 231 */             ARView.this.resetCameraMesh = true;
/*     */             
/* 233 */             this.mLastRotation = rotation;
/*     */           }
/*     */           
/*     */         }
/* 237 */       };
/* 238 */       onConstuction(context);
/*     */     }
/*     */     
/*     */     public ARView(Context context, AttributeSet attrs)
/*     */     {
/* 243 */       super(context, attrs);
/*     */       
/* 245 */       this.mRenderer = new ARSurfaceRenderer(this);
/* 246 */       this.mActivity = ((ARActivity)context);
/*     */       
/*     */ 
/* 249 */       this.mOrientationEventListener = new OrientationEventListener(this.mActivity, 
/* 250 */         3)
/*     */         {
/*     */           int mLastRotation;
/*     */           
/*     */ 
/*     */ 
/*     */           public void onOrientationChanged(int orientation)
/*     */           {
/* 257 */             int rotation = ARView.this.mActivity.getRotation();
/* 258 */             if (rotation != this.mLastRotation) {
/* 259 */               Log.i("KudanAR", "Orientation changed >>> " + rotation);
/*     */               
/* 261 */               ARView.this.resetCameraMesh = true;
/*     */               
/* 263 */               this.mLastRotation = rotation;
/*     */             }
/*     */             
/*     */           }
/* 267 */         };
/* 268 */         onConstuction(context);
/*     */       }
/*     */       
/*     */       private void onConstuction(Context context)
/*     */       {
/* 273 */         ARAPIKey key = ARAPIKey.getInstance();
/* 274 */         key.checkKey(context);
/*     */         
/* 276 */         setEGLContextClientVersion(2);
/*     */         
/* 278 */         setRenderer(this.mRenderer);
/*     */         
/* 280 */         ARCameraStream cameraStream = ARCameraStream.getInstance();
/* 281 */         cameraStream.initialise();
/*     */         
/*     */ 
/* 284 */         this.mCameraTexture = new ARTextureOES();
/* 285 */         this.mCameraSurfaceTexture = new SurfaceTexture(this.mCameraTexture.getTextureID());
/*     */         
/* 287 */         cameraStream.setSurfaceTexture(this.mCameraSurfaceTexture);
/*     */         
/*     */ 
/* 290 */         setupNewCamera();
/*     */         
/* 292 */         if (this.mOrientationEventListener.canDetectOrientation()) {
/* 293 */           this.mOrientationEventListener.enable();
/*     */         }
/*     */       }
/*     */       
/*     */       public void onSizeChanged(int w, int h, int ow, int oh)
/*     */       {
/* 299 */         super.onSizeChanged(w, h, ow, oh);
/*     */         
/* 301 */         setRenderMode(0);
/*     */         
/* 303 */         if (this.onLoad) {
/* 304 */           setupViewports(false);
/* 305 */           setup();
/*     */           
/* 307 */           this.onLoad = false;
/*     */         } else {
/* 309 */           this.resetCameraMesh = true;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       public void onConfigurationChanged(Configuration config)
/*     */       {
/* 316 */         super.onConfigurationChanged(config);
/*     */       }
/*     */       
/*     */ 
/*     */       public void onResume()
/*     */       {
/* 322 */         super.onResume();
/*     */         
/* 324 */         ARCameraStream cameraStream = ARCameraStream.getInstance();
/* 325 */         cameraStream.start();
/*     */         
/* 327 */         ARRenderer renderer = ARRenderer.getInstance();
/* 328 */         renderer.resume();
/*     */         
/* 330 */         if (this.mOrientationEventListener.canDetectOrientation()) {
/* 331 */           this.mOrientationEventListener.enable();
/*     */         }
/*     */         
/* 334 */         this.resetCameraMesh = true;
/*     */       }
/*     */       
/*     */       public void onPause()
/*     */       {
/* 339 */         super.onPause();
/*     */         
/* 341 */         ARCameraStream cameraStream = ARCameraStream.getInstance();
/* 342 */         cameraStream.stop();
/*     */         
/* 344 */         ARRenderer renderer = ARRenderer.getInstance();
/* 345 */         renderer.pause();
/*     */         
/* 347 */         this.mOrientationEventListener.disable();
/*     */       }
/*     */       
/*     */       public ARViewPort getCameraViewPort()
/*     */       {
/* 352 */         return this.mCameraViewPort;
/*     */       }
/*     */       
/*     */       public ARViewPort getContentViewPort()
/*     */       {
/* 357 */         return this.mContentViewPort;
/*     */       }
/*     */       
/*     */       public void render()
/*     */       {
/* 362 */         requestRender();
/*     */       }
/*     */     }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */