/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARCameraBackgroundShader
/*    */   extends ARShaderProgram
/*    */ {
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;\nvoid main()\n{\n    gl_Position = vertexPosition;\n}";
/*    */   static final String fragmentString = "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nuniform samplerExternalOES uvSampler;\nuniform mat4 markerModelViewProjection;\nuniform mat4 uvTransform;\nvoid main()\n{\n\tvec4 clipCoord = markerModelViewProjection * vec4(gl_FragCoord.xy, 0.0, 1.0);\n\t vec2 ndc = vec2(clipCoord.x, clipCoord.y);\n\t ndc /= clipCoord.w;\n    float x = (ndc.x * 0.5 + 0.5);\n    float y = (ndc.y * 0.5 + 0.5);\n\t vec2 lookup = vec2(x, y);\n    vec4 uv = vec4(lookup, 0, 1.0);\n    uv = uvTransform * uv;\n    lookup = vec2(uv.x, uv.y);\n    vec4 rgb = texture2D(uvSampler, lookup);\n    gl_FragColor = rgb;}";
/*    */   
/*    */   public ARCameraBackgroundShader()
/*    */   {
/* 40 */     setShaderStrings("attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;\nvoid main()\n{\n    gl_Position = vertexPosition;\n}", "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nuniform samplerExternalOES uvSampler;\nuniform mat4 markerModelViewProjection;\nuniform mat4 uvTransform;\nvoid main()\n{\n\tvec4 clipCoord = markerModelViewProjection * vec4(gl_FragCoord.xy, 0.0, 1.0);\n\t vec2 ndc = vec2(clipCoord.x, clipCoord.y);\n\t ndc /= clipCoord.w;\n    float x = (ndc.x * 0.5 + 0.5);\n    float y = (ndc.y * 0.5 + 0.5);\n\t vec2 lookup = vec2(x, y);\n    vec4 uv = vec4(lookup, 0, 1.0);\n    uv = uvTransform * uv;\n    lookup = vec2(uv.x, uv.y);\n    vec4 rgb = texture2D(uvSampler, lookup);\n    gl_FragColor = rgb;}");
/*    */   }
/*    */   
/*    */   public static ARCameraBackgroundShader getShader() {
/* 44 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 46 */     boolean[] properties = { true };
/*    */     
/* 48 */     ARCameraBackgroundShader shader = (ARCameraBackgroundShader)shaderManager.findShader(ARCameraBackgroundShader.class, properties);
/* 49 */     if (shader != null)
/*    */     {
/* 51 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 55 */     shader = new ARCameraBackgroundShader();
/*    */     
/* 57 */     shaderManager.addShader(shader, properties);
/*    */     
/* 59 */     ARRenderer renderer = ARRenderer.getInstance();
/* 60 */     renderer.addShader(shader);
/*    */     
/* 62 */     return shader;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 67 */     int uvTransformHandle = GLES20.glGetUniformLocation(this.mShaderID, "uvTransform");
/* 68 */     if (uvTransformHandle >= 0) {
/* 69 */       GLES20.glUniformMatrix4fv(uvTransformHandle, 1, false, uvTransform, 0);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setMarkerModelViewProjection(float[] mvp) {
/* 74 */     int mvpHandle = GLES20.glGetUniformLocation(this.mShaderID, "markerModelViewProjection");
/* 75 */     if (mvpHandle >= 0) {
/* 76 */       GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCameraBackgroundShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */