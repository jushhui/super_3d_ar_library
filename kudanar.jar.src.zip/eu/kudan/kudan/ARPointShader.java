/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARPointShader
/*    */   extends ARShaderProgram
/*    */ {
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;\nvoid main()\n{\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n    gl_PointSize = 32.0;\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static final String fragmentString = "precision mediump float;\nuniform sampler2D uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, gl_PointCoord);\n    gl_FragColor = col;\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ARPointShader()
/*    */   {
/* 25 */     setShaderStrings("attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;\nvoid main()\n{\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n    gl_PointSize = 32.0;\n}", "precision mediump float;\nuniform sampler2D uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, gl_PointCoord);\n    gl_FragColor = col;\n}");
/*    */   }
/*    */   
/*    */   public static ARPointShader getShader() {
/* 29 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 31 */     boolean[] properties = { true };
/*    */     
/* 33 */     ARPointShader shader = (ARPointShader)shaderManager.findShader(ARPointShader.class, properties);
/* 34 */     if (shader != null)
/*    */     {
/* 36 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 40 */     shader = new ARPointShader();
/*    */     
/* 42 */     shaderManager.addShader(shader, properties);
/*    */     
/* 44 */     ARRenderer renderer = ARRenderer.getInstance();
/* 45 */     renderer.addShader(shader);
/*    */     
/* 47 */     return shader;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARPointShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */