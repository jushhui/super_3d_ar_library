/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ 
/*    */ public class ARPointMaterial
/*    */   extends ARMaterial
/*    */ {
/*    */   private ARTexture2D mTexture;
/*    */   private ARPointShader mShader;
/*    */   
/*    */   public ARPointMaterial()
/*    */   {
/* 12 */     this.mShader = ARPointShader.getShader();
/*    */   }
/*    */   
/*    */   public ARPointMaterial(ARTexture2D texture) {
/* 16 */     this();
/* 17 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node)
/*    */   {
/* 22 */     boolean b = super.prepareRendererWithNode(node);
/* 23 */     if (!b) {
/* 24 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 28 */     this.mShader.prepareRenderer();
/* 29 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARPointMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */