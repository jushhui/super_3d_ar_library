/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.google.vrtoolkit.cardboard.sensors.HeadTracker;
/*    */ import com.jme3.math.Matrix4f;
/*    */ import com.jme3.math.Quaternion;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARGyroManager
/*    */   implements ARRendererListener
/*    */ {
/*    */   private static ARGyroManager gyroManager;
/*    */   private HeadTracker mHeadTracker;
/* 14 */   private ARWorld mGyroWorld = new ARWorld();
/*    */   
/*    */   public static ARGyroManager getInstance()
/*    */   {
/* 18 */     if (gyroManager == null) {
/* 19 */       gyroManager = new ARGyroManager();
/*    */     }
/* 21 */     return gyroManager;
/*    */   }
/*    */   
/*    */   public void initialise()
/*    */   {
/* 26 */     if (this.mHeadTracker == null) {
/* 27 */       this.mHeadTracker = new HeadTracker(ARRenderer.getInstance().getActivity());
/*    */     }
/*    */     
/* 30 */     this.mGyroWorld.setName("GyroWorld");
/*    */   }
/*    */   
/*    */   public void deinitialise()
/*    */   {
/* 35 */     this.mGyroWorld.remove();
/* 36 */     this.mGyroWorld.removeAllChildren();
/*    */     
/* 38 */     this.mHeadTracker = null;
/* 39 */     this.mGyroWorld = new ARWorld();
/*    */     
/* 41 */     ARRenderer.getInstance().getActivity().getARView().getContentViewPort().getCamera().addChild(this.mGyroWorld);
/* 42 */     this.mGyroWorld.setVisible(false);
/*    */   }
/*    */   
/*    */   public void start()
/*    */   {
/* 47 */     if (this.mHeadTracker != null) {
/* 48 */       this.mHeadTracker.startTracking();
/* 49 */       this.mGyroWorld.setVisible(true);
/* 50 */       ARRenderer.getInstance().addListener(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void stop()
/*    */   {
/* 56 */     if (this.mHeadTracker != null) {
/* 57 */       this.mHeadTracker.stopTracking();
/* 58 */       this.mGyroWorld.setVisible(false);
/* 59 */       ARRenderer.getInstance().removeListener(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public synchronized void updateGyro()
/*    */   {
/* 65 */     float[] fmat = new float[16];
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 70 */     this.mHeadTracker.getLastHeadView(fmat, 0);
/*    */     
/*    */ 
/* 73 */     Matrix4f matrix = new Matrix4f(fmat);
/*    */     
/* 75 */     Quaternion orientation = matrix.toRotationQuat();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 84 */     this.mGyroWorld.setOrientation(orientation);
/*    */   }
/*    */   
/*    */   public ARWorld getWorld() {
/* 88 */     return this.mGyroWorld;
/*    */   }
/*    */   
/*    */   public void preRender()
/*    */   {
/* 93 */     updateGyro();
/*    */   }
/*    */   
/*    */   public void postRender() {}
/*    */   
/*    */   public void rendererDidPause() {}
/*    */   
/*    */   public void rendererDidResume() {}
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARGyroManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */