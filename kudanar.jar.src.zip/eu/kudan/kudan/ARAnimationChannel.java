/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ 
/*    */ public class ARAnimationChannel
/*    */ {
/*    */   private ARNode mNode;
/*    */   private int mNativeMem;
/*    */   
/*    */   public ARAnimationChannel(ARNode node, int nativeMem)
/*    */   {
/* 11 */     this.mNode = node;
/* 12 */     this.mNativeMem = nativeMem;
/*    */   }
/*    */   
/*    */   private native boolean updateTransformN(ARNode paramARNode, int paramInt);
/*    */   
/* 17 */   public boolean updateTransform(int frame) { return updateTransformN(this.mNode, frame); }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARAnimationChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */