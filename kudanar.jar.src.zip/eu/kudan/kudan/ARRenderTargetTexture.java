/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ public class ARRenderTargetTexture extends ARRenderTarget
/*    */ {
/*    */   private ARTexture2D mTexture;
/*    */   private int mFBO;
/*    */   private int mWidth;
/*    */   private int mHeight;
/*    */   
/*    */   public ARRenderTargetTexture(int width, int height)
/*    */   {
/* 14 */     this.mWidth = width;
/* 15 */     this.mHeight = height;
/* 16 */     this.mTexture = new ARTexture2D();
/*    */   }
/*    */   
/*    */   public ARTexture2D getTexture() {
/* 20 */     return this.mTexture;
/*    */   }
/*    */   
/*    */   public void bind()
/*    */   {
/* 25 */     GLES20.glBindFramebuffer(36160, this.mFBO);
/*    */   }
/*    */   
/*    */   public void create() {
/* 29 */     int[] n = new int[1];
/* 30 */     GLES20.glGenFramebuffers(1, n, 0);
/*    */     
/* 32 */     int fboID = n[0];
/* 33 */     this.mFBO = fboID;
/*    */     
/* 35 */     GLES20.glBindFramebuffer(36160, fboID);
/*    */     
/* 37 */     GLES20.glGenTextures(1, n, 0);
/*    */     
/* 39 */     int textureID = n[0];
/* 40 */     GLES20.glBindTexture(3553, textureID);
/*    */     
/* 42 */     this.mTexture.setTextureID(textureID);
/*    */     
/* 44 */     android.util.Log.i("TEXTURE", "texture: " + textureID);
/*    */     
/* 46 */     GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 47 */     GLES20.glTexParameterf(3553, 10240, 9729.0F);
/* 48 */     GLES20.glTexParameterf(3553, 10243, 33071.0F);
/* 49 */     GLES20.glTexParameterf(3553, 10242, 33071.0F);
/*    */     
/* 51 */     GLES20.glTexImage2D(3553, 0, 6408, this.mWidth, this.mHeight, 0, 6408, 5121, null);
/*    */     
/* 53 */     GLES20.glFramebufferTexture2D(36160, 36064, 3553, textureID, 0);
/*    */     
/*    */ 
/* 56 */     GLES20.glGenRenderbuffers(1, n, 0);
/* 57 */     int depthBuffer = n[0];
/*    */     
/* 59 */     GLES20.glBindRenderbuffer(36161, depthBuffer);
/* 60 */     GLES20.glRenderbufferStorage(36161, 33189, this.mWidth, this.mHeight);
/*    */     
/* 62 */     GLES20.glFramebufferRenderbuffer(36160, 36096, 36161, depthBuffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void draw()
/*    */   {
/* 68 */     super.draw();
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 72 */     return this.mWidth;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 76 */     return this.mHeight;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARRenderTargetTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */