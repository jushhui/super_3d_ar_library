/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Matrix4f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARMesh
/*     */ {
/*     */   private ARVertexBuffer mVertexBuffer;
/*     */   private ARIndexBuffer mIndexBuffer;
/*     */   private NativeMesh mNativeMesh;
/*     */   private int mNumberOfIndices;
/*     */   private int mNumberOfVertices;
/*     */   private int mVertexDataStride;
/*     */   private boolean mHasUVs;
/*     */   private boolean mHasNormals;
/*     */   private boolean mHasTangents;
/*     */   private int mBonesPerVertex;
/*  26 */   private List<ARBoneNode> mBones = new ArrayList();
/*  27 */   private List<ARBlendShapeChannel> mBlendShapeChannels = new ArrayList();
/*     */   
/*     */   private int mNativeVertexBuffer;
/*     */   
/*     */ 
/*     */   public ARMesh() {}
/*     */   
/*     */ 
/*     */   public void setBones(List<ARBoneNode> bones)
/*     */   {
/*  37 */     this.mBones = bones;
/*     */   }
/*     */   
/*     */   public void addBone(ARBoneNode bone) {
/*  41 */     this.mBones.add(bone);
/*     */   }
/*     */   
/*     */   public List<ARBoneNode> getBones() {
/*  45 */     return this.mBones;
/*     */   }
/*     */   
/*     */   public ARMesh(NativeMesh nativeMesh) {
/*  49 */     this.mNativeMesh = nativeMesh;
/*  50 */     this.mVertexBuffer = new ARVertexBuffer(nativeMesh);
/*  51 */     this.mIndexBuffer = new ARIndexBuffer(nativeMesh);
/*  52 */     this.mNumberOfIndices = nativeMesh.getNumberOfIndices();
/*     */   }
/*     */   
/*     */   public ARMesh(int nativeVertexBuffer, int nativeIndexBuffer, boolean hasNormals, boolean hasUVs, boolean hasTangents, int maxBonesPerVertex)
/*     */   {
/*  57 */     this.mNativeVertexBuffer = nativeVertexBuffer;
/*  58 */     this.mVertexBuffer = new ARVertexBuffer(nativeVertexBuffer, hasNormals, hasUVs, hasTangents, maxBonesPerVertex);
/*  59 */     this.mIndexBuffer = new ARIndexBuffer(nativeIndexBuffer);
/*     */   }
/*     */   
/*     */   public void createTestMeshNoUV(float width, float height) {
/*  63 */     this.mVertexBuffer = new ARVertexBuffer(false, false, false, 0);
/*  64 */     this.mIndexBuffer = new ARIndexBuffer();
/*     */     
/*  66 */     float x = width / 2.0F;
/*  67 */     float y = height / 2.0F;
/*     */     
/*  69 */     float u = 1.0F;
/*  70 */     float v = 1.0F;
/*     */     
/*  72 */     float[] vertices = {
/*  73 */       x, -y, 0.0F, 
/*  74 */       x, y, 0.0F, 
/*  75 */       -x, y, 0.0F, 
/*  76 */       -x, -y, 0.0F };
/*     */     
/*     */ 
/*  79 */     short[] indices = { 0, 1, 2, 2, 3 };
/*     */     
/*  81 */     this.mVertexBuffer.setVertexData(vertices);
/*  82 */     this.mIndexBuffer.setIndexData(indices);
/*     */     
/*  84 */     this.mNumberOfIndices = 6;
/*     */   }
/*     */   
/*     */   public void createTestMesh(float width, float height) {
/*  88 */     this.mVertexBuffer = new ARVertexBuffer(false, true, false, 0);
/*  89 */     this.mIndexBuffer = new ARIndexBuffer();
/*     */     
/*  91 */     float x = width / 2.0F;
/*  92 */     float y = height / 2.0F;
/*     */     
/*  94 */     float u = 1.0F;
/*  95 */     float v = 1.0F;
/*     */     
/*  97 */     float[] vertices = {
/*  98 */       x, -y, 0.0F, 
/*  99 */       0.0F, v, 
/* 100 */       x, y, 0.0F, 
/* 101 */       0.0F, 0.0F, 
/* 102 */       -x, y, 0.0F, 
/* 103 */       u, 0.0F, 
/* 104 */       -x, -y, 0.0F, 
/* 105 */       u, v };
/*     */     
/*     */ 
/* 108 */     short[] indices = { 0, 1, 2, 2, 3 };
/*     */     
/* 110 */     this.mVertexBuffer.setVertexData(vertices);
/* 111 */     this.mIndexBuffer.setIndexData(indices);
/*     */     
/* 113 */     this.mNumberOfIndices = 6;
/*     */   }
/*     */   
/*     */   public ARVertexBuffer getVertexBuffer() {
/* 117 */     return this.mVertexBuffer;
/*     */   }
/*     */   
/*     */   public void createTestMesh2(float width, float height) {
/* 121 */     this.mVertexBuffer = new ARVertexBuffer(false, true, false, 0);
/* 122 */     this.mIndexBuffer = new ARIndexBuffer();
/*     */     
/* 124 */     float x = width / 2.0F;
/* 125 */     float y = height / 2.0F;
/*     */     
/* 127 */     float u = 1.0F;
/* 128 */     float v = 1.0F;
/*     */     
/* 130 */     float[] vertices = {
/* 131 */       x, -y, 0.0F, 
/* 132 */       u, 0.0F, 
/* 133 */       x, y, 0.0F, 
/* 134 */       u, v, 
/* 135 */       -x, y, 0.0F, 
/* 136 */       0.0F, v, 
/* 137 */       -x, -y, 0.0F, 
/* 138 */       0.0F, 0.0F };
/*     */     
/*     */ 
/* 141 */     short[] indices = { 0, 1, 2, 2, 3 };
/*     */     
/* 143 */     this.mVertexBuffer.setVertexData(vertices);
/* 144 */     this.mIndexBuffer.setIndexData(indices);
/*     */     
/* 146 */     this.mNumberOfIndices = 6;
/*     */   }
/*     */   
/*     */   public void createTestMeshWithUvs(float width, float height, float u, float u2, float v, float v2, boolean rotate, boolean update) {
/* 150 */     if (!update) {
/* 151 */       this.mVertexBuffer = new ARVertexBuffer(false, true, false, 0);
/* 152 */       this.mIndexBuffer = new ARIndexBuffer();
/*     */     }
/*     */     
/* 155 */     float x = width / 2.0F;
/* 156 */     float y = height / 2.0F;
/*     */     
/*     */     float[] vertices;
/*     */     float[] vertices;
/* 160 */     if (!rotate) {
/* 161 */       vertices = new float[] {
/* 162 */         -x, y, 0.0F, 
/* 163 */         u, v2, 
/* 164 */         x, y, 0.0F, 
/* 165 */         u2, v2, 
/* 166 */         x, -y, 0.0F, 
/* 167 */         u2, v, 
/* 168 */         -x, -y, 0.0F, 
/* 169 */         u, v };
/*     */     }
/*     */     else {
/* 172 */       vertices = new float[] {
/* 173 */         -x, y, 0.0F, 
/* 174 */         u2, v2, 
/* 175 */         x, y, 0.0F, 
/* 176 */         u2, v, 
/* 177 */         x, -y, 0.0F, 
/* 178 */         u, v, 
/* 179 */         -x, -y, 0.0F, 
/* 180 */         u, v2 };
/*     */     }
/*     */     
/*     */ 
/* 184 */     short[] indices = { 0, 1, 2, 2, 3 };
/*     */     
/* 186 */     this.mVertexBuffer.setVertexData(vertices);
/* 187 */     this.mIndexBuffer.setIndexData(indices);
/* 188 */     this.mNumberOfIndices = 6;
/*     */     
/* 190 */     if (update) {
/* 191 */       this.mVertexBuffer.updateData();
/*     */     }
/*     */   }
/*     */   
/*     */   public void createTestMeshWithUvs(float width, float height, float u, float u2, float v, float v2)
/*     */   {
/* 197 */     createTestMeshWithUvs(width, height, u, u2, v, v2, false, false);
/*     */   }
/*     */   
/*     */   private void processBones(ARMeshNode meshNode) {
/* 201 */     if (getBones().size() == 0) {
/* 202 */       return;
/*     */     }
/*     */     
/* 205 */     List<Matrix4f> transforms = new ArrayList();
/*     */     
/* 207 */     for (ARBoneNode node : getBones()) {
/* 208 */       Matrix4f full = node.getFullTransform();
/* 209 */       Matrix4f thisInverse = meshNode.getFullTransform().invert();
/*     */       
/*     */ 
/* 212 */       full = thisInverse.mult(full);
/*     */       
/*     */ 
/* 215 */       full = full.mult(node.getOffsetMatrix());
/*     */       
/* 217 */       transforms.add(full);
/*     */     }
/*     */     
/*     */ 
/* 221 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/* 223 */     renderer.setBones(transforms);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private native void updateVertexBufferWithMeshN(int paramInt1, ARBlendShape paramARBlendShape, int paramInt2, int paramInt3);
/*     */   
/*     */ 
/*     */ 
/*     */   private native void updateVertexBufferN(ARBlendShape paramARBlendShape1, ARBlendShape paramARBlendShape2);
/*     */   
/*     */ 
/*     */ 
/*     */   private void processBlendShapes()
/*     */   {
/* 238 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepareRenderer(ARMeshNode meshNode)
/*     */   {
/* 361 */     this.mVertexBuffer.prepareRenderer();
/* 362 */     this.mIndexBuffer.prepareRenderer();
/*     */     
/* 364 */     processBones(meshNode);
/* 365 */     processBlendShapes();
/*     */   }
/*     */   
/*     */   public int getNumberOfIndices() {
/* 369 */     return this.mNumberOfIndices;
/*     */   }
/*     */   
/*     */   public void addBlendShapeChannel(ARBlendShapeChannel channel) {
/* 373 */     this.mBlendShapeChannels.add(channel);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARMesh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */