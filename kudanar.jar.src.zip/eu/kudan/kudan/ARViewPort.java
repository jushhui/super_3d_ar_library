/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARViewPort
/*    */ {
/*    */   private ARCamera mCamera;
/*    */   private int mOffsetX;
/*    */   private int mOffsetY;
/*    */   private int mWidth;
/*    */   private int mHeight;
/*    */   private int mZOrder;
/*    */   
/*    */   public ARViewPort()
/*    */   {
/* 14 */     this.mCamera = new ARCamera();
/*    */   }
/*    */   
/*    */   public ARViewPort(int offsetX, int offsetY, int width, int height) {
/* 18 */     this();
/* 19 */     setViewportParms(offsetX, offsetY, width, height);
/*    */   }
/*    */   
/*    */   public void setCamera(ARCamera camera) {
/* 23 */     this.mCamera = camera;
/*    */   }
/*    */   
/*    */   public int getOffsetX() {
/* 27 */     return this.mOffsetX;
/*    */   }
/*    */   
/*    */   public int getOffsetY() {
/* 31 */     return this.mOffsetY;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 35 */     return this.mWidth;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 39 */     return this.mHeight;
/*    */   }
/*    */   
/*    */   public void setViewportParms(int offsetX, int offsetY, int width, int height) {
/* 43 */     this.mOffsetX = offsetX;
/* 44 */     this.mOffsetY = offsetY;
/* 45 */     this.mWidth = width;
/* 46 */     this.mHeight = height;
/*    */   }
/*    */   
/*    */   public ARCamera getCamera() {
/* 50 */     return this.mCamera;
/*    */   }
/*    */   
/*    */   public void setZOrder(int zOrder) {
/* 54 */     this.mZOrder = zOrder;
/*    */   }
/*    */   
/*    */   public int getZOrder() {
/* 58 */     return this.mZOrder;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARViewPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */