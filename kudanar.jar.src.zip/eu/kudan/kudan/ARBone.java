/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.jme3.math.Matrix4f;
/*    */ 
/*    */ public class ARBone
/*    */ {
/*    */   private Matrix4f mOffsetMatrix;
/*  8 */   private float[] offsetMatrix = new float[16];
/*    */   private int nodeID;
/*    */   private ARNode mNode;
/*    */   
/*    */   public Matrix4f getOffsetMatrix() {
/* 13 */     if (this.mOffsetMatrix == null) {
/* 14 */       this.mOffsetMatrix = new Matrix4f(this.offsetMatrix);
/*    */     }
/* 16 */     return this.mOffsetMatrix;
/*    */   }
/*    */   
/*    */   public int getNodeID() {
/* 20 */     return this.nodeID;
/*    */   }
/*    */   
/*    */   public ARNode getNode() {
/* 24 */     return this.mNode;
/*    */   }
/*    */   
/*    */   public void setNode(ARNode node) {
/* 28 */     this.mNode = node;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARBone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */