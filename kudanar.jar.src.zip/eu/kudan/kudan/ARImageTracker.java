/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Quaternion;
/*     */ import com.jme3.math.Vector3f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARImageTracker
/*     */ {
/*     */   private static ARImageTracker imageTracker;
/*     */   private boolean mIsInitialised;
/*     */   private ARNode mBaseNode;
/*     */   private List<ARImageTrackable> mTrackables;
/*     */   
/*     */   public static ARImageTracker getInstance()
/*     */   {
/*  22 */     if (imageTracker == null) {
/*  23 */       imageTracker = new ARImageTracker();
/*     */     }
/*  25 */     return imageTracker;
/*     */   }
/*     */   
/*     */ 
/*     */   public ARImageTracker()
/*     */   {
/*  31 */     this.mBaseNode = new ARNode();
/*     */   }
/*     */   
/*     */ 
/*  35 */   public ARNode getBaseNode() { return this.mBaseNode; }
/*     */   private native void processFrameN(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */   private native int getNumberOfResultsN();
/*  38 */   private int mDetectedTrackables = 0;
/*     */   
/*     */ 
/*     */   private native String getTrackedMarkerN(int paramInt, Vector3f paramVector3f, Quaternion paramQuaternion);
/*     */   
/*     */   void processFrame(byte[] cameraImage, int width, int height)
/*     */   {
/*  45 */     if (!this.mIsInitialised) {
/*  46 */       return;
/*     */     }
/*     */     
/*  49 */     processFrameN(cameraImage, width, height);
/*     */     
/*     */ 
/*  52 */     for (ARImageTrackable trackable : this.mTrackables) {
/*  53 */       trackable.getWorld().setVisible(false);
/*  54 */       trackable.trackerStartFrame();
/*  55 */       trackable.trackerSetDetected(false);
/*     */     }
/*     */     
/*  58 */     this.mDetectedTrackables = 0;
/*     */     
/*     */ 
/*  61 */     for (int i = 0; i < getNumberOfResultsN(); i++) {
/*  62 */       v = new Vector3f();
/*  63 */       Quaternion q = new Quaternion();
/*     */       
/*     */ 
/*  66 */       String name = getTrackedMarkerN(i, (Vector3f)v, q);
/*     */       
/*  68 */       if (name != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */         for (ARImageTrackable trackable : this.mTrackables) {
/*  75 */           if (trackable.getName().equals(name)) {
/*  76 */             ARWorld world = trackable.getWorld();
/*     */             
/*  78 */             world.setPosition((Vector3f)v);
/*  79 */             world.setOrientation(q);
/*  80 */             world.setVisible(true);
/*     */             
/*  82 */             trackable.trackerSetDetected(true);
/*     */             
/*  84 */             break;
/*     */           }
/*     */         }
/*     */         
/*  88 */         this.mDetectedTrackables += 1;
/*     */       }
/*     */     }
/*  91 */     for (Object v = this.mTrackables.iterator(); ((Iterator)v).hasNext();) { ARImageTrackable trackable = (ARImageTrackable)((Iterator)v).next();
/*  92 */       trackable.trackerEndFrame();
/*     */     }
/*     */   }
/*     */   
/*     */   private native void initN();
/*     */   
/*  98 */   public void initialise() { initN();
/*  99 */     this.mTrackables = new ArrayList();
/* 100 */     this.mIsInitialised = true;
/*     */   }
/*     */   
/*     */   private native void destroyN();
/*     */   
/* 105 */   public void deinitialise() { destroyN();
/* 106 */     this.mTrackables = null;
/* 107 */     this.mIsInitialised = false;
/* 108 */     this.mBaseNode.remove();
/* 109 */     this.mBaseNode = new ARNode();
/*     */   }
/*     */   
/*     */   private native void addTrackableN(ARImageTrackable paramARImageTrackable);
/*     */   
/*     */   public void addTrackable(ARImageTrackable trackable) {
/* 115 */     this.mTrackables.add(trackable);
/*     */     
/*     */ 
/* 118 */     this.mBaseNode.addChild(trackable.getWorld());
/*     */     
/*     */ 
/* 121 */     trackable.getWorld().setVisible(false);
/*     */     
/* 123 */     addTrackableN(trackable);
/*     */   }
/*     */   
/*     */   public List<ARImageTrackable> getTrackables() {
/* 127 */     return this.mTrackables;
/*     */   }
/*     */   
/*     */   public int getNumberOfDetectedTrackables() {
/* 131 */     return this.mDetectedTrackables;
/*     */   }
/*     */   
/*     */   public List<ARImageTrackable> getDetectedTrackables() {
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public void addTrackableSet(ARTrackableSet set) {
/* 139 */     for (ARImageTrackable trackable : set.getTrackables()) {
/* 140 */       addTrackable(trackable);
/*     */     }
/*     */   }
/*     */   
/*     */   private native void setMaximumSimultaneousTrackingN(int paramInt);
/*     */   
/*     */   public void setMaximumSimultaneousTracking(int maxToTrack) {
/* 147 */     setMaximumSimultaneousTrackingN(maxToTrack);
/*     */   }
/*     */   
/*     */ 
/*     */   public void start() {}
/*     */   
/*     */ 
/*     */   public void stop() {}
/*     */   
/*     */ 
/*     */   public ARImageTrackable findTrackable(String trackableName)
/*     */   {
/* 159 */     for (ARImageTrackable trackable : this.mTrackables) {
/* 160 */       if (trackable.getName().equals(trackableName)) {
/* 161 */         return trackable;
/*     */       }
/*     */     }
/*     */     
/* 165 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARImageTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */