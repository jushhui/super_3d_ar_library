/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.graphics.SurfaceTexture;
/*     */ import android.hardware.Camera;
/*     */ import android.hardware.Camera.Parameters;
/*     */ import android.hardware.Camera.PreviewCallback;
/*     */ import android.os.AsyncTask;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARCameraStream
/*     */   implements Camera.PreviewCallback
/*     */ {
/*     */   private static ARCameraStream cameraStream;
/*  20 */   private Lock mLock = new ReentrantLock();
/*     */   
/*  22 */   private boolean mProcessing = false;
/*     */   private float[] mCameraTransform;
/*     */   private ARCameraTextureMaterial mMaterial;
/*     */   private ARTexture mTexture;
/*     */   
/*  27 */   public void setCameraTransform(float[] transform) { this.mCameraTransform = transform; }
/*     */   
/*     */   public float[] getCameraTransform()
/*     */   {
/*  31 */     return this.mCameraTransform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ARTexture getTexture()
/*     */   {
/*  38 */     return this.mTexture;
/*     */   }
/*     */   
/*     */   public void setTexture(ARTexture texture) {
/*  42 */     this.mTexture = texture;
/*     */   }
/*     */   
/*     */   public ARCameraTextureMaterial getMaterial() {
/*  46 */     return this.mMaterial;
/*     */   }
/*     */   
/*     */   public void setMaterial(ARCameraTextureMaterial material) {
/*  50 */     this.mMaterial = material;
/*     */   }
/*     */   
/*     */   public static ARCameraStream getInstance()
/*     */   {
/*  55 */     if (cameraStream == null) {
/*  56 */       cameraStream = new ARCameraStream();
/*     */     }
/*  58 */     return cameraStream;
/*     */   }
/*     */   
/*  61 */   private Camera mCamera = null;
/*     */   
/*     */   private int mWidth;
/*     */   
/*     */   private int mHeight;
/*     */   private SurfaceTexture mSurfaceTexture;
/*     */   public ARView mArView;
/*     */   
/*     */   public ARCameraStream()
/*     */   {
/*  71 */     this.mWidth = 640;
/*  72 */     this.mHeight = 480;
/*     */   }
/*     */   
/*     */   public void setSurfaceTexture(SurfaceTexture surfaceTexture)
/*     */   {
/*  77 */     this.mSurfaceTexture = surfaceTexture;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onPreviewFrame(byte[] data, Camera arg1)
/*     */   {
/*  88 */     synchronized () {
/*  89 */       process(data);
/*     */     }
/*     */     
/*  92 */     ARArbiTrack arbiTrack = ARArbiTrack.getInstance();
/*     */     
/*  94 */     arbiTrack.processFrame(data, 640, 480);
/*     */     
/*  96 */     if (this.mArView != null) {
/*  97 */       this.mArView.render();
/*     */     }
/*     */   }
/*     */   
/*     */   private void process(byte[] data)
/*     */   {
/* 103 */     ARImageTracker tracker = ARImageTracker.getInstance();
/*     */     
/* 105 */     tracker.processFrame(data, 640, 480);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processBG(byte[] data)
/*     */   {
/* 122 */     process(data);
/* 123 */     synchronized (this) {
/* 124 */       this.mProcessing = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void initialise() {}
/*     */   
/*     */ 
/*     */   private class AsyncTaskRunner
/*     */     extends AsyncTask<byte[], String, String>
/*     */   {
/*     */     private AsyncTaskRunner() {}
/*     */     
/*     */     protected String doInBackground(byte[]... arg0)
/*     */     {
/* 139 */       ARCameraStream.this.processBG(arg0[0]);
/*     */       
/* 141 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/* 148 */     this.mCamera = Camera.open();
/*     */     try {
/* 150 */       this.mCamera.setPreviewTexture(this.mSurfaceTexture);
/* 151 */       this.mCamera.setPreviewCallback(this);
/*     */     }
/*     */     catch (IOException e) {
/* 154 */       this.mCamera.release();
/* 155 */       this.mCamera = null;
/* 156 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 161 */     Camera.Parameters parameters = this.mCamera.getParameters();
/* 162 */     parameters.setPreviewSize(this.mWidth, this.mHeight);
/*     */     
/* 164 */     List<String> focusModes = parameters.getSupportedFocusModes();
/*     */     
/* 166 */     if (focusModes.contains("continuous-video")) {
/* 167 */       parameters.setFocusMode("continuous-video");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     double horizFOV = Math.toRadians(parameters.getHorizontalViewAngle());
/* 182 */     double sensorWidth = Math.tan(horizFOV / 2.0D) * parameters.getFocalLength();
/* 183 */     sensorWidth *= 2.0D;
/*     */     
/* 185 */     List<int[]> ranges = parameters.getSupportedPreviewFpsRange();
/*     */     
/* 187 */     for (int[] range : ranges) {
/* 188 */       int min = range[0];
/* 189 */       int max = range[1];
/*     */       
/* 191 */       if ((min == 30000) && (max == 30000))
/*     */       {
/* 193 */         parameters.setPreviewFpsRange(min, max);
/* 194 */         break;
/*     */       }
/*     */       
/* 197 */       if (min == 30000) {
/* 198 */         parameters.setPreviewFpsRange(min, max);
/*     */       }
/*     */     }
/*     */     
/* 202 */     this.mCamera.setParameters(parameters);
/* 203 */     this.mCamera.startPreview();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 208 */     if (this.mCamera == null) {
/* 209 */       return;
/*     */     }
/* 211 */     this.mCamera.setPreviewCallback(null);
/* 212 */     this.mCamera.stopPreview();
/* 213 */     this.mCamera.release();
/* 214 */     this.mCamera = null;
/*     */   }
/*     */   
/*     */   public int getWidth()
/*     */   {
/* 219 */     return this.mWidth;
/*     */   }
/*     */   
/*     */   public int getHeight()
/*     */   {
/* 224 */     return this.mHeight;
/*     */   }
/*     */   
/*     */   public void rotateCameraPreview(int degrees)
/*     */   {
/* 229 */     if (this.mCamera != null) {
/* 230 */       this.mCamera.setDisplayOrientation(degrees);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCameraStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */