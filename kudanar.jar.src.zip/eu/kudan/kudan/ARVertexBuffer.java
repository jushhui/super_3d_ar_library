/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.opengl.GLES20;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARVertexBuffer
/*     */ {
/*  12 */   private int mBufferID = -1;
/*  13 */   private int mStride = 0;
/*     */   
/*  15 */   private int mPositionOffset = 0;
/*  16 */   private int mNormalOffset = -1;
/*  17 */   private int mUVOffset = -1;
/*  18 */   private int mTangentOffset = -1;
/*  19 */   private int mBoneIndexOffset = -1;
/*  20 */   private int mBoneWeightOffset = -1;
/*     */   
/*  22 */   private int mNormalTargetOffset = -1;
/*  23 */   private int mUVTargetOffset = -1;
/*     */   
/*     */   private boolean mHasNormals;
/*     */   
/*     */   private boolean mHasUVs;
/*     */   
/*     */   private boolean mHasTangents;
/*     */   
/*     */   private boolean mHasBones;
/*     */   private int mMaxBones;
/*     */   private NativeMesh mNativeMesh;
/*     */   private int mNativeMem;
/*     */   private FloatBuffer mVertexData;
/*     */   
/*     */   public ARVertexBuffer(boolean hasNormals, boolean hasUVs, boolean hasTangents, int maxBones)
/*     */   {
/*  39 */     this.mHasNormals = hasNormals;
/*  40 */     this.mHasUVs = hasUVs;
/*  41 */     this.mHasTangents = hasTangents;
/*  42 */     this.mMaxBones = maxBones;
/*  43 */     this.mHasBones = (maxBones > 0);
/*     */     
/*  45 */     int floatSize = 4;
/*  46 */     int intSize = 4;
/*     */     
/*  48 */     int offset = 12;
/*     */     
/*  50 */     if (this.mHasNormals) {
/*  51 */       this.mNormalOffset = offset;
/*  52 */       offset += 12;
/*     */     }
/*     */     
/*  55 */     if (this.mHasTangents) {
/*  56 */       this.mTangentOffset = offset;
/*  57 */       offset += 16;
/*     */     }
/*     */     
/*  60 */     if (this.mHasUVs) {
/*  61 */       this.mUVOffset = offset;
/*  62 */       offset += 8;
/*     */     }
/*     */     
/*  65 */     if (this.mMaxBones > 0) {
/*  66 */       this.mBoneIndexOffset = offset;
/*  67 */       offset += 4 * this.mMaxBones;
/*     */       
/*  69 */       this.mBoneWeightOffset = offset;
/*  70 */       offset += 4 * this.mMaxBones;
/*     */     }
/*     */     
/*  73 */     this.mStride = offset;
/*     */     
/*  75 */     ARRenderer renderer = ARRenderer.getInstance();
/*  76 */     renderer.addVertexBuffer(this);
/*     */   }
/*     */   
/*     */   public ARVertexBuffer(NativeMesh nativeMesh) {
/*  80 */     this(nativeMesh.getHasNormals(), nativeMesh.getHasUVs(), nativeMesh.getHasTangents(), nativeMesh.getMaxBones());
/*  81 */     this.mNativeMesh = nativeMesh;
/*     */   }
/*     */   
/*     */   public ARVertexBuffer(int nativeBuffer, boolean hasNormals, boolean hasUVs, boolean hasTangents, int maxBonesPerVertex) {
/*  85 */     this(hasNormals, hasUVs, hasTangents, maxBonesPerVertex);
/*  86 */     this.mNativeMem = nativeBuffer;
/*     */   }
/*     */   
/*     */   public int getStride()
/*     */   {
/*  91 */     return this.mStride;
/*     */   }
/*     */   
/*     */   public void setVertexData(float[] vertexData) {
/*  95 */     this.mVertexData = FloatBuffer.allocate(vertexData.length);
/*  96 */     this.mVertexData.put(vertexData);
/*  97 */     this.mVertexData.flip();
/*     */   }
/*     */   
/*     */   public void createBuffer() {
/* 101 */     IntBuffer buffer = IntBuffer.allocate(1);
/* 102 */     GLES20.glGenBuffers(1, buffer);
/*     */     
/* 104 */     this.mBufferID = buffer.get(0);
/*     */   }
/*     */   
/*     */   public void bindBuffer() {
/* 108 */     GLES20.glBindBuffer(34962, this.mBufferID);
/*     */   }
/*     */   
/*     */   private native void loadDataN(int paramInt);
/*     */   
/*     */   public void loadData() {
/* 114 */     createBuffer();
/* 115 */     bindBuffer();
/*     */     
/* 117 */     if (this.mNativeMem == 0) {
/* 118 */       int size = this.mVertexData.capacity() * 4;
/*     */       
/* 120 */       GLES20.glBufferData(34962, size, this.mVertexData, 35044);
/*     */     }
/*     */     else {
/* 123 */       loadDataN(this.mNativeMem);
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateData() {
/* 128 */     bindBuffer();
/*     */     
/* 130 */     if (this.mNativeMem == 0) {
/* 131 */       int size = this.mVertexData.capacity() * 4;
/*     */       
/* 133 */       GLES20.glBufferData(34962, size, this.mVertexData, 35044);
/*     */     }
/*     */     else {
/* 136 */       loadDataN(this.mNativeMem);
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateBlendShape(boolean hasNormals, boolean hasUVs, boolean hasTangents) {
/* 141 */     this.mHasNormals = hasNormals;
/* 142 */     this.mHasUVs = hasUVs;
/* 143 */     this.mHasTangents = hasTangents;
/*     */     
/* 145 */     int floatSize = 4;
/* 146 */     int intSize = 4;
/*     */     
/* 148 */     int offset = 12;
/*     */     
/* 150 */     if (this.mHasNormals) {
/* 151 */       this.mNormalOffset = offset;
/* 152 */       offset += 12;
/*     */     }
/*     */     
/* 155 */     if (this.mHasTangents) {
/* 156 */       this.mTangentOffset = offset;
/* 157 */       offset += 16;
/*     */     }
/*     */     
/* 160 */     if (this.mHasUVs) {
/* 161 */       this.mUVOffset = offset;
/* 162 */       offset += 8;
/*     */     }
/*     */     
/*     */ 
/* 166 */     if (this.mHasNormals) {
/* 167 */       this.mNormalTargetOffset = offset;
/* 168 */       offset += 12;
/*     */     }
/*     */     
/* 171 */     if (this.mHasUVs) {
/* 172 */       this.mUVTargetOffset = offset;
/* 173 */       offset += 8;
/*     */     }
/*     */     
/*     */ 
/* 177 */     this.mStride = offset;
/*     */   }
/*     */   
/*     */   public void prepareRenderer() {
/* 181 */     bindBuffer();
/*     */     
/* 183 */     int PositionAttribute = 0;
/* 184 */     int NormalAttribute = 1;
/* 185 */     int UVAttribute = 2;
/* 186 */     int BoneIndexAttribute = 3;
/* 187 */     int BoneWeightAttribute = 4;
/* 188 */     int NormalTargetAttribute = 5;
/* 189 */     int UVTargetAttribute = 6;
/*     */     
/* 191 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/*     */ 
/* 194 */     GLES20.glVertexAttribPointer(0, 3, 5126, false, getStride(), this.mPositionOffset);
/* 195 */     GLES20.glEnableVertexAttribArray(0);
/*     */     
/*     */ 
/* 198 */     if (this.mHasNormals) {
/* 199 */       GLES20.glVertexAttribPointer(1, 3, 5126, false, getStride(), this.mNormalOffset);
/* 200 */       GLES20.glEnableVertexAttribArray(1);
/*     */     } else {
/* 202 */       GLES20.glDisableVertexAttribArray(1);
/*     */     }
/*     */     
/*     */ 
/* 206 */     if (this.mHasUVs) {
/* 207 */       GLES20.glVertexAttribPointer(2, 2, 5126, false, getStride(), this.mUVOffset);
/* 208 */       GLES20.glEnableVertexAttribArray(2);
/*     */     } else {
/* 210 */       GLES20.glDisableVertexAttribArray(2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     if (this.mHasBones) {
/* 231 */       GLES20.glVertexAttribPointer(3, 4, 5126, false, getStride(), this.mBoneIndexOffset);
/* 232 */       GLES20.glVertexAttribPointer(4, 4, 5126, false, getStride(), this.mBoneWeightOffset);
/* 233 */       GLES20.glEnableVertexAttribArray(3);
/* 234 */       GLES20.glEnableVertexAttribArray(4);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 243 */       GLES20.glVertexAttribPointer(3, 3, 5126, false, getStride(), 0);
/* 244 */       GLES20.glVertexAttribPointer(4, 3, 5126, false, getStride(), 0);
/* 245 */       GLES20.glEnableVertexAttribArray(3);
/* 246 */       GLES20.glEnableVertexAttribArray(4);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARVertexBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */