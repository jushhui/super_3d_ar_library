/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.content.res.AssetManager;
/*     */ import android.graphics.Point;
/*     */ import android.media.MediaPlayer;
/*     */ import android.opengl.GLES20;
/*     */ import android.util.Log;
/*     */ import com.jme3.math.Matrix3f;
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Vector2f;
/*     */ import com.jme3.math.Vector3f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ARRenderer
/*     */ {
/*     */   private static ARRenderer renderer;
/*     */   public List<ARRendererListener> mListeners;
/*     */   private long renderTime;
/*     */   private Matrix4f mProjectionMatrix;
/*     */   private Matrix4f mModelViewMatrix;
/*     */   private Matrix4f mModelMatrix;
/*     */   
/*     */   public static ARRenderer getInstance()
/*     */   {
/*  29 */     if (renderer == null) {
/*  30 */       renderer = new ARRenderer();
/*     */     }
/*  32 */     return renderer;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getRenderTime()
/*     */   {
/*  38 */     return this.renderTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  43 */   private Matrix4f mModelViewProjectionMatrix = new Matrix4f();
/*     */   private Matrix3f mNormalMatrix;
/*     */   private Vector3f mWorldCameraPosition;
/*  46 */   private Vector3f mLightPosition = new Vector3f();
/*     */   private float mBlendInfluence;
/*     */   private List<Matrix4f> mBones;
/*     */   private ARCamera mCamera;
/*     */   
/*  51 */   public void setBlendInfluence(float influence) { this.mBlendInfluence = influence; }
/*     */   
/*     */   public float getBlendInfluence()
/*     */   {
/*  55 */     return this.mBlendInfluence;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBones(List<Matrix4f> bones)
/*     */   {
/*  61 */     this.mBones = bones;
/*     */   }
/*     */   
/*     */   public List<Matrix4f> getBones() {
/*  65 */     return this.mBones;
/*     */   }
/*     */   
/*     */ 
/*     */   private AssetManager mAssetManager;
/*     */   
/*     */   private String mDataDir;
/*     */   
/*     */   public Vector2f cameraFBOResolution;
/*     */   
/*  75 */   private List<ARRenderTarget> mRenderTargets = new ArrayList();
/*     */   private ARRenderTarget mDefaultRenderTarget;
/*     */   
/*     */   public void addRenderTarget(ARRenderTarget renderTarget) {
/*  79 */     this.mRenderTargets.add(renderTarget);
/*     */   }
/*     */   
/*     */   public List<ARRenderTarget> getRenderTargets() {
/*  83 */     return this.mRenderTargets;
/*     */   }
/*     */   
/*     */ 
/*     */   public ARRenderTarget getDefaultRenderTarget()
/*     */   {
/*  89 */     return this.mDefaultRenderTarget;
/*     */   }
/*     */   
/*     */   public String getDataDir() {
/*  93 */     return this.mDataDir;
/*     */   }
/*     */   
/*     */   public void setDataDir(String dataDir) {
/*  97 */     this.mDataDir = dataDir;
/*     */   }
/*     */   
/*     */ 
/* 101 */   private List<MediaPlayer> mMediaPlayers = new ArrayList();
/*     */   
/* 103 */   private List<ARVertexBuffer> mVertexBuffers = new ArrayList();
/* 104 */   private List<ARIndexBuffer> mIndexBuffers = new ArrayList();
/* 105 */   private List<ARTexture> mTextures = new ArrayList();
/* 106 */   private List<ARShaderProgram> mShaders = new ArrayList();
/*     */   
/*     */   public Vector2f mScreenSize;
/*     */   private Vector2f mCameraSize;
/*     */   private ARActivity mActivity;
/*     */   
/*     */   public ARActivity getActivity()
/*     */   {
/* 114 */     return this.mActivity;
/*     */   }
/*     */   
/*     */   public void setActivity(ARActivity mActivity) {
/* 118 */     this.mActivity = mActivity;
/*     */   }
/*     */   
/*     */   public void setScreenSize(int x, int y)
/*     */   {
/* 123 */     this.mScreenSize = new Vector2f(x, y);
/*     */   }
/*     */   
/*     */   public void setCameraSize(int x, int y) {
/* 127 */     this.mCameraSize = new Vector2f(x, y);
/*     */   }
/*     */   
/* 130 */   private Point mTouchCoords = null;
/*     */   private boolean mRenderForCapture;
/*     */   
/* 133 */   public Matrix4f getProjectionMatrix() { return this.mProjectionMatrix; }
/*     */   
/*     */   public void setProjectionMatrix(Matrix4f projectionMatrix)
/*     */   {
/* 137 */     this.mProjectionMatrix = projectionMatrix;
/*     */   }
/*     */   
/*     */   public Matrix4f getModelViewMatrix() {
/* 141 */     return this.mModelViewMatrix;
/*     */   }
/*     */   
/*     */   public void setModelViewMatrix(Matrix4f modelViewMatrix) {
/* 145 */     this.mModelViewMatrix = modelViewMatrix;
/*     */   }
/*     */   
/*     */   public Matrix4f getModelMatrix() {
/* 149 */     return this.mModelMatrix;
/*     */   }
/*     */   
/*     */   public void setModelMatrix(Matrix4f modelMatrix) {
/* 153 */     this.mModelMatrix = modelMatrix;
/*     */   }
/*     */   
/*     */   public Matrix3f getNormalMatrix() {
/* 157 */     return this.mNormalMatrix;
/*     */   }
/*     */   
/*     */   public void setNormalMatrix(Matrix3f normalMatrix) {
/* 161 */     this.mNormalMatrix = normalMatrix;
/*     */   }
/*     */   
/*     */   public Vector3f getWorldCameraPosition() {
/* 165 */     return this.mWorldCameraPosition;
/*     */   }
/*     */   
/*     */   public void setWorldCameraPosition(Vector3f worldCameraPosition) {
/* 169 */     this.mWorldCameraPosition = worldCameraPosition;
/*     */   }
/*     */   
/*     */   public Vector3f getLightPosition() {
/* 173 */     return this.mLightPosition;
/*     */   }
/*     */   
/*     */   public void setLightPosition(Vector3f lightPosition) {
/* 177 */     this.mLightPosition.set(lightPosition);
/*     */   }
/*     */   
/*     */   public Matrix4f getModelViewProjectionMatrix() {
/* 181 */     return this.mProjectionMatrix.mult(this.mModelViewMatrix);
/*     */   }
/*     */   
/*     */ 
/*     */   public ARCamera getCamera()
/*     */   {
/* 187 */     return this.mCamera;
/*     */   }
/*     */   
/*     */   public void setCamera(ARCamera camera) {
/* 191 */     this.mCamera = camera;
/*     */   }
/*     */   
/*     */   private void flattenScene(ARNode node, List<ARNode> flatNodes)
/*     */   {
/* 196 */     if (!node.getVisible()) {
/* 197 */       return;
/*     */     }
/* 199 */     flatNodes.add(node);
/* 200 */     for (ARNode child : node.getChildren()) {
/* 201 */       flattenScene(child, flatNodes);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean nearEnough(int a, int b)
/*     */   {
/* 207 */     int distance = 2;
/*     */     
/* 209 */     if (Math.abs(a - b) > 2)
/* 210 */       return false;
/* 211 */     if (Math.abs(b - a) > 2)
/* 212 */       return false;
/* 213 */     return true;
/*     */   }
/*     */   
/*     */   public boolean getRenderForCapture()
/*     */   {
/* 218 */     return this.mRenderForCapture;
/*     */   }
/*     */   
/*     */   public void cameraDraw() {
/* 222 */     GLES20.glBindFramebuffer(36160, this.mCameraFBO);
/*     */   }
/*     */   
/*     */   public void render()
/*     */   {
/* 227 */     this.renderTime = System.currentTimeMillis();
/*     */     Iterator localIterator;
/* 229 */     ARRendererListener listener; synchronized (this.mListeners) {
/* 230 */       for (localIterator = this.mListeners.iterator(); localIterator.hasNext();) { listener = (ARRendererListener)localIterator.next();
/* 231 */         listener.preRender();
/*     */       }
/*     */     }
/*     */     
/* 235 */     Collections.sort(this.mRenderTargets, new Comparator() {
/*     */       public int compare(ARRenderTarget lhs, ARRenderTarget rhs) {
/* 237 */         int a = lhs.getPriority();
/* 238 */         int b = rhs.getPriority();
/*     */         
/* 240 */         return a - b;
/*     */       }
/*     */     });
/*     */     
/*     */ 
/* 245 */     for (ARRenderTarget renderTarget : this.mRenderTargets) {
/* 246 */       renderTarget.draw();
/*     */     }
/*     */     
/* 249 */     synchronized (this.mListeners) {
/* 250 */       for (ARRendererListener listener : this.mListeners) {
/* 251 */         listener.postRender();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void draw() {
/* 257 */     List<ARNode> flatNodes = new ArrayList();
/* 258 */     List<ARNode> occlusionNodes = new ArrayList();
/* 259 */     List<ARNode> opaqueNodes = new ArrayList();
/* 260 */     List<ARNode> translucentNodes = new ArrayList();
/*     */     
/* 262 */     flattenScene(getCamera(), flatNodes);
/*     */     
/* 264 */     for (ARNode node : flatNodes) {
/* 265 */       node.preRender();
/*     */     }
/*     */     
/* 268 */     this.mRenderForCapture = false;
/*     */     
/* 270 */     for (ARNode node : flatNodes) {
/* 271 */       if ((node instanceof ARMeshNode)) {
/* 272 */         ARMeshNode meshNode = (ARMeshNode)node;
/*     */         
/* 274 */         if (meshNode.getMaterial() != null)
/*     */         {
/* 276 */           if (meshNode.getMaterial().getDepthOnly()) {
/* 277 */             occlusionNodes.add(meshNode);
/* 278 */           } else if (!meshNode.getMaterial().getTransparent()) {
/* 279 */             opaqueNodes.add(meshNode);
/* 280 */           } else if (meshNode.getMaterial().getTransparent()) {
/* 281 */             translucentNodes.add(meshNode);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 286 */     for (ARNode node : occlusionNodes) {
/* 287 */       node.render();
/*     */     }
/*     */     
/* 290 */     for (ARNode node : opaqueNodes) {
/* 291 */       node.render();
/*     */     }
/*     */     
/*     */ 
/* 295 */     Collections.sort(translucentNodes, new Comparator() {
/*     */       public int compare(ARNode a, ARNode b) {
/* 297 */         Vector3f centre = new Vector3f(0.0F, 0.0F, 0.0F);
/* 298 */         Vector3f centreA = a.getFullTransform().mult(centre);
/* 299 */         Vector3f centreB = b.getFullTransform().mult(centre);
/*     */         
/* 301 */         float distanceA = centre.distance(centreA);
/* 302 */         float distanceB = centre.distance(centreB);
/*     */         
/* 304 */         if (distanceA > distanceB)
/* 305 */           return -1;
/* 306 */         if (distanceB > distanceA) {
/* 307 */           return 1;
/*     */         }
/* 309 */         return 0;
/*     */       }
/*     */       
/*     */ 
/* 313 */     });
/* 314 */     GLES20.glDisable(2884);
/*     */     
/* 316 */     for (ARNode node : translucentNodes) {
/* 317 */       node.render();
/*     */     }
/*     */     
/* 320 */     GLES20.glEnable(2884);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AssetManager getAssetManager()
/*     */   {
/* 422 */     return this.mAssetManager;
/*     */   }
/*     */   
/*     */   public void setAssetManager(AssetManager assetManager) {
/* 426 */     this.mAssetManager = assetManager;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 430 */     this.mMediaPlayers = new ArrayList();
/* 431 */     this.mVertexBuffers = new ArrayList();
/* 432 */     this.mIndexBuffers = new ArrayList();
/* 433 */     this.mTextures = new ArrayList();
/* 434 */     this.mShaders = new ArrayList();
/* 435 */     this.mRenderTargets = new ArrayList();
/*     */     
/* 437 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/* 438 */     shaderManager.reset();
/* 439 */     this.mActivity = null;
/* 440 */     this.mTouchCoords = null;
/*     */     
/* 442 */     this.mListeners = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 447 */   private ARVideoTexture mActiveVideoTexture = null;
/*     */   private int mCameraFBO;
/*     */   
/* 450 */   public void makeActiveVideoTexture(ARVideoTexture videoTexture) { if (this.mActiveVideoTexture != null) {
/* 451 */       this.mActiveVideoTexture.spill();
/*     */     }
/*     */     
/* 454 */     this.mActiveVideoTexture = videoTexture;
/* 455 */     this.mActiveVideoTexture.open();
/*     */   }
/*     */   
/*     */   public void addMediaPlayer(MediaPlayer mediaPlayer) {
/* 459 */     this.mMediaPlayers.add(mediaPlayer);
/*     */   }
/*     */   
/*     */   public List<MediaPlayer> getMediaPlayers() {
/* 463 */     return this.mMediaPlayers;
/*     */   }
/*     */   
/*     */   public List<ARVertexBuffer> getVertexBuffers() {
/* 467 */     return this.mVertexBuffers;
/*     */   }
/*     */   
/*     */   public List<ARIndexBuffer> getIndexBuffers() {
/* 471 */     return this.mIndexBuffers;
/*     */   }
/*     */   
/*     */   public List<ARTexture> getTextures() {
/* 475 */     return this.mTextures;
/*     */   }
/*     */   
/*     */   public List<ARShaderProgram> getShaders() {
/* 479 */     return this.mShaders;
/*     */   }
/*     */   
/*     */   public void addVertexBuffer(ARVertexBuffer vertexBuffer) {
/* 483 */     this.mVertexBuffers.add(vertexBuffer);
/*     */   }
/*     */   
/*     */   public void addIndexBuffer(ARIndexBuffer indexBuffer) {
/* 487 */     this.mIndexBuffers.add(indexBuffer);
/*     */   }
/*     */   
/*     */   public void addTexture(ARTexture texture) {
/* 491 */     this.mTextures.add(texture);
/*     */   }
/*     */   
/*     */   public void addShader(ARShaderProgram shader) {
/* 495 */     this.mShaders.add(shader);
/*     */   }
/*     */   
/*     */   public void loadContext() {
/* 499 */     for (ARIndexBuffer indexBuffer : this.mIndexBuffers) {
/* 500 */       indexBuffer.loadData();
/*     */     }
/* 502 */     for (ARVertexBuffer vertexBuffer : this.mVertexBuffers) {
/* 503 */       vertexBuffer.loadData();
/*     */     }
/* 505 */     for (ARTexture texture : this.mTextures) {
/* 506 */       texture.loadData();
/*     */     }
/* 508 */     for (ARShaderProgram shader : this.mShaders) {
/* 509 */       shader.compileShaders();
/*     */     }
/* 511 */     for (ARRenderTarget renderTarget : this.mRenderTargets) {
/* 512 */       renderTarget.create();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setupCameraFBO()
/*     */   {
/* 519 */     int[] n = new int[1];
/* 520 */     GLES20.glGenFramebuffers(1, n, 0);
/*     */     
/* 522 */     int fboID = n[0];
/* 523 */     this.mCameraFBO = fboID;
/*     */     
/* 525 */     GLES20.glBindFramebuffer(36160, fboID);
/*     */     
/* 527 */     GLES20.glGenTextures(1, n, 0);
/*     */     
/* 529 */     int textureID = n[0];
/* 530 */     GLES20.glBindTexture(3553, textureID);
/*     */     
/* 532 */     Log.i("CAPTURE", "texture ID: " + textureID);
/*     */     
/* 534 */     GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 535 */     GLES20.glTexParameterf(3553, 10240, 9729.0F);
/* 536 */     GLES20.glTexParameterf(3553, 10243, 33071.0F);
/* 537 */     GLES20.glTexParameterf(3553, 10242, 33071.0F);
/*     */     
/* 539 */     GLES20.glTexImage2D(3553, 0, 6408, (int)this.cameraFBOResolution.getX(), (int)this.cameraFBOResolution.getY(), 0, 6408, 5121, null);
/*     */     
/* 541 */     GLES20.glFramebufferTexture2D(36160, 36064, 3553, textureID, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int mCaptureFBO;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setupCaptureFBO()
/*     */   {
/* 556 */     int[] n = new int[1];
/* 557 */     GLES20.glGenFramebuffers(1, n, 0);
/*     */     
/* 559 */     int fboID = n[0];
/* 560 */     this.mCaptureFBO = fboID;
/*     */     
/* 562 */     GLES20.glBindFramebuffer(36160, fboID);
/*     */     
/* 564 */     GLES20.glGenTextures(1, n, 0);
/*     */     
/* 566 */     int textureID = n[0];
/* 567 */     GLES20.glBindTexture(3553, textureID);
/*     */     
/* 569 */     GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 570 */     GLES20.glTexParameterf(3553, 10240, 9729.0F);
/* 571 */     GLES20.glTexParameterf(3553, 10243, 33071.0F);
/* 572 */     GLES20.glTexParameterf(3553, 10242, 33071.0F);
/*     */     
/* 574 */     GLES20.glTexImage2D(3553, 0, 6408, 1, 1, 0, 6408, 5121, null);
/*     */     
/* 576 */     GLES20.glFramebufferTexture2D(36160, 36064, 3553, textureID, 0);
/*     */     
/*     */ 
/* 579 */     GLES20.glGenRenderbuffers(1, n, 0);
/* 580 */     int depthBuffer = n[0];
/*     */     
/* 582 */     GLES20.glBindRenderbuffer(36161, depthBuffer);
/* 583 */     GLES20.glRenderbufferStorage(36161, 33189, 1, 1);
/*     */     
/* 585 */     GLES20.glFramebufferRenderbuffer(36160, 36096, 36161, depthBuffer);
/*     */   }
/*     */   
/*     */   public void setTouchCoords(Point point) {
/* 589 */     Log.i("AR", "set touch coords");
/* 590 */     this.mTouchCoords = point;
/*     */   }
/*     */   
/*     */ 
/* 594 */   private Vector3f mNextColour = new Vector3f(0.0F, 0.0F, 8.0F);
/*     */   
/* 596 */   public Vector3f getNextCaptureColour() { Vector3f nextColour = new Vector3f(this.mNextColour);
/* 597 */     float r = this.mNextColour.getX();
/* 598 */     float g = this.mNextColour.getY();
/* 599 */     float b = this.mNextColour.getZ();
/*     */     
/* 601 */     b += 8.0F;
/* 602 */     if (b >= 256.0F) {
/* 603 */       b = 0.0F;
/* 604 */       g += 8.0F;
/*     */     }
/*     */     
/* 607 */     if (g >= 256.0F) {
/* 608 */       g = 0.0F;
/* 609 */       r += 8.0F;
/*     */     }
/*     */     
/* 612 */     this.mNextColour.set(r, g, b);
/* 613 */     return nextColour;
/*     */   }
/*     */   
/* 616 */   private boolean[] vertexAttributes = new boolean[10];
/*     */   
/*     */   public void enableVertexAttribute(int n) {
/* 619 */     if (this.vertexAttributes[n] != 0) {
/* 620 */       return;
/*     */     }
/* 622 */     GLES20.glEnableVertexAttribArray(n);
/* 623 */     this.vertexAttributes[n] = true;
/*     */   }
/*     */   
/*     */   public void disableVertexAttribute(int n) {
/* 627 */     if (this.vertexAttributes[n] == 0) {
/* 628 */       return;
/*     */     }
/* 630 */     GLES20.glDisableVertexAttribArray(n);
/* 631 */     this.vertexAttributes[n] = false;
/*     */   }
/*     */   
/*     */   public void pause()
/*     */   {
/* 636 */     for (ARRendererListener listener : this.mListeners) {
/* 637 */       listener.rendererDidPause();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void addListener(ARRendererListener listener) {
/* 642 */     this.mListeners.add(listener);
/*     */   }
/*     */   
/*     */   public synchronized void removeListener(ARRendererListener listener) {
/* 646 */     this.mListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void resume() {
/* 650 */     for (ARRendererListener listener : this.mListeners) {
/* 651 */       listener.rendererDidResume();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */