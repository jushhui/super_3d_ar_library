/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class ModelNode
/*    */ {
/*    */   public int nodeID;
/*    */   public String name;
/*    */   public int numberOfChildren;
/*    */   public int numberOfMeshes;
/* 11 */   public float[] transform = new float[16];
/*    */   
/* 13 */   public List<Integer> childrenList = new java.util.ArrayList();
/* 14 */   public List<Integer> meshList = new java.util.ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addChild(int childNo)
/*    */   {
/* 21 */     this.childrenList.add(Integer.valueOf(childNo));
/*    */   }
/*    */   
/*    */   public void addMesh(int meshNo) {
/* 25 */     this.meshList.add(Integer.valueOf(meshNo));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ModelNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */