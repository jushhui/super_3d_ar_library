/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.opengl.GLES20;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class ARRenderTarget
/*     */ {
/*     */   private ARCamera mCamera;
/*     */   protected int mFramebufferID;
/*  14 */   private boolean mShouldClear = true;
/*  15 */   private boolean mShouldClearDepth = true;
/*     */   
/*     */   private int mPriority;
/*  18 */   private List<ARViewPort> mViewPorts = new ArrayList();
/*     */   
/*     */   public ARRenderTarget() {
/*  21 */     this.mCamera = new ARCamera();
/*     */     
/*  23 */     ARRenderer renderer = ARRenderer.getInstance();
/*  24 */     renderer.addRenderTarget(this);
/*     */   }
/*     */   
/*     */   public void setPriority(int priority) {
/*  28 */     this.mPriority = priority;
/*     */   }
/*     */   
/*     */   public int getPriority() {
/*  32 */     return this.mPriority;
/*     */   }
/*     */   
/*     */   public void setShouldClear(boolean shouldClear) {
/*  36 */     this.mShouldClear = shouldClear;
/*     */   }
/*     */   
/*     */   public boolean getShouldClear() {
/*  40 */     return this.mShouldClear;
/*     */   }
/*     */   
/*     */   public void setShouldClearDepth(boolean shouldClearDepth) {
/*  44 */     this.mShouldClearDepth = shouldClearDepth;
/*     */   }
/*     */   
/*     */   public boolean getShouldClearDepth() {
/*  48 */     return this.mShouldClearDepth;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  52 */     int flags = 0;
/*  53 */     if (this.mShouldClear) {
/*  54 */       flags |= 0x4000;
/*     */     }
/*  56 */     if (this.mShouldClearDepth) {
/*  57 */       GLES20.glDepthMask(true);
/*  58 */       flags |= 0x100;
/*     */     }
/*  60 */     if (flags != 0) {
/*  61 */       GLES20.glClear(flags);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCamera(ARCamera camera) {
/*  66 */     this.mCamera = camera;
/*     */   }
/*     */   
/*     */   public ARCamera getCamera() {
/*  70 */     return this.mCamera;
/*     */   }
/*     */   
/*     */ 
/*     */   public void create() {}
/*     */   
/*     */ 
/*     */   public void bind()
/*     */   {
/*  79 */     GLES20.glBindFramebuffer(36160, 0);
/*     */   }
/*     */   
/*     */   public void draw() {
/*  83 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/*  85 */     bind();
/*  86 */     clear();
/*     */     
/*  88 */     if (this.mCamera == null) {
/*  89 */       return;
/*     */     }
/*     */     
/*     */ 
/*  93 */     Collections.sort(this.mViewPorts, new Comparator() {
/*     */       public int compare(ARViewPort lhs, ARViewPort rhs) {
/*  95 */         int a = lhs.getZOrder();
/*  96 */         int b = rhs.getZOrder();
/*     */         
/*  98 */         return a - b;
/*     */       }
/*     */     });
/*     */     
/*     */ 
/* 103 */     for (ARViewPort viewPort : this.mViewPorts) {
/* 104 */       ARCamera camera = viewPort.getCamera();
/* 105 */       if (camera != null)
/*     */       {
/*     */ 
/* 108 */         GLES20.glViewport(viewPort.getOffsetX(), viewPort.getOffsetY(), viewPort.getWidth(), viewPort.getHeight());
/*     */         
/* 110 */         renderer.setCamera(camera);
/* 111 */         renderer.setProjectionMatrix(camera.getProjectionMatrix());
/* 112 */         renderer.draw();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 117 */   public List<ARViewPort> getViewPorts() { return this.mViewPorts; }
/*     */   
/*     */   public void addViewPort(ARViewPort viewPort)
/*     */   {
/* 121 */     this.mViewPorts.add(viewPort);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARRenderTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */