/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.content.res.AssetFileDescriptor;
/*    */ import android.opengl.GLES20;
/*    */ import java.io.FileDescriptor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ARTexture3D extends ARTexture
/*    */ {
/* 11 */   private List<String> mFaceAssets = new ArrayList();
/*    */   
/*    */ 
/*    */   public ARTexture3D(String posX, String negX, String posY, String negY, String posZ, String negZ)
/*    */   {
/* 16 */     this.mFaceAssets.add(posX);
/* 17 */     this.mFaceAssets.add(negX);
/* 18 */     this.mFaceAssets.add(posY);
/* 19 */     this.mFaceAssets.add(negY);
/* 20 */     this.mFaceAssets.add(posZ);
/* 21 */     this.mFaceAssets.add(negZ);
/*    */   }
/*    */   
/*    */   public void bindTexture(int unit) {
/* 25 */     int texUnit = 33984;
/* 26 */     if (unit == 1) {
/* 27 */       texUnit = 33985;
/*    */     }
/* 29 */     GLES20.glActiveTexture(texUnit);
/* 30 */     GLES20.glBindTexture(34067, this.mTextureID);
/*    */   }
/*    */   
/*    */   private native void loadDataN(FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/* 35 */   public void loadData() { createTexture();
/* 36 */     bindTexture(0);
/*    */     
/* 38 */     for (int i = 0; i < 6; i++) {
/* 39 */       String assetName = (String)this.mFaceAssets.get(i);
/*    */       
/* 41 */       int[] faces = {
/* 42 */         34069, 
/* 43 */         34070, 
/* 44 */         34071, 
/* 45 */         34072, 
/* 46 */         34073, 
/* 47 */         34074 };
/*    */       
/* 49 */       int face = faces[i];
/*    */       try
/*    */       {
/* 52 */         ARRenderer renderer = ARRenderer.getInstance();
/* 53 */         AssetFileDescriptor fd = renderer.getAssetManager().openFd(assetName);
/* 54 */         loadDataN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength(), face);
/* 55 */         fd.close();
/*    */       } catch (Exception e) {
/* 57 */         e.printStackTrace();
/* 58 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void prepareRenderer(int unit)
/*    */   {
/* 66 */     bindTexture(unit);
/* 67 */     GLES20.glTexParameterf(34067, 10241, 9729.0F);
/* 68 */     GLES20.glTexParameterf(34067, 10240, 9729.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTexture3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */