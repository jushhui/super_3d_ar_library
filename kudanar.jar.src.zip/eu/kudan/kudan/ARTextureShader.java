/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARTextureShader
/*    */   extends ARShaderProgram
/*    */ {
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nvoid main()\n{\n    uvCoord = vertexUV;\n    uvCoordMask.x = uvCoord.x + 0.5;\n    uvCoordMask.y = uvCoord.y;\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static final String fragmentString = "precision mediump float;\nuniform vec3 colour;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nuniform sampler2D uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    gl_FragColor = col;\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ARTextureShader()
/*    */   {
/* 35 */     setShaderStrings("attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nvoid main()\n{\n    uvCoord = vertexUV;\n    uvCoordMask.x = uvCoord.x + 0.5;\n    uvCoordMask.y = uvCoord.y;\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}", "precision mediump float;\nuniform vec3 colour;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nuniform sampler2D uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    gl_FragColor = col;\n}");
/*    */   }
/*    */   
/*    */   public static ARTextureShader getShader() {
/* 39 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 41 */     boolean[] properties = { true };
/*    */     
/* 43 */     ARTextureShader shader = (ARTextureShader)shaderManager.findShader(ARTextureShader.class, properties);
/* 44 */     if (shader != null)
/*    */     {
/* 46 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 50 */     shader = new ARTextureShader();
/*    */     
/* 52 */     shaderManager.addShader(shader, properties);
/*    */     
/* 54 */     ARRenderer renderer = ARRenderer.getInstance();
/* 55 */     renderer.addShader(shader);
/*    */     
/* 57 */     return shader;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTextureShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */