/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARArbiTrack
/*     */ {
/*     */   private static ARArbiTrack arbiTrack;
/*  11 */   private ARWorld mWorld = new ARWorld();
/*  12 */   private ARNode mTargetNode = new ARNode();
/*     */   private boolean mIsTracking;
/*     */   private boolean mIsInitialised;
/*     */   
/*     */   public static ARArbiTrack getInstance() {
/*  17 */     if (arbiTrack == null) {
/*  18 */       arbiTrack = new ARArbiTrack();
/*     */     }
/*     */     
/*  21 */     return arbiTrack;
/*     */   }
/*     */   
/*     */   private native void processFrameN(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */   
/*     */   void processFrame(byte[] cameraImage, int width, int height)
/*     */   {
/*  28 */     if (!this.mIsInitialised) {
/*  29 */       return;
/*     */     }
/*  31 */     this.mWorld.setOrientation(ARGyroManager.getInstance().getWorld().getOrientation());
/*  32 */     processFrameN(cameraImage, width, height);
/*     */   }
/*     */   
/*     */   private native void initN();
/*     */   
/*     */   public void initialise() {
/*  38 */     initN();
/*  39 */     ARGyroManager.getInstance().initialise();
/*  40 */     this.mWorld.setVisible(false);
/*  41 */     ARRenderer.getInstance().getActivity().getARView().getContentViewPort().getCamera().addChild(this.mWorld);
/*  42 */     this.mIsInitialised = true;
/*     */   }
/*     */   
/*     */   private native void destroyN();
/*     */   
/*     */   private native void deinitialiseN();
/*     */   
/*  49 */   public void deinitialise() { stop();
/*  50 */     deinitialiseN();
/*  51 */     destroyN();
/*  52 */     this.mTargetNode = new ARNode();
/*  53 */     this.mWorld = new ARWorld();
/*  54 */     this.mIsTracking = false;
/*  55 */     this.mIsInitialised = false;
/*     */   }
/*     */   
/*     */   public void setTargetNode(ARNode node)
/*     */   {
/*  60 */     this.mTargetNode = node;
/*     */   }
/*     */   
/*     */   public ARNode getTargetNode()
/*     */   {
/*  65 */     return this.mTargetNode;
/*     */   }
/*     */   
/*     */   public ARWorld getWorld()
/*     */   {
/*  70 */     return this.mWorld;
/*     */   }
/*     */   
/*     */   public boolean getIsTracking()
/*     */   {
/*  75 */     return this.mIsTracking;
/*     */   }
/*     */   
/*     */   private native void startN(float[] paramArrayOfFloat);
/*     */   
/*     */   public void start() {
/*  81 */     Matrix4f fullTransform = this.mTargetNode.getFullTransform();
/*     */     
/*  83 */     float[] transform = new float[16];
/*  84 */     fullTransform.get(transform, false);
/*     */     
/*  86 */     startN(transform);
/*  87 */     ARGyroManager.getInstance().start();
/*  88 */     this.mWorld.setVisible(true);
/*  89 */     this.mIsTracking = true;
/*     */   }
/*     */   
/*     */   private native void stopN();
/*     */   
/*     */   public void stop() {
/*  95 */     stopN();
/*  96 */     this.mWorld.setVisible(false);
/*  97 */     this.mIsTracking = false;
/*     */   }
/*     */   
/*     */   private void setWorldPosition(float x, float y, float z)
/*     */   {
/* 102 */     this.mWorld.setPosition(-x, -y, z);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARArbiTrack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */