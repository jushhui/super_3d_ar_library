/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARCameraTextureShader
/*    */   extends ARShaderProgram
/*    */ {
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nuniform mat4 uvTransform;\nvarying vec2 uvCoord;\nvoid main()\n{\n    vec4 uv = vec4(vertexUV.x, vertexUV.y, 0, 1.0);\n    uv = uvTransform * uv;\n    uvCoord = vec2(uv.x, uv.y);\n    gl_Position = vertexPosition;\n}";
/*    */   static final String fragmentString = "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nvarying vec2 uvCoord;\nuniform samplerExternalOES uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    gl_FragColor = col;\n}";
/*    */   
/*    */   public ARCameraTextureShader()
/*    */   {
/* 34 */     setShaderStrings("attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nuniform mat4 uvTransform;\nvarying vec2 uvCoord;\nvoid main()\n{\n    vec4 uv = vec4(vertexUV.x, vertexUV.y, 0, 1.0);\n    uv = uvTransform * uv;\n    uvCoord = vec2(uv.x, uv.y);\n    gl_Position = vertexPosition;\n}", "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nvarying vec2 uvCoord;\nuniform samplerExternalOES uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    gl_FragColor = col;\n}");
/*    */   }
/*    */   
/*    */   public static ARCameraTextureShader getShader() {
/* 38 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 40 */     boolean[] properties = { true };
/*    */     
/* 42 */     ARCameraTextureShader shader = (ARCameraTextureShader)shaderManager.findShader(ARCameraTextureShader.class, properties);
/* 43 */     if (shader != null)
/*    */     {
/* 45 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 49 */     shader = new ARCameraTextureShader();
/*    */     
/* 51 */     shaderManager.addShader(shader, properties);
/*    */     
/* 53 */     ARRenderer renderer = ARRenderer.getInstance();
/* 54 */     renderer.addShader(shader);
/*    */     
/* 56 */     return shader;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 61 */     int uvTransformHandle = GLES20.glGetUniformLocation(this.mShaderID, "uvTransform");
/* 62 */     if (uvTransformHandle >= 0) {
/* 63 */       GLES20.glUniformMatrix4fv(uvTransformHandle, 1, false, uvTransform, 0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCameraTextureShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */