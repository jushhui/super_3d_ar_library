/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.jme3.math.Vector3f;
/*    */ 
/*    */ public class ARColourMaterial extends ARMaterial
/*    */ {
/*    */   private ARColourShader mShader;
/*    */   private Vector3f mColour;
/*    */   
/*    */   public ARColourMaterial() {
/* 11 */     this.mShader = ARColourShader.getShader();
/*    */   }
/*    */   
/*    */   public ARColourMaterial(Vector3f colour) {
/* 15 */     this();
/* 16 */     this.mColour = colour;
/*    */   }
/*    */   
/*    */   public void setColour(Vector3f colour) {
/* 20 */     this.mColour = colour;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node) {
/* 24 */     boolean b = super.prepareRendererWithNode(node);
/* 25 */     if (!b) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     this.mShader.prepareRenderer();
/* 30 */     this.mShader.setColour(this.mColour);
/* 31 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARColourMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */