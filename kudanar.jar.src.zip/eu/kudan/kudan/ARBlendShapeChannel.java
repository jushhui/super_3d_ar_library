/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.util.Log;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ARBlendShapeChannel
/*    */ {
/*    */   private int mNativeMem;
/* 10 */   private List<ARBlendShape> mBlendShapes = new ArrayList();
/*    */   private float mInfluence;
/*    */   
/*    */   public ARBlendShapeChannel(int nativeMem) {
/* 14 */     this.mNativeMem = nativeMem;
/*    */   }
/*    */   
/*    */   public void addShape(ARBlendShape shape) {
/* 18 */     this.mBlendShapes.add(shape);
/*    */   }
/*    */   
/*    */   public void setInfluence(float influence) {
/* 22 */     this.mInfluence = influence;
/*    */     
/* 24 */     Log.i("AR", "influence set to " + influence);
/*    */   }
/*    */   
/*    */   public float getInfluence() {
/* 28 */     return this.mInfluence;
/*    */   }
/*    */   
/*    */   public List<ARBlendShape> getShapes() {
/* 32 */     return this.mBlendShapes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARBlendShapeChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */