/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARCameraTextureMaterial extends ARMaterial
/*    */ {
/*    */   private ARTexture mTexture;
/*    */   private ARCameraTextureShader mShader;
/*    */   private float[] mUVTransform;
/*    */   
/*    */   public ARCameraTextureMaterial()
/*    */   {
/* 11 */     this.mShader = ARCameraTextureShader.getShader();
/*    */   }
/*    */   
/*    */   public ARCameraTextureMaterial(ARTexture texture) {
/* 15 */     this();
/* 16 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node)
/*    */   {
/* 21 */     boolean b = super.prepareRendererWithNode(node);
/* 22 */     if (!b) {
/* 23 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 27 */     this.mShader.prepareRenderer();
/* 28 */     this.mShader.setUVTransform(this.mUVTransform);
/*    */     
/* 30 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 38 */     this.mUVTransform = uvTransform;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCameraTextureMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */