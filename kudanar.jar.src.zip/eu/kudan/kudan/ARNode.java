/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Quaternion;
/*     */ import com.jme3.math.Vector3f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ARNode
/*     */ {
/*  11 */   private ARNode mParent = null;
/*  12 */   private List<ARNode> mChildren = new ArrayList();
/*  13 */   private Vector3f mPosition = new Vector3f(0.0F, 0.0F, 0.0F);
/*  14 */   private Quaternion mOrientation = new Quaternion();
/*  15 */   private Vector3f mScale = new Vector3f(1.0F, 1.0F, 1.0F);
/*     */   
/*  17 */   private Matrix4f mLocalTransform = new Matrix4f();
/*  18 */   private Matrix4f mFullTransform = new Matrix4f();
/*  19 */   private Matrix4f mWorldTransform = new Matrix4f();
/*     */   
/*  21 */   private Quaternion mWorldOrientation = new Quaternion();
/*  22 */   private Vector3f mWorldScale = new Vector3f();
/*     */   
/*  24 */   private Quaternion mFullOrientation = new Quaternion();
/*  25 */   private Vector3f mFullScale = new Vector3f();
/*     */   
/*  27 */   private boolean mWorldTransformIsDirty = true;
/*  28 */   private boolean mLocalTransformIsDirty = true;
/*     */   
/*  30 */   private boolean mIsVisible = true;
/*     */   
/*  32 */   private String mName = this;
/*     */   
/*  34 */   private Quaternion mQuaternionTmp = new Quaternion();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void markLocalTransformAsDirty()
/*     */   {
/*  41 */     this.mLocalTransformIsDirty = true;
/*  42 */     markWorldTranformAsDirty();
/*     */   }
/*     */   
/*     */   private void updateLocalTransform() {
/*  46 */     if (!this.mLocalTransformIsDirty)
/*     */     {
/*  48 */       return;
/*     */     }
/*     */     
/*  51 */     com.jme3.math.Matrix3f rotation = this.mOrientation.toRotationMatrix();
/*  52 */     this.mLocalTransform.setTransform(this.mPosition, this.mScale, rotation);
/*  53 */     this.mLocalTransformIsDirty = false;
/*     */   }
/*     */   
/*     */   private void updateWorldTransform() {
/*  57 */     if (!this.mWorldTransformIsDirty)
/*     */     {
/*  59 */       return;
/*     */     }
/*     */     
/*  62 */     if ((this.mParent == null) || ((this.mParent instanceof ARWorld)))
/*     */     {
/*  64 */       this.mWorldTransform.set(Matrix4f.IDENTITY);
/*  65 */       this.mWorldOrientation.set(Quaternion.IDENTITY);
/*  66 */       this.mWorldScale.set(1.0F, 1.0F, 1.0F);
/*     */     } else {
/*  68 */       this.mWorldTransform.set(this.mParent.getWorldTransform());
/*  69 */       this.mWorldOrientation.set(this.mParent.getWorldOrientation());
/*  70 */       this.mWorldScale.set(this.mParent.getWorldScale());
/*     */     }
/*     */     
/*  73 */     this.mWorldOrientation.multLocal(getOrientation());
/*  74 */     this.mWorldScale.multLocal(getScale());
/*  75 */     this.mWorldTransform.multLocal(getLocalTransform());
/*     */     
/*     */ 
/*     */ 
/*  79 */     if (getWorld() != this) {
/*  80 */       this.mFullTransform.set(getWorld().getWorldTransform());
/*     */     } else {
/*  82 */       this.mFullTransform.set(Matrix4f.IDENTITY);
/*     */     }
/*  84 */     this.mFullTransform.multLocal(this.mWorldTransform);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */     this.mWorldTransformIsDirty = false;
/*     */   }
/*     */   
/*     */   private void markWorldTranformAsDirty() {
/*  96 */     this.mWorldTransformIsDirty = true;
/*  97 */     for (ARNode child : this.mChildren) {
/*  98 */       child.markWorldTranformAsDirty();
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove() {
/* 103 */     if (this.mParent == null) {
/* 104 */       return;
/*     */     }
/* 106 */     this.mParent.mChildren.remove(this);
/* 107 */     setParent(null);
/*     */   }
/*     */   
/*     */   public void removeAllChildren()
/*     */   {
/* 112 */     for (ARNode child : this.mChildren) {
/* 113 */       child.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addChild(ARNode child)
/*     */   {
/* 119 */     child.remove();
/* 120 */     this.mChildren.add(child);
/* 121 */     child.setParent(this);
/*     */   }
/*     */   
/*     */   public ARNode getParent() {
/* 125 */     return this.mParent;
/*     */   }
/*     */   
/*     */   public void setParent(ARNode parent) {
/* 129 */     this.mParent = parent;
/* 130 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public List<ARNode> getChildren() {
/* 134 */     return this.mChildren;
/*     */   }
/*     */   
/*     */   public ARNode getWorld() {
/* 138 */     ARNode world = this;
/* 139 */     while (world.getParent() != null) {
/* 140 */       world = world.getParent();
/* 141 */       if ((world instanceof ARWorld)) {
/*     */         break;
/*     */       }
/*     */     }
/* 145 */     return world;
/*     */   }
/*     */   
/*     */   public Vector3f getPosition() {
/* 149 */     return this.mPosition;
/*     */   }
/*     */   
/*     */   public void setPosition(Vector3f position)
/*     */   {
/* 154 */     this.mPosition.set(position);
/* 155 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void setPosition(float x, float y, float z) {
/* 159 */     this.mPosition.setX(x);
/* 160 */     this.mPosition.setY(y);
/* 161 */     this.mPosition.setZ(z);
/* 162 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void translateBy(float x, float y, float z) {
/* 166 */     Vector3f translation = new Vector3f(x, y, z);
/* 167 */     Vector3f delta = this.mOrientation.mult(translation);
/* 168 */     delta.multLocal(getScale());
/* 169 */     this.mPosition.addLocal(delta);
/*     */     
/* 171 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void scaleBy(float x, float y, float z) {
/* 175 */     Vector3f scale = new Vector3f(x, y, z);
/* 176 */     this.mScale.multLocal(scale);
/*     */     
/* 178 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public Vector3f getScale() {
/* 182 */     return this.mScale;
/*     */   }
/*     */   
/*     */   public void setScale(Vector3f scale) {
/* 186 */     this.mScale = scale;
/* 187 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void setScale(float x, float y, float z) {
/* 191 */     this.mScale.set(x, y, z);
/* 192 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void scaleByUniform(float scale) {
/* 196 */     scaleBy(scale, scale, scale);
/*     */   }
/*     */   
/*     */   public Quaternion getOrientation() {
/* 200 */     return this.mOrientation;
/*     */   }
/*     */   
/*     */   public void setOrientation(Quaternion orientation) {
/* 204 */     this.mOrientation.set(orientation);
/* 205 */     this.mOrientation.normalizeLocal();
/* 206 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void setOrientation(float x, float y, float z, float w) {
/* 210 */     this.mOrientation.set(x, y, z, w);
/* 211 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void rotateByQuaternion(Quaternion quaternion) {
/* 215 */     quaternion.normalizeLocal();
/* 216 */     this.mOrientation.multLocal(quaternion);
/* 217 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public void rotateByDegrees(float angle, float x, float y, float z) {
/* 221 */     this.mQuaternionTmp.fromAngleAxis(angle * 0.017453292F, new Vector3f(x, y, z));
/*     */     
/* 223 */     rotateByQuaternion(this.mQuaternionTmp);
/* 224 */     markLocalTransformAsDirty();
/*     */   }
/*     */   
/*     */   public Matrix4f getFullTransform() {
/* 228 */     updateLocalTransform();
/* 229 */     updateWorldTransform();
/* 230 */     return this.mFullTransform;
/*     */   }
/*     */   
/*     */   public Quaternion getFullOrientation() {
/* 234 */     updateLocalTransform();
/* 235 */     updateWorldTransform();
/*     */     
/* 237 */     this.mFullOrientation.set(getWorld().getWorldOrientation());
/* 238 */     this.mFullOrientation.multLocal(getWorldOrientation());
/*     */     
/* 240 */     return this.mFullOrientation;
/*     */   }
/*     */   
/*     */   public Matrix4f getLocalTransform() {
/* 244 */     updateLocalTransform();
/* 245 */     return this.mLocalTransform;
/*     */   }
/*     */   
/*     */   public Matrix4f getWorldTransform() {
/* 249 */     updateWorldTransform();
/* 250 */     return this.mWorldTransform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void render() {}
/*     */   
/*     */ 
/*     */   public boolean getVisible()
/*     */   {
/* 260 */     return this.mIsVisible;
/*     */   }
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 264 */     this.mIsVisible = visible;
/*     */   }
/*     */   
/*     */   public Quaternion getWorldOrientation() {
/* 268 */     updateWorldTransform();
/* 269 */     return this.mWorldOrientation;
/*     */   }
/*     */   
/*     */   public Vector3f getWorldScale() {
/* 273 */     updateWorldTransform();
/* 274 */     return this.mWorldScale;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 278 */     return this.mName;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 282 */     this.mName = name;
/*     */   }
/*     */   
/*     */   public void preRender() {}
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */