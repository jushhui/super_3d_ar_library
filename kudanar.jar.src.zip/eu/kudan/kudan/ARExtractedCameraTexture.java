/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Vector3f;
/*     */ 
/*     */ public class ARExtractedCameraTexture extends ARRenderTargetTexture implements ARRendererListener
/*     */ {
/*     */   private ARNode mOffsetNode;
/*     */   private ARNode mSrcNode;
/*     */   private float mSrcWidth;
/*     */   private float mSrcHeight;
/*     */   private ARCameraBackgroundMaterial mCameraBackgroundMaterial;
/*     */   
/*     */   public void setSrcWidth(float srcWidth)
/*     */   {
/*  16 */     this.mSrcWidth = srcWidth;
/*  17 */     updateOffsetNode();
/*     */   }
/*     */   
/*     */   public void setSrcHeight(float srcHeight) {
/*  21 */     this.mSrcHeight = srcHeight;
/*  22 */     updateOffsetNode();
/*     */   }
/*     */   
/*     */   public void setSrcNode(ARNode node) {
/*  26 */     this.mSrcNode = node;
/*     */   }
/*     */   
/*     */   public ARNode getSrcNode() {
/*  30 */     return this.mSrcNode;
/*     */   }
/*     */   
/*     */   private void updateOffsetNode() {
/*  34 */     Vector3f position = this.mOffsetNode.getPosition();
/*     */     
/*  36 */     position.setX(-this.mSrcWidth / 2.0F);
/*  37 */     position.setY(-this.mSrcHeight / 2.0F);
/*     */     
/*  39 */     this.mOffsetNode.setPosition(position);
/*     */     
/*  41 */     Vector3f scale = this.mOffsetNode.getScale();
/*     */     
/*  43 */     float scaleFactorX = this.mSrcWidth / getWidth();
/*  44 */     float scaleFactorY = this.mSrcHeight / getHeight();
/*     */     
/*  46 */     scale.setX(scaleFactorX);
/*  47 */     scale.setY(scaleFactorY);
/*     */     
/*  49 */     android.util.Log.i("AR", "scale: " + scale);
/*  50 */     android.util.Log.i("AR", "position: " + position);
/*  51 */     android.util.Log.i("AR", "blah: " + this.mSrcWidth + " " + getWidth());
/*     */     
/*  53 */     this.mOffsetNode.setScale(scale);
/*     */   }
/*     */   
/*     */   private void setupOffscreen() {
/*  57 */     this.mOffsetNode = new ARNode();
/*     */     
/*  59 */     updateOffsetNode();
/*     */     
/*     */ 
/*  62 */     setPriority(-100);
/*     */     
/*     */ 
/*     */ 
/*  66 */     ARViewPort viewPort = new ARViewPort(0, 0, getWidth(), getHeight());
/*  67 */     addViewPort(viewPort);
/*     */     
/*  69 */     viewPort.getCamera().setProjectionMatrix(new Matrix4f());
/*     */     
/*  71 */     ARMesh mesh = new ARMesh();
/*  72 */     mesh.createTestMeshWithUvs(2.0F, 2.0F, 0.0F, 1.0F, 0.0F, 1.0F);
/*     */     
/*  74 */     ARMeshNode cameraMeshNode = new ARMeshNode();
/*  75 */     cameraMeshNode.setMesh(mesh);
/*     */     
/*  77 */     ARCameraStream stream = ARCameraStream.getInstance();
/*     */     
/*  79 */     ARCameraBackgroundMaterial camMaterial = new ARCameraBackgroundMaterial();
/*     */     
/*  81 */     camMaterial.setTexture(stream.getTexture());
/*  82 */     cameraMeshNode.setMaterial(camMaterial);
/*     */     
/*  84 */     this.mCameraBackgroundMaterial = camMaterial;
/*     */     
/*  86 */     viewPort.getCamera().addChild(cameraMeshNode);
/*     */     
/*  88 */     ARRenderer renderer = ARRenderer.getInstance();
/*  89 */     renderer.addListener(this);
/*     */   }
/*     */   
/*     */   public ARExtractedCameraTexture(int width, int height) {
/*  93 */     super(width, height);
/*  94 */     setupOffscreen();
/*     */   }
/*     */   
/*     */   public void preRender()
/*     */   {
/*  99 */     Matrix4f projectionMatrix = new Matrix4f(546.0F, 546.0F, 320.0F, 240.0F);
/* 100 */     this.mSrcNode.addChild(this.mOffsetNode);
/*     */     
/* 102 */     Matrix4f modelView = this.mOffsetNode.getFullTransform();
/* 103 */     this.mOffsetNode.remove();
/*     */     
/* 105 */     projectionMatrix = projectionMatrix.mult(modelView);
/* 106 */     this.mCameraBackgroundMaterial.setMarkerModelViewProjection(projectionMatrix);
/*     */     
/* 108 */     Vector3f v1 = new Vector3f(0.0F, 0.0F, 1.0F);
/* 109 */     v1 = projectionMatrix.mult(v1);
/* 110 */     v1.x /= v1.z;
/* 111 */     v1.y /= v1.z;
/*     */     
/* 113 */     Vector3f v2 = new Vector3f(100.0F, 100.0F, 1.0F);
/* 114 */     v2 = projectionMatrix.mult(v2);
/* 115 */     v2.x /= v2.z;
/* 116 */     v2.y /= v2.z;
/*     */   }
/*     */   
/*     */   public void postRender() {}
/*     */   
/*     */   public void rendererDidPause() {}
/*     */   
/*     */   public void rendererDidResume() {}
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARExtractedCameraTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */