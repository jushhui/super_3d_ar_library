package eu.kudan.kudan;

public abstract interface ARVideoTextureListener
{
  public abstract void videoDidFinish(ARVideoTexture paramARVideoTexture);
}


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARVideoTextureListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */