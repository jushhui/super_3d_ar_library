/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.jme3.math.Matrix4f;
/*    */ 
/*    */ public class ARCamera
/*    */   extends ARNode
/*    */ {
/*    */   private Matrix4f mProjectionMatrix;
/*    */   
/*    */   public void setProjectionMatrix(Matrix4f projection)
/*    */   {
/* 12 */     this.mProjectionMatrix = projection;
/*    */   }
/*    */   
/*    */   public Matrix4f getProjectionMatrix() {
/* 16 */     return this.mProjectionMatrix;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCamera.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */