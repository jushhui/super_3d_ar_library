/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.app.Activity;
/*    */ import android.app.FragmentManager;
/*    */ import android.app.FragmentTransaction;
/*    */ import android.os.Bundle;
/*    */ import android.view.Display;
/*    */ import android.view.Window;
/*    */ import android.view.WindowManager;
/*    */ 
/*    */ public class ARActivity
/*    */   extends Activity
/*    */ {
/*    */   private static final String TAG_AR_FRAGMENT = "ar_fragment";
/*    */   private ARFragment mARFragment;
/*    */   
/*    */   protected void onCreate(Bundle savedInstanceState)
/*    */   {
/* 19 */     super.onCreate(savedInstanceState);
/*    */     
/* 21 */     FragmentManager fm = getFragmentManager();
/* 22 */     this.mARFragment = ((ARFragment)fm.findFragmentByTag("ar_fragment"));
/*    */     
/* 24 */     if (this.mARFragment == null) {
/* 25 */       this.mARFragment = new ARFragment();
/* 26 */       fm.beginTransaction().add(this.mARFragment, "ar_fragment").commit();
/*    */     }
/*    */     
/* 29 */     getWindow().addFlags(128);
/*    */   }
/*    */   
/*    */   public int getRotation()
/*    */   {
/* 34 */     Display display = ((WindowManager)getSystemService("window")).getDefaultDisplay();
/*    */     
/* 36 */     return display.getRotation();
/*    */   }
/*    */   
/*    */ 
/*    */   public void setup() {}
/*    */   
/*    */ 
/*    */   public ARView getARView()
/*    */   {
/* 45 */     return this.mARFragment.getARView();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */