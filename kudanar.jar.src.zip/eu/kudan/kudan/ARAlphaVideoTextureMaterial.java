/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.graphics.SurfaceTexture;
/*    */ 
/*    */ public class ARAlphaVideoTextureMaterial extends ARMaterial
/*    */ {
/*    */   private ARTextureOES mTexture;
/*    */   private ARAlphaVideoTextureShader mShader;
/*    */   private float[] mUVTransform;
/*    */   
/*    */   public ARAlphaVideoTextureMaterial()
/*    */   {
/* 13 */     this.mUVTransform = new float[16];
/* 14 */     this.mShader = ARAlphaVideoTextureShader.getShader();
/*    */   }
/*    */   
/*    */   public ARAlphaVideoTextureMaterial(ARTextureOES texture) {
/* 18 */     this();
/* 19 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public void setTexture(ARTextureOES newTexture) {
/* 23 */     this.mTexture = newTexture;
/*    */   }
/*    */   
/*    */   public ARTextureOES getTexture() {
/* 27 */     return this.mTexture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node) {
/* 31 */     boolean b = super.prepareRendererWithNode(node);
/* 32 */     if (!b) {
/* 33 */       return false;
/*    */     }
/*    */     
/* 36 */     if (this.mTexture.getSurfaceTexture() != null) {
/* 37 */       this.mTexture.getSurfaceTexture().getTransformMatrix(this.mUVTransform);
/*    */     }
/*    */     
/* 40 */     this.mShader.prepareRenderer();
/*    */     
/*    */ 
/*    */ 
/* 44 */     this.mShader.setUVTransform(this.mUVTransform);
/*    */     
/* 46 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 49 */     return true;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 54 */     this.mUVTransform = uvTransform;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARAlphaVideoTextureMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */