/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.content.res.AssetFileDescriptor;
/*    */ 
/*    */ public class ARTexture2D extends ARTexture
/*    */ {
/*    */   private String mAssetName;
/*    */   private int mNativeMem;
/*    */   
/*    */   private native void loadFromAssetN(java.io.FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*    */   
/*    */   private native void loadFromPathN(String paramString);
/*    */   
/*    */   public void loadFromAsset(String assetName)
/*    */   {
/*    */     try {
/* 17 */       ARRenderer renderer = ARRenderer.getInstance();
/* 18 */       AssetFileDescriptor fd = renderer.getAssetManager().openFd(assetName);
/* 19 */       loadFromAssetN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength());
/* 20 */       fd.close();
/*    */     }
/*    */     catch (Exception e) {
/* 23 */       e.printStackTrace();
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     this.mAssetName = assetName;
/*    */   }
/*    */   
/*    */ 
/*    */   public void loadFromPath(String path) {}
/*    */   
/*    */ 
/*    */   public ARTexture2D(int textureID)
/*    */   {
/* 36 */     this.mTextureID = textureID;
/*    */   }
/*    */   
/*    */ 
/*    */   public ARTexture2D() {}
/*    */   
/*    */ 
/*    */   public void bindTexture(int unit)
/*    */   {
/* 45 */     int texUnit = 33984;
/* 46 */     if (unit == 1) {
/* 47 */       texUnit = 33985;
/*    */     }
/* 49 */     if (unit == 2) {
/* 50 */       texUnit = 33986;
/*    */     }
/*    */     
/* 53 */     android.opengl.GLES20.glActiveTexture(texUnit);
/* 54 */     android.opengl.GLES20.glBindTexture(3553, this.mTextureID);
/*    */   }
/*    */   
/*    */   private native void loadDataN(java.io.FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*    */   
/* 59 */   public void loadData() { if (this.mAssetName != null) {
/* 60 */       createTexture();
/*    */     }
/* 62 */     bindTexture(0);
/*    */     
/* 64 */     if (this.mAssetName != null) {
/*    */       try {
/* 66 */         ARRenderer renderer = ARRenderer.getInstance();
/* 67 */         AssetFileDescriptor fd = renderer.getAssetManager().openFd(this.mAssetName);
/* 68 */         loadDataN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength());
/* 69 */         fd.close();
/*    */       }
/*    */       catch (Exception e) {
/* 72 */         e.printStackTrace();
/* 73 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void prepareRenderer(int unit)
/*    */   {
/* 80 */     bindTexture(unit);
/* 81 */     android.opengl.GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 82 */     android.opengl.GLES20.glTexParameterf(3553, 10240, 9729.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTexture2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */