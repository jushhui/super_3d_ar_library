/*      */ package com.jme3.math;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Matrix3f
/*      */   implements Cloneable, Serializable
/*      */ {
/*      */   static final long serialVersionUID = 1L;
/*   52 */   private static final Logger logger = Logger.getLogger(Matrix3f.class.getName());
/*      */   protected float m00;
/*      */   protected float m01;
/*      */   protected float m02;
/*   56 */   protected float m10; protected float m11; protected float m12; protected float m20; protected float m21; protected float m22; public static final Matrix3f ZERO = new Matrix3f(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*   57 */   public static final Matrix3f IDENTITY = new Matrix3f();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f()
/*      */   {
/*   65 */     loadIdentity();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f(float m00, float m01, float m02, float m10, float m11, float m12, float m20, float m21, float m22)
/*      */   {
/*   93 */     this.m00 = m00;
/*   94 */     this.m01 = m01;
/*   95 */     this.m02 = m02;
/*   96 */     this.m10 = m10;
/*   97 */     this.m11 = m11;
/*   98 */     this.m12 = m12;
/*   99 */     this.m20 = m20;
/*  100 */     this.m21 = m21;
/*  101 */     this.m22 = m22;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f(Matrix3f mat)
/*      */   {
/*  112 */     set(mat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void absoluteLocal()
/*      */   {
/*  119 */     this.m00 = FastMath.abs(this.m00);
/*  120 */     this.m01 = FastMath.abs(this.m01);
/*  121 */     this.m02 = FastMath.abs(this.m02);
/*  122 */     this.m10 = FastMath.abs(this.m10);
/*  123 */     this.m11 = FastMath.abs(this.m11);
/*  124 */     this.m12 = FastMath.abs(this.m12);
/*  125 */     this.m20 = FastMath.abs(this.m20);
/*  126 */     this.m21 = FastMath.abs(this.m21);
/*  127 */     this.m22 = FastMath.abs(this.m22);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(Matrix3f matrix)
/*      */   {
/*  140 */     if (matrix == null) {
/*  141 */       loadIdentity();
/*      */     } else {
/*  143 */       this.m00 = matrix.m00;
/*  144 */       this.m01 = matrix.m01;
/*  145 */       this.m02 = matrix.m02;
/*  146 */       this.m10 = matrix.m10;
/*  147 */       this.m11 = matrix.m11;
/*  148 */       this.m12 = matrix.m12;
/*  149 */       this.m20 = matrix.m20;
/*  150 */       this.m21 = matrix.m21;
/*  151 */       this.m22 = matrix.m22;
/*      */     }
/*  153 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float get(int i, int j)
/*      */   {
/*  169 */     switch (i) {
/*      */     case 0: 
/*  171 */       switch (j) {
/*      */       case 0: 
/*  173 */         return this.m00;
/*      */       case 1: 
/*  175 */         return this.m01;
/*      */       case 2: 
/*  177 */         return this.m02;
/*      */       }
/*      */     case 1: 
/*  180 */       switch (j) {
/*      */       case 0: 
/*  182 */         return this.m10;
/*      */       case 1: 
/*  184 */         return this.m11;
/*      */       case 2: 
/*  186 */         return this.m12;
/*      */       }
/*      */     case 2: 
/*  189 */       switch (j) {
/*      */       case 0: 
/*  191 */         return this.m20;
/*      */       case 1: 
/*  193 */         return this.m21;
/*      */       case 2: 
/*  195 */         return this.m22;
/*      */       }
/*      */       break;
/*      */     }
/*  199 */     logger.warning("Invalid matrix index.");
/*  200 */     throw new IllegalArgumentException("Invalid indices into matrix.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void get(float[] data, boolean rowMajor)
/*      */   {
/*  214 */     if (data.length == 9) {
/*  215 */       if (rowMajor) {
/*  216 */         data[0] = this.m00;
/*  217 */         data[1] = this.m01;
/*  218 */         data[2] = this.m02;
/*  219 */         data[3] = this.m10;
/*  220 */         data[4] = this.m11;
/*  221 */         data[5] = this.m12;
/*  222 */         data[6] = this.m20;
/*  223 */         data[7] = this.m21;
/*  224 */         data[8] = this.m22;
/*      */       } else {
/*  226 */         data[0] = this.m00;
/*  227 */         data[1] = this.m10;
/*  228 */         data[2] = this.m20;
/*  229 */         data[3] = this.m01;
/*  230 */         data[4] = this.m11;
/*  231 */         data[5] = this.m21;
/*  232 */         data[6] = this.m02;
/*  233 */         data[7] = this.m12;
/*  234 */         data[8] = this.m22;
/*      */       }
/*  236 */     } else if (data.length == 16) {
/*  237 */       if (rowMajor) {
/*  238 */         data[0] = this.m00;
/*  239 */         data[1] = this.m01;
/*  240 */         data[2] = this.m02;
/*  241 */         data[4] = this.m10;
/*  242 */         data[5] = this.m11;
/*  243 */         data[6] = this.m12;
/*  244 */         data[8] = this.m20;
/*  245 */         data[9] = this.m21;
/*  246 */         data[10] = this.m22;
/*      */       } else {
/*  248 */         data[0] = this.m00;
/*  249 */         data[1] = this.m10;
/*  250 */         data[2] = this.m20;
/*  251 */         data[4] = this.m01;
/*  252 */         data[5] = this.m11;
/*  253 */         data[6] = this.m21;
/*  254 */         data[8] = this.m02;
/*  255 */         data[9] = this.m12;
/*  256 */         data[10] = this.m22;
/*      */       }
/*      */     } else {
/*  259 */       throw new IndexOutOfBoundsException("Array size must be 9 or 16 in Matrix3f.get().");
/*      */     }
/*      */   }
/*      */   
/*      */   public void get(float[] data, int offset, boolean rowMajor) {
/*  264 */     if (rowMajor) {
/*  265 */       data[(0 + offset)] = this.m00;
/*  266 */       data[(1 + offset)] = this.m01;
/*  267 */       data[(2 + offset)] = this.m02;
/*  268 */       data[(3 + offset)] = this.m10;
/*  269 */       data[(4 + offset)] = this.m11;
/*  270 */       data[(5 + offset)] = this.m12;
/*  271 */       data[(6 + offset)] = this.m20;
/*  272 */       data[(7 + offset)] = this.m21;
/*  273 */       data[(8 + offset)] = this.m22;
/*      */     } else {
/*  275 */       data[(0 + offset)] = this.m00;
/*  276 */       data[(1 + offset)] = this.m10;
/*  277 */       data[(2 + offset)] = this.m20;
/*  278 */       data[(3 + offset)] = this.m01;
/*  279 */       data[(4 + offset)] = this.m11;
/*  280 */       data[(5 + offset)] = this.m21;
/*  281 */       data[(6 + offset)] = this.m02;
/*  282 */       data[(7 + offset)] = this.m12;
/*  283 */       data[(8 + offset)] = this.m22;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getColumn(int i)
/*      */   {
/*  297 */     return getColumn(i, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getColumn(int i, Vector3f store)
/*      */   {
/*  312 */     if (store == null) {
/*  313 */       store = new Vector3f();
/*      */     }
/*  315 */     switch (i) {
/*      */     case 0: 
/*  317 */       store.x = this.m00;
/*  318 */       store.y = this.m10;
/*  319 */       store.z = this.m20;
/*  320 */       break;
/*      */     case 1: 
/*  322 */       store.x = this.m01;
/*  323 */       store.y = this.m11;
/*  324 */       store.z = this.m21;
/*  325 */       break;
/*      */     case 2: 
/*  327 */       store.x = this.m02;
/*  328 */       store.y = this.m12;
/*  329 */       store.z = this.m22;
/*  330 */       break;
/*      */     default: 
/*  332 */       logger.warning("Invalid column index.");
/*  333 */       throw new IllegalArgumentException("Invalid column index. " + i);
/*      */     }
/*  335 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getRow(int i)
/*      */   {
/*  347 */     return getRow(i, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getRow(int i, Vector3f store)
/*      */   {
/*  362 */     if (store == null) {
/*  363 */       store = new Vector3f();
/*      */     }
/*  365 */     switch (i) {
/*      */     case 0: 
/*  367 */       store.x = this.m00;
/*  368 */       store.y = this.m01;
/*  369 */       store.z = this.m02;
/*  370 */       break;
/*      */     case 1: 
/*  372 */       store.x = this.m10;
/*  373 */       store.y = this.m11;
/*  374 */       store.z = this.m12;
/*  375 */       break;
/*      */     case 2: 
/*  377 */       store.x = this.m20;
/*  378 */       store.y = this.m21;
/*  379 */       store.z = this.m22;
/*  380 */       break;
/*      */     default: 
/*  382 */       logger.warning("Invalid row index.");
/*  383 */       throw new IllegalArgumentException("Invalid row index. " + i);
/*      */     }
/*  385 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillFloatArray(float[] f, boolean columnMajor)
/*      */   {
/*  393 */     if (columnMajor) {
/*  394 */       f[0] = this.m00;
/*  395 */       f[1] = this.m10;
/*  396 */       f[2] = this.m20;
/*  397 */       f[3] = this.m01;
/*  398 */       f[4] = this.m11;
/*  399 */       f[5] = this.m21;
/*  400 */       f[6] = this.m02;
/*  401 */       f[7] = this.m12;
/*  402 */       f[8] = this.m22;
/*      */     } else {
/*  404 */       f[0] = this.m00;
/*  405 */       f[1] = this.m01;
/*  406 */       f[2] = this.m02;
/*  407 */       f[3] = this.m10;
/*  408 */       f[4] = this.m11;
/*  409 */       f[5] = this.m12;
/*  410 */       f[6] = this.m20;
/*  411 */       f[7] = this.m21;
/*  412 */       f[8] = this.m22;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f setColumn(int i, Vector3f column)
/*      */   {
/*  429 */     if (column == null) {
/*  430 */       logger.warning("Column is null. Ignoring.");
/*  431 */       return this;
/*      */     }
/*  433 */     switch (i) {
/*      */     case 0: 
/*  435 */       this.m00 = column.x;
/*  436 */       this.m10 = column.y;
/*  437 */       this.m20 = column.z;
/*  438 */       break;
/*      */     case 1: 
/*  440 */       this.m01 = column.x;
/*  441 */       this.m11 = column.y;
/*  442 */       this.m21 = column.z;
/*  443 */       break;
/*      */     case 2: 
/*  445 */       this.m02 = column.x;
/*  446 */       this.m12 = column.y;
/*  447 */       this.m22 = column.z;
/*  448 */       break;
/*      */     default: 
/*  450 */       logger.warning("Invalid column index.");
/*  451 */       throw new IllegalArgumentException("Invalid column index. " + i);
/*      */     }
/*  453 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f setRow(int i, Vector3f row)
/*      */   {
/*  469 */     if (row == null) {
/*  470 */       logger.warning("Row is null. Ignoring.");
/*  471 */       return this;
/*      */     }
/*  473 */     switch (i) {
/*      */     case 0: 
/*  475 */       this.m00 = row.x;
/*  476 */       this.m01 = row.y;
/*  477 */       this.m02 = row.z;
/*  478 */       break;
/*      */     case 1: 
/*  480 */       this.m10 = row.x;
/*  481 */       this.m11 = row.y;
/*  482 */       this.m12 = row.z;
/*  483 */       break;
/*      */     case 2: 
/*  485 */       this.m20 = row.x;
/*  486 */       this.m21 = row.y;
/*  487 */       this.m22 = row.z;
/*  488 */       break;
/*      */     default: 
/*  490 */       logger.warning("Invalid row index.");
/*  491 */       throw new IllegalArgumentException("Invalid row index. " + i);
/*      */     }
/*  493 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(int i, int j, float value)
/*      */   {
/*  511 */     switch (i) {
/*      */     case 0: 
/*  513 */       switch (j) {
/*      */       case 0: 
/*  515 */         this.m00 = value;
/*  516 */         return this;
/*      */       case 1: 
/*  518 */         this.m01 = value;
/*  519 */         return this;
/*      */       case 2: 
/*  521 */         this.m02 = value;
/*  522 */         return this;
/*      */       }
/*      */     case 1: 
/*  525 */       switch (j) {
/*      */       case 0: 
/*  527 */         this.m10 = value;
/*  528 */         return this;
/*      */       case 1: 
/*  530 */         this.m11 = value;
/*  531 */         return this;
/*      */       case 2: 
/*  533 */         this.m12 = value;
/*  534 */         return this;
/*      */       }
/*      */     case 2: 
/*  537 */       switch (j) {
/*      */       case 0: 
/*  539 */         this.m20 = value;
/*  540 */         return this;
/*      */       case 1: 
/*  542 */         this.m21 = value;
/*  543 */         return this;
/*      */       case 2: 
/*  545 */         this.m22 = value;
/*  546 */         return this;
/*      */       }
/*      */       break;
/*      */     }
/*  550 */     logger.warning("Invalid matrix index.");
/*  551 */     throw new IllegalArgumentException("Invalid indices into matrix.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(float[][] matrix)
/*      */   {
/*  566 */     if ((matrix.length != 3) || (matrix[0].length != 3)) {
/*  567 */       throw new IllegalArgumentException(
/*  568 */         "Array must be of size 9.");
/*      */     }
/*      */     
/*  571 */     this.m00 = matrix[0][0];
/*  572 */     this.m01 = matrix[0][1];
/*  573 */     this.m02 = matrix[0][2];
/*  574 */     this.m10 = matrix[1][0];
/*  575 */     this.m11 = matrix[1][1];
/*  576 */     this.m12 = matrix[1][2];
/*  577 */     this.m20 = matrix[2][0];
/*  578 */     this.m21 = matrix[2][1];
/*  579 */     this.m22 = matrix[2][2];
/*      */     
/*  581 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromAxes(Vector3f uAxis, Vector3f vAxis, Vector3f wAxis)
/*      */   {
/*  595 */     this.m00 = uAxis.x;
/*  596 */     this.m10 = uAxis.y;
/*  597 */     this.m20 = uAxis.z;
/*      */     
/*  599 */     this.m01 = vAxis.x;
/*  600 */     this.m11 = vAxis.y;
/*  601 */     this.m21 = vAxis.z;
/*      */     
/*  603 */     this.m02 = wAxis.x;
/*  604 */     this.m12 = wAxis.y;
/*  605 */     this.m22 = wAxis.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(float[] matrix)
/*      */   {
/*  617 */     return set(matrix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(float[] matrix, boolean rowMajor)
/*      */   {
/*  631 */     if (matrix.length != 9) {
/*  632 */       throw new IllegalArgumentException(
/*  633 */         "Array must be of size 9.");
/*      */     }
/*      */     
/*  636 */     if (rowMajor) {
/*  637 */       this.m00 = matrix[0];
/*  638 */       this.m01 = matrix[1];
/*  639 */       this.m02 = matrix[2];
/*  640 */       this.m10 = matrix[3];
/*  641 */       this.m11 = matrix[4];
/*  642 */       this.m12 = matrix[5];
/*  643 */       this.m20 = matrix[6];
/*  644 */       this.m21 = matrix[7];
/*  645 */       this.m22 = matrix[8];
/*      */     } else {
/*  647 */       this.m00 = matrix[0];
/*  648 */       this.m01 = matrix[3];
/*  649 */       this.m02 = matrix[6];
/*  650 */       this.m10 = matrix[1];
/*  651 */       this.m11 = matrix[4];
/*  652 */       this.m12 = matrix[7];
/*  653 */       this.m20 = matrix[2];
/*  654 */       this.m21 = matrix[5];
/*  655 */       this.m22 = matrix[8];
/*      */     }
/*  657 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f set(Quaternion quaternion)
/*      */   {
/*  671 */     return quaternion.toRotationMatrix(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadIdentity()
/*      */   {
/*  680 */     this.m01 = (this.m02 = this.m10 = this.m12 = this.m20 = this.m21 = 0.0F);
/*  681 */     this.m00 = (this.m11 = this.m22 = 1.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isIdentity()
/*      */   {
/*  688 */     return (this.m00 == 1.0F) && (this.m01 == 0.0F) && (this.m02 == 0.0F) && 
/*  689 */       (this.m10 == 0.0F) && (this.m11 == 1.0F) && (this.m12 == 0.0F) && 
/*  690 */       (this.m20 == 0.0F) && (this.m21 == 0.0F) && (this.m22 == 1.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromAngleAxis(float angle, Vector3f axis)
/*      */   {
/*  704 */     Vector3f normAxis = axis.normalize();
/*  705 */     fromAngleNormalAxis(angle, normAxis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromAngleNormalAxis(float angle, Vector3f axis)
/*      */   {
/*  718 */     float fCos = FastMath.cos(angle);
/*  719 */     float fSin = FastMath.sin(angle);
/*  720 */     float fOneMinusCos = 1.0F - fCos;
/*  721 */     float fX2 = axis.x * axis.x;
/*  722 */     float fY2 = axis.y * axis.y;
/*  723 */     float fZ2 = axis.z * axis.z;
/*  724 */     float fXYM = axis.x * axis.y * fOneMinusCos;
/*  725 */     float fXZM = axis.x * axis.z * fOneMinusCos;
/*  726 */     float fYZM = axis.y * axis.z * fOneMinusCos;
/*  727 */     float fXSin = axis.x * fSin;
/*  728 */     float fYSin = axis.y * fSin;
/*  729 */     float fZSin = axis.z * fSin;
/*      */     
/*  731 */     this.m00 = (fX2 * fOneMinusCos + fCos);
/*  732 */     this.m01 = (fXYM - fZSin);
/*  733 */     this.m02 = (fXZM + fYSin);
/*  734 */     this.m10 = (fXYM + fZSin);
/*  735 */     this.m11 = (fY2 * fOneMinusCos + fCos);
/*  736 */     this.m12 = (fYZM - fXSin);
/*  737 */     this.m20 = (fXZM - fYSin);
/*  738 */     this.m21 = (fYZM + fXSin);
/*  739 */     this.m22 = (fZ2 * fOneMinusCos + fCos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f mult(Matrix3f mat)
/*      */   {
/*  752 */     return mult(mat, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f mult(Matrix3f mat, Matrix3f product)
/*      */   {
/*  772 */     if (product == null) {
/*  773 */       product = new Matrix3f();
/*      */     }
/*  775 */     float temp00 = this.m00 * mat.m00 + this.m01 * mat.m10 + this.m02 * mat.m20;
/*  776 */     float temp01 = this.m00 * mat.m01 + this.m01 * mat.m11 + this.m02 * mat.m21;
/*  777 */     float temp02 = this.m00 * mat.m02 + this.m01 * mat.m12 + this.m02 * mat.m22;
/*  778 */     float temp10 = this.m10 * mat.m00 + this.m11 * mat.m10 + this.m12 * mat.m20;
/*  779 */     float temp11 = this.m10 * mat.m01 + this.m11 * mat.m11 + this.m12 * mat.m21;
/*  780 */     float temp12 = this.m10 * mat.m02 + this.m11 * mat.m12 + this.m12 * mat.m22;
/*  781 */     float temp20 = this.m20 * mat.m00 + this.m21 * mat.m10 + this.m22 * mat.m20;
/*  782 */     float temp21 = this.m20 * mat.m01 + this.m21 * mat.m11 + this.m22 * mat.m21;
/*  783 */     float temp22 = this.m20 * mat.m02 + this.m21 * mat.m12 + this.m22 * mat.m22;
/*      */     
/*  785 */     product.m00 = temp00;
/*  786 */     product.m01 = temp01;
/*  787 */     product.m02 = temp02;
/*  788 */     product.m10 = temp10;
/*  789 */     product.m11 = temp11;
/*  790 */     product.m12 = temp12;
/*  791 */     product.m20 = temp20;
/*  792 */     product.m21 = temp21;
/*  793 */     product.m22 = temp22;
/*      */     
/*  795 */     return product;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec)
/*      */   {
/*  808 */     return mult(vec, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec, Vector3f product)
/*      */   {
/*  824 */     if (product == null) {
/*  825 */       product = new Vector3f();
/*      */     }
/*      */     
/*  828 */     float x = vec.x;
/*  829 */     float y = vec.y;
/*  830 */     float z = vec.z;
/*      */     
/*  832 */     product.x = (this.m00 * x + this.m01 * y + this.m02 * z);
/*  833 */     product.y = (this.m10 * x + this.m11 * y + this.m12 * z);
/*  834 */     product.z = (this.m20 * x + this.m21 * y + this.m22 * z);
/*  835 */     return product;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f multLocal(float scale)
/*      */   {
/*  847 */     this.m00 *= scale;
/*  848 */     this.m01 *= scale;
/*  849 */     this.m02 *= scale;
/*  850 */     this.m10 *= scale;
/*  851 */     this.m11 *= scale;
/*  852 */     this.m12 *= scale;
/*  853 */     this.m20 *= scale;
/*  854 */     this.m21 *= scale;
/*  855 */     this.m22 *= scale;
/*  856 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multLocal(Vector3f vec)
/*      */   {
/*  870 */     if (vec == null) {
/*  871 */       return null;
/*      */     }
/*  873 */     float x = vec.x;
/*  874 */     float y = vec.y;
/*  875 */     vec.x = (this.m00 * x + this.m01 * y + this.m02 * vec.z);
/*  876 */     vec.y = (this.m10 * x + this.m11 * y + this.m12 * vec.z);
/*  877 */     vec.z = (this.m20 * x + this.m21 * y + this.m22 * vec.z);
/*  878 */     return vec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f multLocal(Matrix3f mat)
/*      */   {
/*  892 */     return mult(mat, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f transposeLocal()
/*      */   {
/*  905 */     float tmp = this.m01;
/*  906 */     this.m01 = this.m10;
/*  907 */     this.m10 = tmp;
/*      */     
/*  909 */     tmp = this.m02;
/*  910 */     this.m02 = this.m20;
/*  911 */     this.m20 = tmp;
/*      */     
/*  913 */     tmp = this.m12;
/*  914 */     this.m12 = this.m21;
/*  915 */     this.m21 = tmp;
/*      */     
/*  917 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f invert()
/*      */   {
/*  926 */     return invert(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f invert(Matrix3f store)
/*      */   {
/*  935 */     if (store == null) {
/*  936 */       store = new Matrix3f();
/*      */     }
/*      */     
/*  939 */     float det = determinant();
/*  940 */     if (FastMath.abs(det) <= 1.1920929E-7F) {
/*  941 */       return store.zero();
/*      */     }
/*      */     
/*  944 */     store.m00 = (this.m11 * this.m22 - this.m12 * this.m21);
/*  945 */     store.m01 = (this.m02 * this.m21 - this.m01 * this.m22);
/*  946 */     store.m02 = (this.m01 * this.m12 - this.m02 * this.m11);
/*  947 */     store.m10 = (this.m12 * this.m20 - this.m10 * this.m22);
/*  948 */     store.m11 = (this.m00 * this.m22 - this.m02 * this.m20);
/*  949 */     store.m12 = (this.m02 * this.m10 - this.m00 * this.m12);
/*  950 */     store.m20 = (this.m10 * this.m21 - this.m11 * this.m20);
/*  951 */     store.m21 = (this.m01 * this.m20 - this.m00 * this.m21);
/*  952 */     store.m22 = (this.m00 * this.m11 - this.m01 * this.m10);
/*      */     
/*  954 */     store.multLocal(1.0F / det);
/*  955 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f invertLocal()
/*      */   {
/*  964 */     float det = determinant();
/*  965 */     if (FastMath.abs(det) <= 0.0F) {
/*  966 */       return zero();
/*      */     }
/*      */     
/*  969 */     float f00 = this.m11 * this.m22 - this.m12 * this.m21;
/*  970 */     float f01 = this.m02 * this.m21 - this.m01 * this.m22;
/*  971 */     float f02 = this.m01 * this.m12 - this.m02 * this.m11;
/*  972 */     float f10 = this.m12 * this.m20 - this.m10 * this.m22;
/*  973 */     float f11 = this.m00 * this.m22 - this.m02 * this.m20;
/*  974 */     float f12 = this.m02 * this.m10 - this.m00 * this.m12;
/*  975 */     float f20 = this.m10 * this.m21 - this.m11 * this.m20;
/*  976 */     float f21 = this.m01 * this.m20 - this.m00 * this.m21;
/*  977 */     float f22 = this.m00 * this.m11 - this.m01 * this.m10;
/*      */     
/*  979 */     this.m00 = f00;
/*  980 */     this.m01 = f01;
/*  981 */     this.m02 = f02;
/*  982 */     this.m10 = f10;
/*  983 */     this.m11 = f11;
/*  984 */     this.m12 = f12;
/*  985 */     this.m20 = f20;
/*  986 */     this.m21 = f21;
/*  987 */     this.m22 = f22;
/*      */     
/*  989 */     multLocal(1.0F / det);
/*  990 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f adjoint()
/*      */   {
/*  999 */     return adjoint(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f adjoint(Matrix3f store)
/*      */   {
/* 1010 */     if (store == null) {
/* 1011 */       store = new Matrix3f();
/*      */     }
/*      */     
/* 1014 */     store.m00 = (this.m11 * this.m22 - this.m12 * this.m21);
/* 1015 */     store.m01 = (this.m02 * this.m21 - this.m01 * this.m22);
/* 1016 */     store.m02 = (this.m01 * this.m12 - this.m02 * this.m11);
/* 1017 */     store.m10 = (this.m12 * this.m20 - this.m10 * this.m22);
/* 1018 */     store.m11 = (this.m00 * this.m22 - this.m02 * this.m20);
/* 1019 */     store.m12 = (this.m02 * this.m10 - this.m00 * this.m12);
/* 1020 */     store.m20 = (this.m10 * this.m21 - this.m11 * this.m20);
/* 1021 */     store.m21 = (this.m01 * this.m20 - this.m00 * this.m21);
/* 1022 */     store.m22 = (this.m00 * this.m11 - this.m01 * this.m10);
/*      */     
/* 1024 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float determinant()
/*      */   {
/* 1033 */     float fCo00 = this.m11 * this.m22 - this.m12 * this.m21;
/* 1034 */     float fCo10 = this.m12 * this.m20 - this.m10 * this.m22;
/* 1035 */     float fCo20 = this.m10 * this.m21 - this.m11 * this.m20;
/* 1036 */     float fDet = this.m00 * fCo00 + this.m01 * fCo10 + this.m02 * fCo20;
/* 1037 */     return fDet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f zero()
/*      */   {
/* 1046 */     this.m00 = (this.m01 = this.m02 = this.m10 = this.m11 = this.m12 = this.m20 = this.m21 = this.m22 = 0.0F);
/* 1047 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f transpose()
/*      */   {
/* 1059 */     return transposeLocal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f transposeNew()
/*      */   {
/* 1068 */     Matrix3f ret = new Matrix3f(this.m00, this.m10, this.m20, this.m01, this.m11, this.m21, this.m02, this.m12, this.m22);
/* 1069 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1084 */     StringBuilder result = new StringBuilder("Matrix3f\n[\n");
/* 1085 */     result.append(" ");
/* 1086 */     result.append(this.m00);
/* 1087 */     result.append("  ");
/* 1088 */     result.append(this.m01);
/* 1089 */     result.append("  ");
/* 1090 */     result.append(this.m02);
/* 1091 */     result.append(" \n");
/* 1092 */     result.append(" ");
/* 1093 */     result.append(this.m10);
/* 1094 */     result.append("  ");
/* 1095 */     result.append(this.m11);
/* 1096 */     result.append("  ");
/* 1097 */     result.append(this.m12);
/* 1098 */     result.append(" \n");
/* 1099 */     result.append(" ");
/* 1100 */     result.append(this.m20);
/* 1101 */     result.append("  ");
/* 1102 */     result.append(this.m21);
/* 1103 */     result.append("  ");
/* 1104 */     result.append(this.m22);
/* 1105 */     result.append(" \n]");
/* 1106 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1120 */     int hash = 37;
/* 1121 */     hash = 37 * hash + Float.floatToIntBits(this.m00);
/* 1122 */     hash = 37 * hash + Float.floatToIntBits(this.m01);
/* 1123 */     hash = 37 * hash + Float.floatToIntBits(this.m02);
/*      */     
/* 1125 */     hash = 37 * hash + Float.floatToIntBits(this.m10);
/* 1126 */     hash = 37 * hash + Float.floatToIntBits(this.m11);
/* 1127 */     hash = 37 * hash + Float.floatToIntBits(this.m12);
/*      */     
/* 1129 */     hash = 37 * hash + Float.floatToIntBits(this.m20);
/* 1130 */     hash = 37 * hash + Float.floatToIntBits(this.m21);
/* 1131 */     hash = 37 * hash + Float.floatToIntBits(this.m22);
/*      */     
/* 1133 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1145 */     if ((!(o instanceof Matrix3f)) || (o == null)) {
/* 1146 */       return false;
/*      */     }
/*      */     
/* 1149 */     if (this == o) {
/* 1150 */       return true;
/*      */     }
/*      */     
/* 1153 */     Matrix3f comp = (Matrix3f)o;
/* 1154 */     if (Float.compare(this.m00, comp.m00) != 0) {
/* 1155 */       return false;
/*      */     }
/* 1157 */     if (Float.compare(this.m01, comp.m01) != 0) {
/* 1158 */       return false;
/*      */     }
/* 1160 */     if (Float.compare(this.m02, comp.m02) != 0) {
/* 1161 */       return false;
/*      */     }
/*      */     
/* 1164 */     if (Float.compare(this.m10, comp.m10) != 0) {
/* 1165 */       return false;
/*      */     }
/* 1167 */     if (Float.compare(this.m11, comp.m11) != 0) {
/* 1168 */       return false;
/*      */     }
/* 1170 */     if (Float.compare(this.m12, comp.m12) != 0) {
/* 1171 */       return false;
/*      */     }
/*      */     
/* 1174 */     if (Float.compare(this.m20, comp.m20) != 0) {
/* 1175 */       return false;
/*      */     }
/* 1177 */     if (Float.compare(this.m21, comp.m21) != 0) {
/* 1178 */       return false;
/*      */     }
/* 1180 */     if (Float.compare(this.m22, comp.m22) != 0) {
/* 1181 */       return false;
/*      */     }
/*      */     
/* 1184 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromStartEndVectors(Vector3f start, Vector3f end)
/*      */   {
/* 1200 */     Vector3f v = new Vector3f();
/*      */     
/*      */ 
/* 1203 */     start.cross(end, v);
/* 1204 */     float e = start.dot(end);
/* 1205 */     float f = e < 0.0F ? -e : e;
/*      */     
/*      */ 
/* 1208 */     if (f > 0.9999F) {
/* 1209 */       Vector3f u = new Vector3f();
/* 1210 */       Vector3f x = new Vector3f();
/*      */       
/*      */ 
/*      */ 
/* 1214 */       x.x = (start.x > 0.0D ? start.x : -start.x);
/* 1215 */       x.y = (start.y > 0.0D ? start.y : -start.y);
/* 1216 */       x.z = (start.z > 0.0D ? start.z : -start.z);
/*      */       
/* 1218 */       if (x.x < x.y) {
/* 1219 */         if (x.x < x.z) {
/* 1220 */           x.x = 1.0F;
/* 1221 */           x.y = (x.z = 0.0F);
/*      */         } else {
/* 1223 */           x.z = 1.0F;
/* 1224 */           x.x = (x.y = 0.0F);
/*      */         }
/*      */       }
/* 1227 */       else if (x.y < x.z) {
/* 1228 */         x.y = 1.0F;
/* 1229 */         x.x = (x.z = 0.0F);
/*      */       } else {
/* 1231 */         x.z = 1.0F;
/* 1232 */         x.x = (x.y = 0.0F);
/*      */       }
/*      */       
/*      */ 
/* 1236 */       x.x -= start.x;
/* 1237 */       x.y -= start.y;
/* 1238 */       x.z -= start.z;
/* 1239 */       x.x -= end.x;
/* 1240 */       x.y -= end.y;
/* 1241 */       x.z -= end.z;
/*      */       
/* 1243 */       float c1 = 2.0F / u.dot(u);
/* 1244 */       float c2 = 2.0F / v.dot(v);
/* 1245 */       float c3 = c1 * c2 * u.dot(v);
/*      */       
/* 1247 */       for (int i = 0; i < 3; i++) {
/* 1248 */         for (int j = 0; j < 3; j++) {
/* 1249 */           float val = -c1 * u.get(i) * u.get(j) - c2 * v.get(i) * 
/* 1250 */             v.get(j) + c3 * v.get(i) * u.get(j);
/* 1251 */           set(i, j, val);
/*      */         }
/* 1253 */         float val = get(i, i);
/* 1254 */         set(i, i, val + 1.0F);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1259 */       float h = 1.0F / (1.0F + e);
/* 1260 */       float hvx = h * v.x;
/* 1261 */       float hvz = h * v.z;
/* 1262 */       float hvxy = hvx * v.y;
/* 1263 */       float hvxz = hvx * v.z;
/* 1264 */       float hvyz = hvz * v.y;
/* 1265 */       set(0, 0, e + hvx * v.x);
/* 1266 */       set(0, 1, hvxy - v.z);
/* 1267 */       set(0, 2, hvxz + v.y);
/*      */       
/* 1269 */       set(1, 0, hvxy + v.z);
/* 1270 */       set(1, 1, e + h * v.y * v.y);
/* 1271 */       set(1, 2, hvyz - v.x);
/*      */       
/* 1273 */       set(2, 0, hvxz - v.y);
/* 1274 */       set(2, 1, hvyz + v.x);
/* 1275 */       set(2, 2, e + hvz * v.z);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void scale(Vector3f scale)
/*      */   {
/* 1287 */     this.m00 *= scale.x;
/* 1288 */     this.m10 *= scale.x;
/* 1289 */     this.m20 *= scale.x;
/* 1290 */     this.m01 *= scale.y;
/* 1291 */     this.m11 *= scale.y;
/* 1292 */     this.m21 *= scale.y;
/* 1293 */     this.m02 *= scale.z;
/* 1294 */     this.m12 *= scale.z;
/* 1295 */     this.m22 *= scale.z;
/*      */   }
/*      */   
/*      */   static boolean equalIdentity(Matrix3f mat) {
/* 1299 */     if (Math.abs(mat.m00 - 1.0F) > 1.0E-4D) {
/* 1300 */       return false;
/*      */     }
/* 1302 */     if (Math.abs(mat.m11 - 1.0F) > 1.0E-4D) {
/* 1303 */       return false;
/*      */     }
/* 1305 */     if (Math.abs(mat.m22 - 1.0F) > 1.0E-4D) {
/* 1306 */       return false;
/*      */     }
/*      */     
/* 1309 */     if (Math.abs(mat.m01) > 1.0E-4D) {
/* 1310 */       return false;
/*      */     }
/* 1312 */     if (Math.abs(mat.m02) > 1.0E-4D) {
/* 1313 */       return false;
/*      */     }
/*      */     
/* 1316 */     if (Math.abs(mat.m10) > 1.0E-4D) {
/* 1317 */       return false;
/*      */     }
/* 1319 */     if (Math.abs(mat.m12) > 1.0E-4D) {
/* 1320 */       return false;
/*      */     }
/*      */     
/* 1323 */     if (Math.abs(mat.m20) > 1.0E-4D) {
/* 1324 */       return false;
/*      */     }
/* 1326 */     if (Math.abs(mat.m21) > 1.0E-4D) {
/* 1327 */       return false;
/*      */     }
/*      */     
/* 1330 */     return true;
/*      */   }
/*      */   
/*      */   public Matrix3f clone()
/*      */   {
/*      */     try {
/* 1336 */       return (Matrix3f)super.clone();
/*      */     } catch (CloneNotSupportedException e) {
/* 1338 */       throw new AssertionError();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Matrix3f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */