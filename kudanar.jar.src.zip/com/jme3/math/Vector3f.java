/*      */ package com.jme3.math;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Vector3f
/*      */   implements Cloneable, Serializable
/*      */ {
/*      */   static final long serialVersionUID = 1L;
/*   54 */   private static final Logger logger = Logger.getLogger(Vector3f.class.getName());
/*      */   
/*   56 */   public static final Vector3f ZERO = new Vector3f(0.0F, 0.0F, 0.0F);
/*   57 */   public static final Vector3f NAN = new Vector3f(NaN.0F, NaN.0F, NaN.0F);
/*   58 */   public static final Vector3f UNIT_X = new Vector3f(1.0F, 0.0F, 0.0F);
/*   59 */   public static final Vector3f UNIT_Y = new Vector3f(0.0F, 1.0F, 0.0F);
/*   60 */   public static final Vector3f UNIT_Z = new Vector3f(0.0F, 0.0F, 1.0F);
/*   61 */   public static final Vector3f UNIT_XYZ = new Vector3f(1.0F, 1.0F, 1.0F);
/*   62 */   public static final Vector3f POSITIVE_INFINITY = new Vector3f(
/*   63 */     Float.POSITIVE_INFINITY, 
/*   64 */     Float.POSITIVE_INFINITY, 
/*   65 */     Float.POSITIVE_INFINITY);
/*   66 */   public static final Vector3f NEGATIVE_INFINITY = new Vector3f(
/*   67 */     Float.NEGATIVE_INFINITY, 
/*   68 */     Float.NEGATIVE_INFINITY, 
/*   69 */     Float.NEGATIVE_INFINITY);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float x;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float y;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float z;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f()
/*      */   {
/*   93 */     this.x = (this.y = this.z = 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f(float x, float y, float z)
/*      */   {
/*  108 */     this.x = x;
/*  109 */     this.y = y;
/*  110 */     this.z = z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f(Vector3f copy)
/*      */   {
/*  119 */     set(copy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f set(float x, float y, float z)
/*      */   {
/*  135 */     this.x = x;
/*  136 */     this.y = y;
/*  137 */     this.z = z;
/*  138 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f set(Vector3f vect)
/*      */   {
/*  150 */     this.x = vect.x;
/*  151 */     this.y = vect.y;
/*  152 */     this.z = vect.z;
/*  153 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f add(Vector3f vec)
/*      */   {
/*  167 */     if (vec == null) {
/*  168 */       logger.warning("Provided vector is null, null returned.");
/*  169 */       return null;
/*      */     }
/*  171 */     return new Vector3f(this.x + vec.x, this.y + vec.y, this.z + vec.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f add(Vector3f vec, Vector3f result)
/*      */   {
/*  186 */     this.x += vec.x;
/*  187 */     this.y += vec.y;
/*  188 */     this.z += vec.z;
/*  189 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f addLocal(Vector3f vec)
/*      */   {
/*  202 */     if (vec == null) {
/*  203 */       logger.warning("Provided vector is null, null returned.");
/*  204 */       return null;
/*      */     }
/*  206 */     this.x += vec.x;
/*  207 */     this.y += vec.y;
/*  208 */     this.z += vec.z;
/*  209 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f add(float addX, float addY, float addZ)
/*      */   {
/*  226 */     return new Vector3f(this.x + addX, this.y + addY, this.z + addZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f addLocal(float addX, float addY, float addZ)
/*      */   {
/*  243 */     this.x += addX;
/*  244 */     this.y += addY;
/*  245 */     this.z += addZ;
/*  246 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f scaleAdd(float scalar, Vector3f add)
/*      */   {
/*  260 */     this.x = (this.x * scalar + add.x);
/*  261 */     this.y = (this.y * scalar + add.y);
/*  262 */     this.z = (this.z * scalar + add.z);
/*  263 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f scaleAdd(float scalar, Vector3f mult, Vector3f add)
/*      */   {
/*  279 */     this.x = (mult.x * scalar + add.x);
/*  280 */     this.y = (mult.y * scalar + add.y);
/*  281 */     this.z = (mult.z * scalar + add.z);
/*  282 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float dot(Vector3f vec)
/*      */   {
/*  295 */     if (vec == null) {
/*  296 */       logger.warning("Provided vector is null, 0 returned.");
/*  297 */       return 0.0F;
/*      */     }
/*  299 */     return this.x * vec.x + this.y * vec.y + this.z * vec.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f cross(Vector3f v)
/*      */   {
/*  311 */     return cross(v, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f cross(Vector3f v, Vector3f result)
/*      */   {
/*  325 */     return cross(v.x, v.y, v.z, result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f cross(float otherX, float otherY, float otherZ, Vector3f result)
/*      */   {
/*  343 */     if (result == null) result = new Vector3f();
/*  344 */     float resX = this.y * otherZ - this.z * otherY;
/*  345 */     float resY = this.z * otherX - this.x * otherZ;
/*  346 */     float resZ = this.x * otherY - this.y * otherX;
/*  347 */     result.set(resX, resY, resZ);
/*  348 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f crossLocal(Vector3f v)
/*      */   {
/*  360 */     return crossLocal(v.x, v.y, v.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f crossLocal(float otherX, float otherY, float otherZ)
/*      */   {
/*  376 */     float tempx = this.y * otherZ - this.z * otherY;
/*  377 */     float tempy = this.z * otherX - this.x * otherZ;
/*  378 */     this.z = (this.x * otherY - this.y * otherX);
/*  379 */     this.x = tempx;
/*  380 */     this.y = tempy;
/*  381 */     return this;
/*      */   }
/*      */   
/*      */   public Vector3f project(Vector3f other) {
/*  385 */     float n = dot(other);
/*  386 */     float d = other.lengthSquared();
/*  387 */     return new Vector3f(other).normalizeLocal().multLocal(n / d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnitVector()
/*      */   {
/*  398 */     float len = length();
/*  399 */     return (0.99F < len) && (len < 1.01F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float length()
/*      */   {
/*  408 */     return FastMath.sqrt(lengthSquared());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float lengthSquared()
/*      */   {
/*  418 */     return this.x * this.x + this.y * this.y + this.z * this.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float distanceSquared(Vector3f v)
/*      */   {
/*  429 */     double dx = this.x - v.x;
/*  430 */     double dy = this.y - v.y;
/*  431 */     double dz = this.z - v.z;
/*  432 */     return (float)(dx * dx + dy * dy + dz * dz);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float distance(Vector3f v)
/*      */   {
/*  443 */     return FastMath.sqrt(distanceSquared(v));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(float scalar)
/*      */   {
/*  456 */     return new Vector3f(this.x * scalar, this.y * scalar, this.z * scalar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(float scalar, Vector3f product)
/*      */   {
/*  469 */     if (product == null) {
/*  470 */       product = new Vector3f();
/*      */     }
/*      */     
/*  473 */     this.x *= scalar;
/*  474 */     this.y *= scalar;
/*  475 */     this.z *= scalar;
/*  476 */     return product;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multLocal(float scalar)
/*      */   {
/*  488 */     this.x *= scalar;
/*  489 */     this.y *= scalar;
/*  490 */     this.z *= scalar;
/*  491 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multLocal(Vector3f vec)
/*      */   {
/*  504 */     if (vec == null) {
/*  505 */       logger.warning("Provided vector is null, null returned.");
/*  506 */       return null;
/*      */     }
/*  508 */     this.x *= vec.x;
/*  509 */     this.y *= vec.y;
/*  510 */     this.z *= vec.z;
/*  511 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multLocal(float x, float y, float z)
/*      */   {
/*  525 */     this.x *= x;
/*  526 */     this.y *= y;
/*  527 */     this.z *= z;
/*  528 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec)
/*      */   {
/*  541 */     if (vec == null) {
/*  542 */       logger.warning("Provided vector is null, null returned.");
/*  543 */       return null;
/*      */     }
/*  545 */     return mult(vec, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec, Vector3f store)
/*      */   {
/*  559 */     if (vec == null) {
/*  560 */       logger.warning("Provided vector is null, null returned.");
/*  561 */       return null;
/*      */     }
/*  563 */     if (store == null) store = new Vector3f();
/*  564 */     return store.set(this.x * vec.x, this.y * vec.y, this.z * vec.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f divide(float scalar)
/*      */   {
/*  577 */     scalar = 1.0F / scalar;
/*  578 */     return new Vector3f(this.x * scalar, this.y * scalar, this.z * scalar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f divideLocal(float scalar)
/*      */   {
/*  591 */     scalar = 1.0F / scalar;
/*  592 */     this.x *= scalar;
/*  593 */     this.y *= scalar;
/*  594 */     this.z *= scalar;
/*  595 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f divide(Vector3f scalar)
/*      */   {
/*  608 */     return new Vector3f(this.x / scalar.x, this.y / scalar.y, this.z / scalar.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f divideLocal(Vector3f scalar)
/*      */   {
/*  621 */     this.x /= scalar.x;
/*  622 */     this.y /= scalar.y;
/*  623 */     this.z /= scalar.z;
/*  624 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f negate()
/*      */   {
/*  635 */     return new Vector3f(-this.x, -this.y, -this.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f negateLocal()
/*      */   {
/*  645 */     this.x = (-this.x);
/*  646 */     this.y = (-this.y);
/*  647 */     this.z = (-this.z);
/*  648 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f subtract(Vector3f vec)
/*      */   {
/*  662 */     return new Vector3f(this.x - vec.x, this.y - vec.y, this.z - vec.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f subtractLocal(Vector3f vec)
/*      */   {
/*  675 */     if (vec == null) {
/*  676 */       logger.warning("Provided vector is null, null returned.");
/*  677 */       return null;
/*      */     }
/*  679 */     this.x -= vec.x;
/*  680 */     this.y -= vec.y;
/*  681 */     this.z -= vec.z;
/*  682 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f subtract(Vector3f vec, Vector3f result)
/*      */   {
/*  696 */     if (result == null) {
/*  697 */       result = new Vector3f();
/*      */     }
/*  699 */     this.x -= vec.x;
/*  700 */     this.y -= vec.y;
/*  701 */     this.z -= vec.z;
/*  702 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f subtract(float subtractX, float subtractY, float subtractZ)
/*      */   {
/*  719 */     return new Vector3f(this.x - subtractX, this.y - subtractY, this.z - subtractZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f subtractLocal(float subtractX, float subtractY, float subtractZ)
/*      */   {
/*  736 */     this.x -= subtractX;
/*  737 */     this.y -= subtractY;
/*  738 */     this.z -= subtractZ;
/*  739 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f normalize()
/*      */   {
/*  754 */     float length = this.x * this.x + this.y * this.y + this.z * this.z;
/*  755 */     if ((length != 1.0F) && (length != 0.0F)) {
/*  756 */       length = 1.0F / FastMath.sqrt(length);
/*  757 */       return new Vector3f(this.x * length, this.y * length, this.z * length);
/*      */     }
/*  759 */     return clone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f normalizeLocal()
/*      */   {
/*  772 */     float length = this.x * this.x + this.y * this.y + this.z * this.z;
/*  773 */     if ((length != 1.0F) && (length != 0.0F)) {
/*  774 */       length = 1.0F / FastMath.sqrt(length);
/*  775 */       this.x *= length;
/*  776 */       this.y *= length;
/*  777 */       this.z *= length;
/*      */     }
/*  779 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void maxLocal(Vector3f other)
/*      */   {
/*  789 */     this.x = (other.x > this.x ? other.x : this.x);
/*  790 */     this.y = (other.y > this.y ? other.y : this.y);
/*  791 */     this.z = (other.z > this.z ? other.z : this.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void minLocal(Vector3f other)
/*      */   {
/*  801 */     this.x = (other.x < this.x ? other.x : this.x);
/*  802 */     this.y = (other.y < this.y ? other.y : this.y);
/*  803 */     this.z = (other.z < this.z ? other.z : this.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Vector3f zero()
/*      */   {
/*  810 */     this.x = (this.y = this.z = 0.0F);
/*  811 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float angleBetween(Vector3f otherVector)
/*      */   {
/*  822 */     float dotProduct = dot(otherVector);
/*  823 */     float angle = FastMath.acos(dotProduct);
/*  824 */     return angle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f interpolate(Vector3f finalVec, float changeAmnt)
/*      */   {
/*  835 */     this.x = ((1.0F - changeAmnt) * this.x + changeAmnt * finalVec.x);
/*  836 */     this.y = ((1.0F - changeAmnt) * this.y + changeAmnt * finalVec.y);
/*  837 */     this.z = ((1.0F - changeAmnt) * this.z + changeAmnt * finalVec.z);
/*  838 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f interpolate(Vector3f beginVec, Vector3f finalVec, float changeAmnt)
/*      */   {
/*  850 */     this.x = ((1.0F - changeAmnt) * beginVec.x + changeAmnt * finalVec.x);
/*  851 */     this.y = ((1.0F - changeAmnt) * beginVec.y + changeAmnt * finalVec.y);
/*  852 */     this.z = ((1.0F - changeAmnt) * beginVec.z + changeAmnt * finalVec.z);
/*  853 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isValidVector(Vector3f vector)
/*      */   {
/*  863 */     if (vector == null) return false;
/*  864 */     if ((Float.isNaN(vector.x)) || 
/*  865 */       (Float.isNaN(vector.y)) || 
/*  866 */       (Float.isNaN(vector.z))) return false;
/*  867 */     if ((Float.isInfinite(vector.x)) || 
/*  868 */       (Float.isInfinite(vector.y)) || 
/*  869 */       (Float.isInfinite(vector.z))) return false;
/*  870 */     return true;
/*      */   }
/*      */   
/*      */   public static void generateOrthonormalBasis(Vector3f u, Vector3f v, Vector3f w) {
/*  874 */     w.normalizeLocal();
/*  875 */     generateComplementBasis(u, v, w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void generateComplementBasis(Vector3f u, Vector3f v, Vector3f w)
/*      */   {
/*  882 */     if (FastMath.abs(w.x) >= FastMath.abs(w.y))
/*      */     {
/*  884 */       float fInvLength = FastMath.invSqrt(w.x * w.x + w.z * w.z);
/*  885 */       u.x = (-w.z * fInvLength);
/*  886 */       u.y = 0.0F;
/*  887 */       u.z = (w.x * fInvLength);
/*  888 */       v.x = (w.y * u.z);
/*  889 */       v.y = (w.z * u.x - w.x * u.z);
/*  890 */       v.z = (-w.y * u.x);
/*      */     }
/*      */     else {
/*  893 */       float fInvLength = FastMath.invSqrt(w.y * w.y + w.z * w.z);
/*  894 */       u.x = 0.0F;
/*  895 */       u.y = (w.z * fInvLength);
/*  896 */       u.z = (-w.y * fInvLength);
/*  897 */       v.x = (w.y * u.z - w.z * u.y);
/*  898 */       v.y = (-w.x * u.z);
/*  899 */       v.z = (w.x * u.y);
/*      */     }
/*      */   }
/*      */   
/*      */   public Vector3f clone()
/*      */   {
/*      */     try {
/*  906 */       return (Vector3f)super.clone();
/*      */     } catch (CloneNotSupportedException e) {
/*  908 */       throw new AssertionError();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] toArray(float[] floats)
/*      */   {
/*  921 */     if (floats == null) {
/*  922 */       floats = new float[3];
/*      */     }
/*  924 */     floats[0] = this.x;
/*  925 */     floats[1] = this.y;
/*  926 */     floats[2] = this.z;
/*  927 */     return floats;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/*  939 */     if (!(o instanceof Vector3f)) { return false;
/*      */     }
/*  941 */     if (this == o) { return true;
/*      */     }
/*  943 */     Vector3f comp = (Vector3f)o;
/*  944 */     if (Float.compare(this.x, comp.x) != 0) return false;
/*  945 */     if (Float.compare(this.y, comp.y) != 0) return false;
/*  946 */     if (Float.compare(this.z, comp.z) != 0) return false;
/*  947 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  957 */     int hash = 37;
/*  958 */     hash += 37 * hash + Float.floatToIntBits(this.x);
/*  959 */     hash += 37 * hash + Float.floatToIntBits(this.y);
/*  960 */     hash += 37 * hash + Float.floatToIntBits(this.z);
/*  961 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  973 */     return "(" + this.x + ", " + this.y + ", " + this.z + ")";
/*      */   }
/*      */   
/*      */ 
/*      */   public float getX()
/*      */   {
/*  979 */     return this.x;
/*      */   }
/*      */   
/*      */   public Vector3f setX(float x) {
/*  983 */     this.x = x;
/*  984 */     return this;
/*      */   }
/*      */   
/*      */   public float getY() {
/*  988 */     return this.y;
/*      */   }
/*      */   
/*      */   public Vector3f setY(float y) {
/*  992 */     this.y = y;
/*  993 */     return this;
/*      */   }
/*      */   
/*      */   public float getZ() {
/*  997 */     return this.z;
/*      */   }
/*      */   
/*      */   public Vector3f setZ(float z) {
/* 1001 */     this.z = z;
/* 1002 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float get(int index)
/*      */   {
/* 1013 */     switch (index) {
/*      */     case 0: 
/* 1015 */       return this.x;
/*      */     case 1: 
/* 1017 */       return this.y;
/*      */     case 2: 
/* 1019 */       return this.z;
/*      */     }
/* 1021 */     throw new IllegalArgumentException("index must be either 0, 1 or 2");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(int index, float value)
/*      */   {
/* 1033 */     switch (index) {
/*      */     case 0: 
/* 1035 */       this.x = value;
/* 1036 */       return;
/*      */     case 1: 
/* 1038 */       this.y = value;
/* 1039 */       return;
/*      */     case 2: 
/* 1041 */       this.z = value;
/* 1042 */       return;
/*      */     }
/* 1044 */     throw new IllegalArgumentException("index must be either 0, 1 or 2");
/*      */   }
/*      */   
/*      */   public Quaternion rotationTo(Vector3f dest) {
/* 1048 */     Quaternion q = new Quaternion();
/*      */     
/* 1050 */     Vector3f v0 = new Vector3f(this);
/* 1051 */     Vector3f v1 = new Vector3f(dest);
/*      */     
/* 1053 */     v0.normalizeLocal();
/* 1054 */     v1.normalizeLocal();
/*      */     
/* 1056 */     float d = v0.dot(v1);
/*      */     
/* 1058 */     if (d >= 1.0F) {
/* 1059 */       return q;
/*      */     }
/* 1061 */     if (d < -0.999999F) {
/* 1062 */       Vector3f axis = new Vector3f(1.0F, 0.0F, 0.0F);
/* 1063 */       axis.crossLocal(this);
/*      */       
/* 1065 */       float sqLen = axis.getX() * axis.getX() + axis.getY() * axis.getY() + axis.getZ() * axis.getZ();
/*      */       
/* 1067 */       if (sqLen < 1.0E-12D) {
/* 1068 */         axis.set(0.0F, 1.0F, 0.0F);
/* 1069 */         axis.crossLocal(this);
/*      */       }
/* 1071 */       axis.normalizeLocal();
/*      */       
/* 1073 */       q.fromAngleAxis(3.1415927F, axis);
/*      */     } else {
/* 1075 */       float s = (float)Math.sqrt((1.0F + d) * 2.0F);
/* 1076 */       float invs = 1.0F / s;
/*      */       
/* 1078 */       v0.crossLocal(v1);
/*      */       
/* 1080 */       q.set(v0.getX() * invs, v0.getY() * invs, v0.getZ() * invs, s * 0.5F);
/* 1081 */       q.normalizeLocal();
/*      */     }
/* 1083 */     return q;
/*      */   }
/*      */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Vector3f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */