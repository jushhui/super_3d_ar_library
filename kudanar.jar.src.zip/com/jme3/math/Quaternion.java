/*      */ package com.jme3.math;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInput;
/*      */ import java.io.ObjectOutput;
/*      */ import java.io.Serializable;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Quaternion
/*      */   implements Cloneable, Serializable
/*      */ {
/*      */   static final long serialVersionUID = 1L;
/*   56 */   private static final Logger logger = Logger.getLogger(Quaternion.class.getName());
/*      */   
/*      */ 
/*      */ 
/*   60 */   public static final Quaternion IDENTITY = new Quaternion();
/*   61 */   public static final Quaternion DIRECTION_Z = new Quaternion();
/*   62 */   public static final Quaternion ZERO = new Quaternion(0.0F, 0.0F, 0.0F, 0.0F);
/*      */   protected float x;
/*      */   
/*   65 */   static { DIRECTION_Z.fromAxes(Vector3f.UNIT_X, Vector3f.UNIT_Y, Vector3f.UNIT_Z); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion()
/*      */   {
/*   75 */     this.x = 0.0F;
/*   76 */     this.y = 0.0F;
/*   77 */     this.z = 0.0F;
/*   78 */     this.w = 1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion(float x, float y, float z, float w)
/*      */   {
/*   95 */     this.x = x;
/*   96 */     this.y = y;
/*   97 */     this.z = z;
/*   98 */     this.w = w;
/*      */   }
/*      */   
/*      */   public float getX() {
/*  102 */     return this.x;
/*      */   }
/*      */   
/*      */   public float getY() {
/*  106 */     return this.y;
/*      */   }
/*      */   
/*      */   public float getZ() {
/*  110 */     return this.z;
/*      */   }
/*      */   
/*      */   public float getW() {
/*  114 */     return this.w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float y;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion set(float x, float y, float z, float w)
/*      */   {
/*  132 */     this.x = x;
/*  133 */     this.y = y;
/*  134 */     this.z = z;
/*  135 */     this.w = w;
/*  136 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion set(Quaternion q)
/*      */   {
/*  149 */     this.x = q.x;
/*  150 */     this.y = q.y;
/*  151 */     this.z = q.z;
/*  152 */     this.w = q.w;
/*  153 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion(float[] angles)
/*      */   {
/*  165 */     fromAngles(angles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion(Quaternion q1, Quaternion q2, float interp)
/*      */   {
/*  180 */     slerp(q1, q2, interp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion(Quaternion q)
/*      */   {
/*  191 */     this.x = q.x;
/*  192 */     this.y = q.y;
/*  193 */     this.z = q.z;
/*  194 */     this.w = q.w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void loadIdentity()
/*      */   {
/*  201 */     this.x = (this.y = this.z = 0.0F);
/*  202 */     this.w = 1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isIdentity()
/*      */   {
/*  209 */     if ((this.x == 0.0F) && (this.y == 0.0F) && (this.z == 0.0F) && (this.w == 1.0F)) {
/*  210 */       return true;
/*      */     }
/*  212 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAngles(float[] angles)
/*      */   {
/*  224 */     if (angles.length != 3) {
/*  225 */       throw new IllegalArgumentException(
/*  226 */         "Angles array must have three elements");
/*      */     }
/*      */     
/*  229 */     return fromAngles(angles[0], angles[1], angles[2]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float z;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float w;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAngles(float xAngle, float yAngle, float zAngle)
/*      */   {
/*  251 */     float angle = zAngle * 0.5F;
/*  252 */     float sinZ = FastMath.sin(angle);
/*  253 */     float cosZ = FastMath.cos(angle);
/*  254 */     angle = yAngle * 0.5F;
/*  255 */     float sinY = FastMath.sin(angle);
/*  256 */     float cosY = FastMath.cos(angle);
/*  257 */     angle = xAngle * 0.5F;
/*  258 */     float sinX = FastMath.sin(angle);
/*  259 */     float cosX = FastMath.cos(angle);
/*      */     
/*      */ 
/*  262 */     float cosYXcosZ = cosY * cosZ;
/*  263 */     float sinYXsinZ = sinY * sinZ;
/*  264 */     float cosYXsinZ = cosY * sinZ;
/*  265 */     float sinYXcosZ = sinY * cosZ;
/*      */     
/*  267 */     this.w = (cosYXcosZ * cosX - sinYXsinZ * sinX);
/*  268 */     this.x = (cosYXcosZ * sinX + sinYXsinZ * cosX);
/*  269 */     this.y = (sinYXcosZ * cosX + cosYXsinZ * sinX);
/*  270 */     this.z = (cosYXsinZ * cosX - sinYXcosZ * sinX);
/*      */     
/*  272 */     normalizeLocal();
/*  273 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] toAngles(float[] angles)
/*      */   {
/*  288 */     if (angles == null) {
/*  289 */       angles = new float[3];
/*  290 */     } else if (angles.length != 3) {
/*  291 */       throw new IllegalArgumentException("Angles array must have three elements");
/*      */     }
/*      */     
/*  294 */     float sqw = this.w * this.w;
/*  295 */     float sqx = this.x * this.x;
/*  296 */     float sqy = this.y * this.y;
/*  297 */     float sqz = this.z * this.z;
/*  298 */     float unit = sqx + sqy + sqz + sqw;
/*      */     
/*  300 */     float test = this.x * this.y + this.z * this.w;
/*  301 */     if (test > 0.499D * unit) {
/*  302 */       angles[1] = (2.0F * FastMath.atan2(this.x, this.w));
/*  303 */       angles[2] = 1.5707964F;
/*  304 */       angles[0] = 0.0F;
/*  305 */     } else if (test < -0.499D * unit) {
/*  306 */       angles[1] = (-2.0F * FastMath.atan2(this.x, this.w));
/*  307 */       angles[2] = -1.5707964F;
/*  308 */       angles[0] = 0.0F;
/*      */     } else {
/*  310 */       angles[1] = FastMath.atan2(2.0F * this.y * this.w - 2.0F * this.x * this.z, sqx - sqy - sqz + sqw);
/*  311 */       angles[2] = FastMath.asin(2.0F * test / unit);
/*  312 */       angles[0] = FastMath.atan2(2.0F * this.x * this.w - 2.0F * this.y * this.z, -sqx + sqy - sqz + sqw);
/*      */     }
/*  314 */     return angles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromRotationMatrix(Matrix3f matrix)
/*      */   {
/*  326 */     return fromRotationMatrix(matrix.m00, matrix.m01, matrix.m02, matrix.m10, 
/*  327 */       matrix.m11, matrix.m12, matrix.m20, matrix.m21, matrix.m22);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromRotationMatrix(float m00, float m01, float m02, float m10, float m11, float m12, float m20, float m21, float m22)
/*      */   {
/*  339 */     float t = m00 + m11 + m22;
/*      */     
/*      */ 
/*  342 */     if (t >= 0.0F) {
/*  343 */       float s = FastMath.sqrt(t + 1.0F);
/*  344 */       this.w = (0.5F * s);
/*  345 */       s = 0.5F / s;
/*  346 */       this.x = ((m21 - m12) * s);
/*  347 */       this.y = ((m02 - m20) * s);
/*  348 */       this.z = ((m10 - m01) * s);
/*  349 */     } else if ((m00 > m11) && (m00 > m22)) {
/*  350 */       float s = FastMath.sqrt(1.0F + m00 - m11 - m22);
/*  351 */       this.x = (s * 0.5F);
/*  352 */       s = 0.5F / s;
/*  353 */       this.y = ((m10 + m01) * s);
/*  354 */       this.z = ((m02 + m20) * s);
/*  355 */       this.w = ((m21 - m12) * s);
/*  356 */     } else if (m11 > m22) {
/*  357 */       float s = FastMath.sqrt(1.0F + m11 - m00 - m22);
/*  358 */       this.y = (s * 0.5F);
/*  359 */       s = 0.5F / s;
/*  360 */       this.x = ((m10 + m01) * s);
/*  361 */       this.z = ((m21 + m12) * s);
/*  362 */       this.w = ((m02 - m20) * s);
/*      */     } else {
/*  364 */       float s = FastMath.sqrt(1.0F + m22 - m00 - m11);
/*  365 */       this.z = (s * 0.5F);
/*  366 */       s = 0.5F / s;
/*  367 */       this.x = ((m02 + m20) * s);
/*  368 */       this.y = ((m21 + m12) * s);
/*  369 */       this.w = ((m10 - m01) * s);
/*      */     }
/*      */     
/*  372 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f toRotationMatrix()
/*      */   {
/*  382 */     Matrix3f matrix = new Matrix3f();
/*  383 */     return toRotationMatrix(matrix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix3f toRotationMatrix(Matrix3f result)
/*      */   {
/*  396 */     float norm = norm();
/*      */     
/*      */ 
/*  399 */     float s = norm > 0.0F ? 2.0F / norm : norm == 1.0F ? 2.0F : 0.0F;
/*      */     
/*      */ 
/*      */ 
/*  403 */     float xs = this.x * s;
/*  404 */     float ys = this.y * s;
/*  405 */     float zs = this.z * s;
/*  406 */     float xx = this.x * xs;
/*  407 */     float xy = this.x * ys;
/*  408 */     float xz = this.x * zs;
/*  409 */     float xw = this.w * xs;
/*  410 */     float yy = this.y * ys;
/*  411 */     float yz = this.y * zs;
/*  412 */     float yw = this.w * ys;
/*  413 */     float zz = this.z * zs;
/*  414 */     float zw = this.w * zs;
/*      */     
/*      */ 
/*  417 */     result.m00 = (1.0F - (yy + zz));
/*  418 */     result.m01 = (xy - zw);
/*  419 */     result.m02 = (xz + yw);
/*  420 */     result.m10 = (xy + zw);
/*  421 */     result.m11 = (1.0F - (xx + zz));
/*  422 */     result.m12 = (yz - xw);
/*  423 */     result.m20 = (xz - yw);
/*  424 */     result.m21 = (yz + xw);
/*  425 */     result.m22 = (1.0F - (xx + yy));
/*      */     
/*  427 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f toRotationMatrix(Matrix4f result)
/*      */   {
/*  441 */     float norm = norm();
/*      */     
/*      */ 
/*  444 */     float s = norm > 0.0F ? 2.0F / norm : norm == 1.0F ? 2.0F : 0.0F;
/*      */     
/*      */ 
/*      */ 
/*  448 */     float xs = this.x * s;
/*  449 */     float ys = this.y * s;
/*  450 */     float zs = this.z * s;
/*  451 */     float xx = this.x * xs;
/*  452 */     float xy = this.x * ys;
/*  453 */     float xz = this.x * zs;
/*  454 */     float xw = this.w * xs;
/*  455 */     float yy = this.y * ys;
/*  456 */     float yz = this.y * zs;
/*  457 */     float yw = this.w * ys;
/*  458 */     float zz = this.z * zs;
/*  459 */     float zw = this.w * zs;
/*      */     
/*      */ 
/*  462 */     result.m00 = (1.0F - (yy + zz));
/*  463 */     result.m01 = (xy - zw);
/*  464 */     result.m02 = (xz + yw);
/*  465 */     result.m10 = (xy + zw);
/*  466 */     result.m11 = (1.0F - (xx + zz));
/*  467 */     result.m12 = (yz - xw);
/*  468 */     result.m20 = (xz - yw);
/*  469 */     result.m21 = (yz + xw);
/*  470 */     result.m22 = (1.0F - (xx + yy));
/*      */     
/*  472 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getRotationColumn(int i)
/*      */   {
/*  485 */     return getRotationColumn(i, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f getRotationColumn(int i, Vector3f store)
/*      */   {
/*  501 */     if (store == null) {
/*  502 */       store = new Vector3f();
/*      */     }
/*      */     
/*  505 */     float norm = norm();
/*  506 */     if (norm != 1.0F) {
/*  507 */       norm = FastMath.invSqrt(norm);
/*      */     }
/*      */     
/*  510 */     float xx = this.x * this.x * norm;
/*  511 */     float xy = this.x * this.y * norm;
/*  512 */     float xz = this.x * this.z * norm;
/*  513 */     float xw = this.x * this.w * norm;
/*  514 */     float yy = this.y * this.y * norm;
/*  515 */     float yz = this.y * this.z * norm;
/*  516 */     float yw = this.y * this.w * norm;
/*  517 */     float zz = this.z * this.z * norm;
/*  518 */     float zw = this.z * this.w * norm;
/*      */     
/*  520 */     switch (i) {
/*      */     case 0: 
/*  522 */       store.x = (1.0F - 2.0F * (yy + zz));
/*  523 */       store.y = (2.0F * (xy + zw));
/*  524 */       store.z = (2.0F * (xz - yw));
/*  525 */       break;
/*      */     case 1: 
/*  527 */       store.x = (2.0F * (xy - zw));
/*  528 */       store.y = (1.0F - 2.0F * (xx + zz));
/*  529 */       store.z = (2.0F * (yz + xw));
/*  530 */       break;
/*      */     case 2: 
/*  532 */       store.x = (2.0F * (xz + yw));
/*  533 */       store.y = (2.0F * (yz - xw));
/*  534 */       store.z = (1.0F - 2.0F * (xx + yy));
/*  535 */       break;
/*      */     default: 
/*  537 */       logger.warning("Invalid column index.");
/*  538 */       throw new IllegalArgumentException("Invalid column index. " + i);
/*      */     }
/*      */     
/*  541 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAngleAxis(float angle, Vector3f axis)
/*      */   {
/*  556 */     Vector3f normAxis = axis.normalize();
/*  557 */     fromAngleNormalAxis(angle, normAxis);
/*  558 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAngleNormalAxis(float angle, Vector3f axis)
/*      */   {
/*  571 */     if ((axis.x == 0.0F) && (axis.y == 0.0F) && (axis.z == 0.0F)) {
/*  572 */       loadIdentity();
/*      */     } else {
/*  574 */       float halfAngle = 0.5F * angle;
/*  575 */       float sin = FastMath.sin(halfAngle);
/*  576 */       this.w = FastMath.cos(halfAngle);
/*  577 */       this.x = (sin * axis.x);
/*  578 */       this.y = (sin * axis.y);
/*  579 */       this.z = (sin * axis.z);
/*      */     }
/*  581 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float toAngleAxis(Vector3f axisStore)
/*      */   {
/*  595 */     float sqrLength = this.x * this.x + this.y * this.y + this.z * this.z;
/*      */     float angle;
/*  597 */     if (sqrLength == 0.0F) {
/*  598 */       float angle = 0.0F;
/*  599 */       if (axisStore != null) {
/*  600 */         axisStore.x = 1.0F;
/*  601 */         axisStore.y = 0.0F;
/*  602 */         axisStore.z = 0.0F;
/*      */       }
/*      */     } else {
/*  605 */       angle = 2.0F * FastMath.acos(this.w);
/*  606 */       if (axisStore != null) {
/*  607 */         float invLength = 1.0F / FastMath.sqrt(sqrLength);
/*  608 */         axisStore.x = (this.x * invLength);
/*  609 */         axisStore.y = (this.y * invLength);
/*  610 */         axisStore.z = (this.z * invLength);
/*      */       }
/*      */     }
/*      */     
/*  614 */     return angle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion slerp(Quaternion q1, Quaternion q2, float t)
/*      */   {
/*  630 */     if ((q1.x == q2.x) && (q1.y == q2.y) && (q1.z == q2.z) && (q1.w == q2.w)) {
/*  631 */       set(q1);
/*  632 */       return this;
/*      */     }
/*      */     
/*  635 */     float result = q1.x * q2.x + q1.y * q2.y + q1.z * q2.z + 
/*  636 */       q1.w * q2.w;
/*      */     
/*  638 */     if (result < 0.0F)
/*      */     {
/*  640 */       q2.x = (-q2.x);
/*  641 */       q2.y = (-q2.y);
/*  642 */       q2.z = (-q2.z);
/*  643 */       q2.w = (-q2.w);
/*  644 */       result = -result;
/*      */     }
/*      */     
/*      */ 
/*  648 */     float scale0 = 1.0F - t;
/*  649 */     float scale1 = t;
/*      */     
/*      */ 
/*      */ 
/*  653 */     if (1.0F - result > 0.1F)
/*      */     {
/*  655 */       float theta = FastMath.acos(result);
/*  656 */       float invSinTheta = 1.0F / FastMath.sin(theta);
/*      */       
/*      */ 
/*      */ 
/*  660 */       scale0 = FastMath.sin((1.0F - t) * theta) * invSinTheta;
/*  661 */       scale1 = FastMath.sin(t * theta) * invSinTheta;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  667 */     this.x = (scale0 * q1.x + scale1 * q2.x);
/*  668 */     this.y = (scale0 * q1.y + scale1 * q2.y);
/*  669 */     this.z = (scale0 * q1.z + scale1 * q2.z);
/*  670 */     this.w = (scale0 * q1.w + scale1 * q2.w);
/*      */     
/*      */ 
/*  673 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void slerp(Quaternion q2, float changeAmnt)
/*      */   {
/*  686 */     if ((this.x == q2.x) && (this.y == q2.y) && (this.z == q2.z) && 
/*  687 */       (this.w == q2.w)) {
/*  688 */       return;
/*      */     }
/*      */     
/*  691 */     float result = this.x * q2.x + this.y * q2.y + this.z * q2.z + 
/*  692 */       this.w * q2.w;
/*      */     
/*  694 */     if (result < 0.0F)
/*      */     {
/*  696 */       q2.x = (-q2.x);
/*  697 */       q2.y = (-q2.y);
/*  698 */       q2.z = (-q2.z);
/*  699 */       q2.w = (-q2.w);
/*  700 */       result = -result;
/*      */     }
/*      */     
/*      */ 
/*  704 */     float scale0 = 1.0F - changeAmnt;
/*  705 */     float scale1 = changeAmnt;
/*      */     
/*      */ 
/*      */ 
/*  709 */     if (1.0F - result > 0.1F)
/*      */     {
/*      */ 
/*  712 */       float theta = FastMath.acos(result);
/*  713 */       float invSinTheta = 1.0F / FastMath.sin(theta);
/*      */       
/*      */ 
/*      */ 
/*  717 */       scale0 = FastMath.sin((1.0F - changeAmnt) * theta) * invSinTheta;
/*  718 */       scale1 = FastMath.sin(changeAmnt * theta) * invSinTheta;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  724 */     this.x = (scale0 * this.x + scale1 * q2.x);
/*  725 */     this.y = (scale0 * this.y + scale1 * q2.y);
/*  726 */     this.z = (scale0 * this.z + scale1 * q2.z);
/*  727 */     this.w = (scale0 * this.w + scale1 * q2.w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void nlerp(Quaternion q2, float blend)
/*      */   {
/*  736 */     float dot = dot(q2);
/*  737 */     float blendI = 1.0F - blend;
/*  738 */     if (dot < 0.0F) {
/*  739 */       this.x = (blendI * this.x - blend * q2.x);
/*  740 */       this.y = (blendI * this.y - blend * q2.y);
/*  741 */       this.z = (blendI * this.z - blend * q2.z);
/*  742 */       this.w = (blendI * this.w - blend * q2.w);
/*      */     } else {
/*  744 */       this.x = (blendI * this.x + blend * q2.x);
/*  745 */       this.y = (blendI * this.y + blend * q2.y);
/*  746 */       this.z = (blendI * this.z + blend * q2.z);
/*  747 */       this.w = (blendI * this.w + blend * q2.w);
/*      */     }
/*  749 */     normalizeLocal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion add(Quaternion q)
/*      */   {
/*  761 */     return new Quaternion(this.x + q.x, this.y + q.y, this.z + q.z, this.w + q.w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion addLocal(Quaternion q)
/*      */   {
/*  773 */     this.x += q.x;
/*  774 */     this.y += q.y;
/*  775 */     this.z += q.z;
/*  776 */     this.w += q.w;
/*  777 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion subtract(Quaternion q)
/*      */   {
/*  790 */     return new Quaternion(this.x - q.x, this.y - q.y, this.z - q.z, this.w - q.w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion subtractLocal(Quaternion q)
/*      */   {
/*  802 */     this.x -= q.x;
/*  803 */     this.y -= q.y;
/*  804 */     this.z -= q.z;
/*  805 */     this.w -= q.w;
/*  806 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion mult(Quaternion q)
/*      */   {
/*  819 */     return mult(q, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion mult(Quaternion q, Quaternion res)
/*      */   {
/*  837 */     if (res == null) {
/*  838 */       res = new Quaternion();
/*      */     }
/*  840 */     float qw = q.w;float qx = q.x;float qy = q.y;float qz = q.z;
/*  841 */     res.x = (this.x * qw + this.y * qz - this.z * qy + this.w * qx);
/*  842 */     res.y = (-this.x * qz + this.y * qw + this.z * qx + this.w * qy);
/*  843 */     res.z = (this.x * qy - this.y * qx + this.z * qw + this.w * qz);
/*  844 */     res.w = (-this.x * qx - this.y * qy - this.z * qz + this.w * qw);
/*  845 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void apply(Matrix3f matrix)
/*      */   {
/*  856 */     float oldX = this.x;float oldY = this.y;float oldZ = this.z;float oldW = this.w;
/*  857 */     fromRotationMatrix(matrix);
/*  858 */     float tempX = this.x;float tempY = this.y;float tempZ = this.z;float tempW = this.w;
/*      */     
/*  860 */     this.x = (oldX * tempW + oldY * tempZ - oldZ * tempY + oldW * tempX);
/*  861 */     this.y = (-oldX * tempZ + oldY * tempW + oldZ * tempX + oldW * tempY);
/*  862 */     this.z = (oldX * tempY - oldY * tempX + oldZ * tempW + oldW * tempZ);
/*  863 */     this.w = (-oldX * tempX - oldY * tempY - oldZ * tempZ + oldW * tempW);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAxes(Vector3f[] axis)
/*      */   {
/*  879 */     if (axis.length != 3) {
/*  880 */       throw new IllegalArgumentException(
/*  881 */         "Axis array must have three elements");
/*      */     }
/*  883 */     return fromAxes(axis[0], axis[1], axis[2]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion fromAxes(Vector3f xAxis, Vector3f yAxis, Vector3f zAxis)
/*      */   {
/*  899 */     return fromRotationMatrix(xAxis.x, yAxis.x, zAxis.x, xAxis.y, yAxis.y, 
/*  900 */       zAxis.y, xAxis.z, yAxis.z, zAxis.z);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void toAxes(Vector3f[] axis)
/*      */   {
/*  913 */     Matrix3f tempMat = toRotationMatrix();
/*  914 */     axis[0] = tempMat.getColumn(0, axis[0]);
/*  915 */     axis[1] = tempMat.getColumn(1, axis[1]);
/*  916 */     axis[2] = tempMat.getColumn(2, axis[2]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f v)
/*      */   {
/*  928 */     return mult(v, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multLocal(Vector3f v)
/*      */   {
/*  941 */     float tempX = this.w * this.w * v.x + 2.0F * this.y * this.w * v.z - 2.0F * this.z * this.w * v.y + this.x * this.x * v.x + 
/*  942 */       2.0F * this.y * this.x * v.y + 2.0F * this.z * this.x * v.z - this.z * this.z * v.x - this.y * this.y * v.x;
/*  943 */     float tempY = 2.0F * this.x * this.y * v.x + this.y * this.y * v.y + 2.0F * this.z * this.y * v.z + 2.0F * this.w * this.z * 
/*  944 */       v.x - this.z * this.z * v.y + this.w * this.w * v.y - 2.0F * this.x * this.w * v.z - this.x * this.x * 
/*  945 */       v.y;
/*  946 */     v.z = 
/*  947 */       (2.0F * this.x * this.z * v.x + 2.0F * this.y * this.z * v.y + this.z * this.z * v.z - 2.0F * this.w * this.y * v.x - this.y * this.y * v.z + 2.0F * this.w * this.x * v.y - this.x * this.x * v.z + this.w * this.w * v.z);
/*  948 */     v.x = tempX;
/*  949 */     v.y = tempY;
/*  950 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion multLocal(Quaternion q)
/*      */   {
/*  963 */     float x1 = this.x * q.w + this.y * q.z - this.z * q.y + this.w * q.x;
/*  964 */     float y1 = -this.x * q.z + this.y * q.w + this.z * q.x + this.w * q.y;
/*  965 */     float z1 = this.x * q.y - this.y * q.x + this.z * q.w + this.w * q.z;
/*  966 */     this.w = (-this.x * q.x - this.y * q.y - this.z * q.z + this.w * q.w);
/*  967 */     this.x = x1;
/*  968 */     this.y = y1;
/*  969 */     this.z = z1;
/*  970 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion multLocal(float qx, float qy, float qz, float qw)
/*      */   {
/*  990 */     float x1 = this.x * qw + this.y * qz - this.z * qy + this.w * qx;
/*  991 */     float y1 = -this.x * qz + this.y * qw + this.z * qx + this.w * qy;
/*  992 */     float z1 = this.x * qy - this.y * qx + this.z * qw + this.w * qz;
/*  993 */     this.w = (-this.x * qx - this.y * qy - this.z * qz + this.w * qw);
/*  994 */     this.x = x1;
/*  995 */     this.y = y1;
/*  996 */     this.z = z1;
/*  997 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f v, Vector3f store)
/*      */   {
/* 1012 */     if (store == null) {
/* 1013 */       store = new Vector3f();
/*      */     }
/* 1015 */     if ((v.x == 0.0F) && (v.y == 0.0F) && (v.z == 0.0F)) {
/* 1016 */       store.set(0.0F, 0.0F, 0.0F);
/*      */     } else {
/* 1018 */       float vx = v.x;float vy = v.y;float vz = v.z;
/* 1019 */       store.x = 
/*      */       
/* 1021 */         (this.w * this.w * vx + 2.0F * this.y * this.w * vz - 2.0F * this.z * this.w * vy + this.x * this.x * vx + 2.0F * this.y * this.x * vy + 2.0F * this.z * this.x * vz - this.z * this.z * vx - this.y * this.y * vx);
/* 1022 */       store.y = 
/*      */       
/* 1024 */         (2.0F * this.x * this.y * vx + this.y * this.y * vy + 2.0F * this.z * this.y * vz + 2.0F * this.w * this.z * vx - this.z * this.z * vy + this.w * this.w * vy - 2.0F * this.x * this.w * vz - this.x * this.x * vy);
/* 1025 */       store.z = 
/*      */       
/* 1027 */         (2.0F * this.x * this.z * vx + 2.0F * this.y * this.z * vy + this.z * this.z * vz - 2.0F * this.w * this.y * vx - this.y * this.y * vz + 2.0F * this.w * this.x * vy - this.x * this.x * vz + this.w * this.w * vz);
/*      */     }
/* 1029 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion mult(float scalar)
/*      */   {
/* 1041 */     return new Quaternion(scalar * this.x, scalar * this.y, scalar * this.z, scalar * this.w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion multLocal(float scalar)
/*      */   {
/* 1053 */     this.w *= scalar;
/* 1054 */     this.x *= scalar;
/* 1055 */     this.y *= scalar;
/* 1056 */     this.z *= scalar;
/* 1057 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float dot(Quaternion q)
/*      */   {
/* 1069 */     return this.w * q.w + this.x * q.x + this.y * q.y + this.z * q.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float norm()
/*      */   {
/* 1079 */     return this.w * this.w + this.x * this.x + this.y * this.y + this.z * this.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion normalizeLocal()
/*      */   {
/* 1101 */     float n = FastMath.invSqrt(norm());
/* 1102 */     this.x *= n;
/* 1103 */     this.y *= n;
/* 1104 */     this.z *= n;
/* 1105 */     this.w *= n;
/* 1106 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion inverse()
/*      */   {
/* 1118 */     float norm = norm();
/* 1119 */     if (norm > 0.0D) {
/* 1120 */       float invNorm = 1.0F / norm;
/* 1121 */       return new Quaternion(-this.x * invNorm, -this.y * invNorm, -this.z * invNorm, this.w * 
/* 1122 */         invNorm);
/*      */     }
/*      */     
/* 1125 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion inverseLocal()
/*      */   {
/* 1136 */     float norm = norm();
/* 1137 */     if (norm > 0.0D) {
/* 1138 */       float invNorm = 1.0F / norm;
/* 1139 */       this.x *= -invNorm;
/* 1140 */       this.y *= -invNorm;
/* 1141 */       this.z *= -invNorm;
/* 1142 */       this.w *= invNorm;
/*      */     }
/* 1144 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void negate()
/*      */   {
/* 1152 */     this.x *= -1.0F;
/* 1153 */     this.y *= -1.0F;
/* 1154 */     this.z *= -1.0F;
/* 1155 */     this.w *= -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1170 */     return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1183 */     if (!(o instanceof Quaternion)) {
/* 1184 */       return false;
/*      */     }
/*      */     
/* 1187 */     if (this == o) {
/* 1188 */       return true;
/*      */     }
/*      */     
/* 1191 */     Quaternion comp = (Quaternion)o;
/* 1192 */     if (Float.compare(this.x, comp.x) != 0) {
/* 1193 */       return false;
/*      */     }
/* 1195 */     if (Float.compare(this.y, comp.y) != 0) {
/* 1196 */       return false;
/*      */     }
/* 1198 */     if (Float.compare(this.z, comp.z) != 0) {
/* 1199 */       return false;
/*      */     }
/* 1201 */     if (Float.compare(this.w, comp.w) != 0) {
/* 1202 */       return false;
/*      */     }
/* 1204 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1218 */     int hash = 37;
/* 1219 */     hash = 37 * hash + Float.floatToIntBits(this.x);
/* 1220 */     hash = 37 * hash + Float.floatToIntBits(this.y);
/* 1221 */     hash = 37 * hash + Float.floatToIntBits(this.z);
/* 1222 */     hash = 37 * hash + Float.floatToIntBits(this.w);
/* 1223 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readExternal(ObjectInput in)
/*      */     throws IOException
/*      */   {
/* 1239 */     this.x = in.readFloat();
/* 1240 */     this.y = in.readFloat();
/* 1241 */     this.z = in.readFloat();
/* 1242 */     this.w = in.readFloat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeExternal(ObjectOutput out)
/*      */     throws IOException
/*      */   {
/* 1257 */     out.writeFloat(this.x);
/* 1258 */     out.writeFloat(this.y);
/* 1259 */     out.writeFloat(this.z);
/* 1260 */     out.writeFloat(this.w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion opposite()
/*      */   {
/* 1270 */     return opposite(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion opposite(Quaternion store)
/*      */   {
/* 1283 */     if (store == null) {
/* 1284 */       store = new Quaternion();
/*      */     }
/*      */     
/* 1287 */     Vector3f axis = new Vector3f();
/* 1288 */     float angle = toAngleAxis(axis);
/*      */     
/* 1290 */     store.fromAngleAxis(3.1415927F + angle, axis);
/* 1291 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion oppositeLocal()
/*      */   {
/* 1300 */     return opposite(this);
/*      */   }
/*      */   
/*      */   public Quaternion clone()
/*      */   {
/*      */     try {
/* 1306 */       return (Quaternion)super.clone();
/*      */     } catch (CloneNotSupportedException e) {
/* 1308 */       throw new AssertionError();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Quaternion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */