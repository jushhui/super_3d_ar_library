/*     */ package com.jme3.math;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FastMath
/*     */ {
/*     */   public static final double DBL_EPSILON = 2.220446049250313E-16D;
/*     */   public static final float FLT_EPSILON = 1.1920929E-7F;
/*     */   public static final float ZERO_TOLERANCE = 1.0E-4F;
/*     */   public static final float ONE_THIRD = 0.33333334F;
/*     */   public static final float PI = 3.1415927F;
/*     */   public static final float TWO_PI = 6.2831855F;
/*     */   public static final float HALF_PI = 1.5707964F;
/*     */   public static final float QUARTER_PI = 0.7853982F;
/*     */   public static final float INV_PI = 0.31830987F;
/*     */   public static final float INV_TWO_PI = 0.15915494F;
/*     */   public static final float DEG_TO_RAD = 0.017453292F;
/*     */   public static final float RAD_TO_DEG = 57.295776F;
/*  71 */   public static final Random rand = new Random(System.currentTimeMillis());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPowerOfTwo(int number)
/*     */   {
/*  87 */     return (number > 0) && ((number & number - 1) == 0);
/*     */   }
/*     */   
/*     */   public static int nearestPowerOfTwo(int number) {
/*  91 */     return (int)Math.pow(2.0D, Math.ceil(Math.log(number) / Math.log(2.0D)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float interpolateLinear(float scale, float startValue, float endValue)
/*     */   {
/* 107 */     if (startValue == endValue) {
/* 108 */       return startValue;
/*     */     }
/* 110 */     if (scale <= 0.0F) {
/* 111 */       return startValue;
/*     */     }
/* 113 */     if (scale >= 1.0F) {
/* 114 */       return endValue;
/*     */     }
/* 116 */     return (1.0F - scale) * startValue + scale * endValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateLinear(float scale, Vector3f startValue, Vector3f endValue, Vector3f store)
/*     */   {
/* 133 */     if (store == null) {
/* 134 */       store = new Vector3f();
/*     */     }
/* 136 */     store.x = interpolateLinear(scale, startValue.x, endValue.x);
/* 137 */     store.y = interpolateLinear(scale, startValue.y, endValue.y);
/* 138 */     store.z = interpolateLinear(scale, startValue.z, endValue.z);
/* 139 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateLinear(float scale, Vector3f startValue, Vector3f endValue)
/*     */   {
/* 155 */     return interpolateLinear(scale, startValue, endValue, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float extrapolateLinear(float scale, float startValue, float endValue)
/*     */   {
/* 172 */     return (1.0F - scale) * startValue + scale * endValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f extrapolateLinear(float scale, Vector3f startValue, Vector3f endValue, Vector3f store)
/*     */   {
/* 187 */     if (store == null) {
/* 188 */       store = new Vector3f();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 193 */     store.x = extrapolateLinear(scale, startValue.x, endValue.x);
/* 194 */     store.y = extrapolateLinear(scale, startValue.y, endValue.y);
/* 195 */     store.z = extrapolateLinear(scale, startValue.z, endValue.z);
/* 196 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f extrapolateLinear(float scale, Vector3f startValue, Vector3f endValue)
/*     */   {
/* 210 */     return extrapolateLinear(scale, startValue, endValue, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float interpolateCatmullRom(float u, float T, float p0, float p1, float p2, float p3)
/*     */   {
/* 231 */     float c1 = p1;
/* 232 */     float c2 = -1.0F * T * p0 + T * p2;
/* 233 */     float c3 = 2.0F * T * p0 + (T - 3.0F) * p1 + (3.0F - 2.0F * T) * p2 + -T * p3;
/* 234 */     float c4 = -T * p0 + (2.0F - T) * p1 + (T - 2.0F) * p2 + T * p3;
/*     */     
/* 236 */     return ((c4 * u + c3) * u + c2) * u + c1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateCatmullRom(float u, float T, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, Vector3f store)
/*     */   {
/* 257 */     if (store == null) {
/* 258 */       store = new Vector3f();
/*     */     }
/* 260 */     store.x = interpolateCatmullRom(u, T, p0.x, p1.x, p2.x, p3.x);
/* 261 */     store.y = interpolateCatmullRom(u, T, p0.y, p1.y, p2.y, p3.y);
/* 262 */     store.z = interpolateCatmullRom(u, T, p0.z, p1.z, p2.z, p3.z);
/* 263 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateCatmullRom(float u, float T, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3)
/*     */   {
/* 283 */     return interpolateCatmullRom(u, T, p0, p1, p2, p3, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float interpolateBezier(float u, float p0, float p1, float p2, float p3)
/*     */   {
/* 302 */     float oneMinusU = 1.0F - u;
/* 303 */     float oneMinusU2 = oneMinusU * oneMinusU;
/* 304 */     float u2 = u * u;
/* 305 */     return p0 * oneMinusU2 * oneMinusU + 
/* 306 */       3.0F * p1 * u * oneMinusU2 + 
/* 307 */       3.0F * p2 * u2 * oneMinusU + 
/* 308 */       p3 * u2 * u;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateBezier(float u, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, Vector3f store)
/*     */   {
/* 328 */     if (store == null) {
/* 329 */       store = new Vector3f();
/*     */     }
/* 331 */     store.x = interpolateBezier(u, p0.x, p1.x, p2.x, p3.x);
/* 332 */     store.y = interpolateBezier(u, p0.y, p1.y, p2.y, p3.y);
/* 333 */     store.z = interpolateBezier(u, p0.z, p1.z, p2.z, p3.z);
/* 334 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f interpolateBezier(float u, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3)
/*     */   {
/* 353 */     return interpolateBezier(u, p0, p1, p2, p3, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float getCatmullRomP1toP2Length(Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, float startRange, float endRange, float curveTension)
/*     */   {
/* 369 */     float epsilon = 0.001F;
/* 370 */     float middleValue = (startRange + endRange) * 0.5F;
/* 371 */     Vector3f start = p1.clone();
/* 372 */     if (startRange != 0.0F) {
/* 373 */       interpolateCatmullRom(startRange, curveTension, p0, p1, p2, p3, start);
/*     */     }
/* 375 */     Vector3f end = p2.clone();
/* 376 */     if (endRange != 1.0F) {
/* 377 */       interpolateCatmullRom(endRange, curveTension, p0, p1, p2, p3, end);
/*     */     }
/* 379 */     Vector3f middle = interpolateCatmullRom(middleValue, curveTension, p0, p1, p2, p3);
/* 380 */     float l = end.subtract(start).length();
/* 381 */     float l1 = middle.subtract(start).length();
/* 382 */     float l2 = end.subtract(middle).length();
/* 383 */     float len = l1 + l2;
/* 384 */     if (l + epsilon < len) {
/* 385 */       l1 = getCatmullRomP1toP2Length(p0, p1, p2, p3, startRange, middleValue, curveTension);
/* 386 */       l2 = getCatmullRomP1toP2Length(p0, p1, p2, p3, middleValue, endRange, curveTension);
/*     */     }
/* 388 */     l = l1 + l2;
/* 389 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float getBezierP1toP2Length(Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3)
/*     */   {
/* 401 */     float delta = 0.02F;float t = 0.0F;float result = 0.0F;
/* 402 */     Vector3f v1 = p0.clone();Vector3f v2 = new Vector3f();
/* 403 */     while (t <= 1.0F) {
/* 404 */       interpolateBezier(t, p0, p1, p2, p3, v2);
/* 405 */       result += v1.subtractLocal(v2).length();
/* 406 */       v1.set(v2);
/* 407 */       t += delta;
/*     */     }
/* 409 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float acos(float fValue)
/*     */   {
/* 422 */     if (-1.0F < fValue) {
/* 423 */       if (fValue < 1.0F) {
/* 424 */         return (float)Math.acos(fValue);
/*     */       }
/*     */       
/* 427 */       return 0.0F;
/*     */     }
/*     */     
/* 430 */     return 3.1415927F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float asin(float fValue)
/*     */   {
/* 443 */     if (-1.0F < fValue) {
/* 444 */       if (fValue < 1.0F) {
/* 445 */         return (float)Math.asin(fValue);
/*     */       }
/*     */       
/* 448 */       return 1.5707964F;
/*     */     }
/*     */     
/* 451 */     return -1.5707964F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float atan(float fValue)
/*     */   {
/* 461 */     return (float)Math.atan(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float atan2(float fY, float fX)
/*     */   {
/* 472 */     return (float)Math.atan2(fY, fX);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float ceil(float fValue)
/*     */   {
/* 482 */     return (float)Math.ceil(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float cos(float v)
/*     */   {
/* 492 */     return (float)Math.cos(v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float sin(float v)
/*     */   {
/* 502 */     return (float)Math.sin(v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float exp(float fValue)
/*     */   {
/* 512 */     return (float)Math.exp(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float abs(float fValue)
/*     */   {
/* 522 */     if (fValue < 0.0F) {
/* 523 */       return -fValue;
/*     */     }
/* 525 */     return fValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float floor(float fValue)
/*     */   {
/* 535 */     return (float)Math.floor(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float invSqrt(float fValue)
/*     */   {
/* 545 */     return (float)(1.0D / Math.sqrt(fValue));
/*     */   }
/*     */   
/*     */   public static float fastInvSqrt(float x) {
/* 549 */     float xhalf = 0.5F * x;
/* 550 */     int i = Float.floatToIntBits(x);
/* 551 */     i = 1597463174 - (i >> 1);
/* 552 */     x = Float.intBitsToFloat(i);
/* 553 */     x *= (1.5F - xhalf * x * x);
/* 554 */     return x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float log(float fValue)
/*     */   {
/* 564 */     return (float)Math.log(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float log(float value, float base)
/*     */   {
/* 575 */     return (float)(Math.log(value) / Math.log(base));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float pow(float fBase, float fExponent)
/*     */   {
/* 586 */     return (float)Math.pow(fBase, fExponent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float sqr(float fValue)
/*     */   {
/* 595 */     return fValue * fValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float sqrt(float fValue)
/*     */   {
/* 605 */     return (float)Math.sqrt(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float tan(float fValue)
/*     */   {
/* 616 */     return (float)Math.tan(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int sign(int iValue)
/*     */   {
/* 625 */     if (iValue > 0) {
/* 626 */       return 1;
/*     */     }
/* 628 */     if (iValue < 0) {
/* 629 */       return -1;
/*     */     }
/* 631 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float sign(float fValue)
/*     */   {
/* 640 */     return Math.signum(fValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int counterClockwise(Vector2f p0, Vector2f p1, Vector2f p2)
/*     */   {
/* 653 */     float dx1 = p1.x - p0.x;
/* 654 */     float dy1 = p1.y - p0.y;
/* 655 */     float dx2 = p2.x - p0.x;
/* 656 */     float dy2 = p2.y - p0.y;
/* 657 */     if (dx1 * dy2 > dy1 * dx2) {
/* 658 */       return 1;
/*     */     }
/* 660 */     if (dx1 * dy2 < dy1 * dx2) {
/* 661 */       return -1;
/*     */     }
/* 663 */     if ((dx1 * dx2 < 0.0F) || (dy1 * dy2 < 0.0F)) {
/* 664 */       return -1;
/*     */     }
/* 666 */     if (dx1 * dx1 + dy1 * dy1 < dx2 * dx2 + dy2 * dy2) {
/* 667 */       return 1;
/*     */     }
/* 669 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int pointInsideTriangle(Vector2f t0, Vector2f t1, Vector2f t2, Vector2f p)
/*     */   {
/* 682 */     int val1 = counterClockwise(t0, t1, p);
/* 683 */     if (val1 == 0) {
/* 684 */       return 1;
/*     */     }
/* 686 */     int val2 = counterClockwise(t1, t2, p);
/* 687 */     if (val2 == 0) {
/* 688 */       return 1;
/*     */     }
/* 690 */     if (val2 != val1) {
/* 691 */       return 0;
/*     */     }
/* 693 */     int val3 = counterClockwise(t2, t0, p);
/* 694 */     if (val3 == 0) {
/* 695 */       return 1;
/*     */     }
/* 697 */     if (val3 != val1) {
/* 698 */       return 0;
/*     */     }
/* 700 */     return val3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f computeNormal(Vector3f v1, Vector3f v2, Vector3f v3)
/*     */   {
/* 711 */     Vector3f a1 = v1.subtract(v2);
/* 712 */     Vector3f a2 = v3.subtract(v2);
/* 713 */     return a2.crossLocal(a1).normalizeLocal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float determinant(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33)
/*     */   {
/* 724 */     double det01 = m20 * m31 - m21 * m30;
/* 725 */     double det02 = m20 * m32 - m22 * m30;
/* 726 */     double det03 = m20 * m33 - m23 * m30;
/* 727 */     double det12 = m21 * m32 - m22 * m31;
/* 728 */     double det13 = m21 * m33 - m23 * m31;
/* 729 */     double det23 = m22 * m33 - m23 * m32;
/* 730 */     return (float)(m00 * (m11 * det23 - m12 * det13 + m13 * det12) - m01 * (
/* 731 */       m10 * det23 - m12 * det03 + m13 * det02) + m02 * (
/* 732 */       m10 * det13 - m11 * det03 + m13 * det01) - m03 * (
/* 733 */       m10 * det12 - m11 * det02 + m12 * det01));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float nextRandomFloat()
/*     */   {
/* 743 */     return rand.nextFloat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int nextRandomInt(int min, int max)
/*     */   {
/* 753 */     return (int)(nextRandomFloat() * (max - min + 1)) + min;
/*     */   }
/*     */   
/*     */   public static int nextRandomInt() {
/* 757 */     return rand.nextInt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f sphericalToCartesian(Vector3f sphereCoords, Vector3f store)
/*     */   {
/* 766 */     if (store == null) {
/* 767 */       store = new Vector3f();
/*     */     }
/* 769 */     store.y = (sphereCoords.x * sin(sphereCoords.z));
/* 770 */     float a = sphereCoords.x * cos(sphereCoords.z);
/* 771 */     store.x = (a * cos(sphereCoords.y));
/* 772 */     store.z = (a * sin(sphereCoords.y));
/*     */     
/* 774 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f cartesianToSpherical(Vector3f cartCoords, Vector3f store)
/*     */   {
/* 784 */     if (store == null) {
/* 785 */       store = new Vector3f();
/*     */     }
/* 787 */     float x = cartCoords.x;
/* 788 */     if (x == 0.0F) {
/* 789 */       x = 1.1920929E-7F;
/*     */     }
/* 791 */     store.x = sqrt(x * x + 
/* 792 */       cartCoords.y * cartCoords.y + 
/* 793 */       cartCoords.z * cartCoords.z);
/* 794 */     store.y = atan(cartCoords.z / x);
/* 795 */     if (x < 0.0F) {
/* 796 */       store.y += 3.1415927F;
/*     */     }
/* 798 */     store.z = asin(cartCoords.y / store.x);
/* 799 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f sphericalToCartesianZ(Vector3f sphereCoords, Vector3f store)
/*     */   {
/* 808 */     if (store == null) {
/* 809 */       store = new Vector3f();
/*     */     }
/* 811 */     store.z = (sphereCoords.x * sin(sphereCoords.z));
/* 812 */     float a = sphereCoords.x * cos(sphereCoords.z);
/* 813 */     store.x = (a * cos(sphereCoords.y));
/* 814 */     store.y = (a * sin(sphereCoords.y));
/*     */     
/* 816 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector3f cartesianZToSpherical(Vector3f cartCoords, Vector3f store)
/*     */   {
/* 826 */     if (store == null) {
/* 827 */       store = new Vector3f();
/*     */     }
/* 829 */     float x = cartCoords.x;
/* 830 */     if (x == 0.0F) {
/* 831 */       x = 1.1920929E-7F;
/*     */     }
/* 833 */     store.x = sqrt(x * x + 
/* 834 */       cartCoords.y * cartCoords.y + 
/* 835 */       cartCoords.z * cartCoords.z);
/* 836 */     store.z = atan(cartCoords.z / x);
/* 837 */     if (x < 0.0F) {
/* 838 */       store.z += 3.1415927F;
/*     */     }
/* 840 */     store.y = asin(cartCoords.y / store.x);
/* 841 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float normalize(float val, float min, float max)
/*     */   {
/* 852 */     if ((Float.isInfinite(val)) || (Float.isNaN(val))) {
/* 853 */       return 0.0F;
/*     */     }
/* 855 */     float range = max - min;
/* 856 */     while (val > max) {
/* 857 */       val -= range;
/*     */     }
/* 859 */     while (val < min) {
/* 860 */       val += range;
/*     */     }
/* 862 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float copysign(float x, float y)
/*     */   {
/* 873 */     if ((y >= 0.0F) && (x <= 0.0F))
/* 874 */       return -x;
/* 875 */     if ((y < 0.0F) && (x >= 0.0F)) {
/* 876 */       return -x;
/*     */     }
/* 878 */     return x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float clamp(float input, float min, float max)
/*     */   {
/* 891 */     return input > max ? max : input < min ? min : input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float saturate(float input)
/*     */   {
/* 901 */     return clamp(input, 0.0F, 1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static float convertHalfToFloat(short half)
/*     */   {
/* 915 */     switch (half) {
/*     */     case 0: 
/* 917 */       return 0.0F;
/*     */     case 32768: 
/* 919 */       return -0.0F;
/*     */     case 31744: 
/* 921 */       return Float.POSITIVE_INFINITY;
/*     */     case 64512: 
/* 923 */       return Float.NEGATIVE_INFINITY;
/*     */     }
/*     */     
/* 926 */     return Float.intBitsToFloat((half & 0x8000) << 16 | 
/* 927 */       (half & 0x7C00) + 114688 << 13 | 
/* 928 */       (half & 0x3FF) << 13);
/*     */   }
/*     */   
/*     */   public static short convertFloatToHalf(float flt)
/*     */   {
/* 933 */     if (Float.isNaN(flt))
/* 934 */       throw new UnsupportedOperationException("NaN to half conversion not supported!");
/* 935 */     if (flt == Float.POSITIVE_INFINITY)
/* 936 */       return 31744;
/* 937 */     if (flt == Float.NEGATIVE_INFINITY)
/* 938 */       return 64512;
/* 939 */     if (flt == 0.0F)
/* 940 */       return 0;
/* 941 */     if (flt == -0.0F)
/* 942 */       return Short.MIN_VALUE;
/* 943 */     if (flt > 65504.0F)
/*     */     {
/* 945 */       return 31743; }
/* 946 */     if (flt < -65504.0F)
/* 947 */       return 64511;
/* 948 */     if ((flt > 0.0F) && (flt < 5.96046E-8F))
/* 949 */       return 1;
/* 950 */     if ((flt < 0.0F) && (flt > -5.96046E-8F)) {
/* 951 */       return 32769;
/*     */     }
/*     */     
/* 954 */     int f = Float.floatToIntBits(flt);
/* 955 */     return (short)(f >> 16 & 0x8000 | 
/* 956 */       (f & 0x7F800000) - 939524096 >> 13 & 0x7C00 | 
/* 957 */       f >> 13 & 0x3FF);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\FastMath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */