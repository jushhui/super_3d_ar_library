/*     */ package com.jme3.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Vector4f
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*  49 */   private static final Logger logger = Logger.getLogger(Vector4f.class.getName());
/*     */   
/*  51 */   public static final Vector4f ZERO = new Vector4f(0.0F, 0.0F, 0.0F, 0.0F);
/*  52 */   public static final Vector4f NAN = new Vector4f(NaN.0F, NaN.0F, NaN.0F, NaN.0F);
/*  53 */   public static final Vector4f UNIT_X = new Vector4f(1.0F, 0.0F, 0.0F, 0.0F);
/*  54 */   public static final Vector4f UNIT_Y = new Vector4f(0.0F, 1.0F, 0.0F, 0.0F);
/*  55 */   public static final Vector4f UNIT_Z = new Vector4f(0.0F, 0.0F, 1.0F, 0.0F);
/*  56 */   public static final Vector4f UNIT_W = new Vector4f(0.0F, 0.0F, 0.0F, 1.0F);
/*  57 */   public static final Vector4f UNIT_XYZW = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  58 */   public static final Vector4f POSITIVE_INFINITY = new Vector4f(
/*  59 */     Float.POSITIVE_INFINITY, 
/*  60 */     Float.POSITIVE_INFINITY, 
/*  61 */     Float.POSITIVE_INFINITY, 
/*  62 */     Float.POSITIVE_INFINITY);
/*  63 */   public static final Vector4f NEGATIVE_INFINITY = new Vector4f(
/*  64 */     Float.NEGATIVE_INFINITY, 
/*  65 */     Float.NEGATIVE_INFINITY, 
/*  66 */     Float.NEGATIVE_INFINITY, 
/*  67 */     Float.NEGATIVE_INFINITY);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float z;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float w;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f()
/*     */   {
/*  95 */     this.x = (this.y = this.z = this.w = 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f(float x, float y, float z, float w)
/*     */   {
/* 112 */     this.x = x;
/* 113 */     this.y = y;
/* 114 */     this.z = z;
/* 115 */     this.w = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f(Vector4f copy)
/*     */   {
/* 124 */     set(copy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f set(float x, float y, float z, float w)
/*     */   {
/* 142 */     this.x = x;
/* 143 */     this.y = y;
/* 144 */     this.z = z;
/* 145 */     this.w = w;
/* 146 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f set(Vector4f vect)
/*     */   {
/* 158 */     this.x = vect.x;
/* 159 */     this.y = vect.y;
/* 160 */     this.z = vect.z;
/* 161 */     this.w = vect.w;
/* 162 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f add(Vector4f vec)
/*     */   {
/* 176 */     if (vec == null) {
/* 177 */       logger.warning("Provided vector is null, null returned.");
/* 178 */       return null;
/*     */     }
/* 180 */     return new Vector4f(this.x + vec.x, this.y + vec.y, this.z + vec.z, this.w + vec.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f add(Vector4f vec, Vector4f result)
/*     */   {
/* 195 */     this.x += vec.x;
/* 196 */     this.y += vec.y;
/* 197 */     this.z += vec.z;
/* 198 */     this.w += vec.w;
/* 199 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f addLocal(Vector4f vec)
/*     */   {
/* 212 */     if (vec == null) {
/* 213 */       logger.warning("Provided vector is null, null returned.");
/* 214 */       return null;
/*     */     }
/* 216 */     this.x += vec.x;
/* 217 */     this.y += vec.y;
/* 218 */     this.z += vec.z;
/* 219 */     this.w += vec.w;
/* 220 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f add(float addX, float addY, float addZ, float addW)
/*     */   {
/* 237 */     return new Vector4f(this.x + addX, this.y + addY, this.z + addZ, this.w + addW);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f addLocal(float addX, float addY, float addZ, float addW)
/*     */   {
/* 254 */     this.x += addX;
/* 255 */     this.y += addY;
/* 256 */     this.z += addZ;
/* 257 */     this.w += addW;
/* 258 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f scaleAdd(float scalar, Vector4f add)
/*     */   {
/* 272 */     this.x = (this.x * scalar + add.x);
/* 273 */     this.y = (this.y * scalar + add.y);
/* 274 */     this.z = (this.z * scalar + add.z);
/* 275 */     this.w = (this.w * scalar + add.w);
/* 276 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f scaleAdd(float scalar, Vector4f mult, Vector4f add)
/*     */   {
/* 292 */     this.x = (mult.x * scalar + add.x);
/* 293 */     this.y = (mult.y * scalar + add.y);
/* 294 */     this.z = (mult.z * scalar + add.z);
/* 295 */     this.w = (mult.w * scalar + add.w);
/* 296 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float dot(Vector4f vec)
/*     */   {
/* 309 */     if (vec == null) {
/* 310 */       logger.warning("Provided vector is null, 0 returned.");
/* 311 */       return 0.0F;
/*     */     }
/* 313 */     return this.x * vec.x + this.y * vec.y + this.z * vec.z + this.w * vec.w;
/*     */   }
/*     */   
/*     */   public Vector4f project(Vector4f other) {
/* 317 */     float n = dot(other);
/* 318 */     float d = other.lengthSquared();
/* 319 */     return new Vector4f(other).normalizeLocal().multLocal(n / d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnitVector()
/*     */   {
/* 330 */     float len = length();
/* 331 */     return (0.99F < len) && (len < 1.01F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float length()
/*     */   {
/* 340 */     return FastMath.sqrt(lengthSquared());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float lengthSquared()
/*     */   {
/* 350 */     return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float distanceSquared(Vector4f v)
/*     */   {
/* 361 */     double dx = this.x - v.x;
/* 362 */     double dy = this.y - v.y;
/* 363 */     double dz = this.z - v.z;
/* 364 */     double dw = this.w - v.w;
/* 365 */     return (float)(dx * dx + dy * dy + dz * dz + dw * dw);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float distance(Vector4f v)
/*     */   {
/* 376 */     return FastMath.sqrt(distanceSquared(v));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f mult(float scalar)
/*     */   {
/* 389 */     return new Vector4f(this.x * scalar, this.y * scalar, this.z * scalar, this.w * scalar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f mult(float scalar, Vector4f product)
/*     */   {
/* 402 */     if (product == null) {
/* 403 */       product = new Vector4f();
/*     */     }
/*     */     
/* 406 */     this.x *= scalar;
/* 407 */     this.y *= scalar;
/* 408 */     this.z *= scalar;
/* 409 */     this.w *= scalar;
/* 410 */     return product;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f multLocal(float scalar)
/*     */   {
/* 422 */     this.x *= scalar;
/* 423 */     this.y *= scalar;
/* 424 */     this.z *= scalar;
/* 425 */     this.w *= scalar;
/* 426 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f multLocal(Vector4f vec)
/*     */   {
/* 439 */     if (vec == null) {
/* 440 */       logger.warning("Provided vector is null, null returned.");
/* 441 */       return null;
/*     */     }
/* 443 */     this.x *= vec.x;
/* 444 */     this.y *= vec.y;
/* 445 */     this.z *= vec.z;
/* 446 */     this.w *= vec.w;
/* 447 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f multLocal(float x, float y, float z, float w)
/*     */   {
/* 462 */     this.x *= x;
/* 463 */     this.y *= y;
/* 464 */     this.z *= z;
/* 465 */     this.w *= w;
/* 466 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f mult(Vector4f vec)
/*     */   {
/* 479 */     if (vec == null) {
/* 480 */       logger.warning("Provided vector is null, null returned.");
/* 481 */       return null;
/*     */     }
/* 483 */     return mult(vec, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f mult(Vector4f vec, Vector4f store)
/*     */   {
/* 497 */     if (vec == null) {
/* 498 */       logger.warning("Provided vector is null, null returned.");
/* 499 */       return null;
/*     */     }
/* 501 */     if (store == null) store = new Vector4f();
/* 502 */     return store.set(this.x * vec.x, this.y * vec.y, this.z * vec.z, this.w * vec.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f divide(float scalar)
/*     */   {
/* 514 */     scalar = 1.0F / scalar;
/* 515 */     return new Vector4f(this.x * scalar, this.y * scalar, this.z * scalar, this.w * scalar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f divideLocal(float scalar)
/*     */   {
/* 528 */     scalar = 1.0F / scalar;
/* 529 */     this.x *= scalar;
/* 530 */     this.y *= scalar;
/* 531 */     this.z *= scalar;
/* 532 */     this.w *= scalar;
/* 533 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f divide(Vector4f scalar)
/*     */   {
/* 545 */     return new Vector4f(this.x / scalar.x, this.y / scalar.y, this.z / scalar.z, this.w / scalar.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f divideLocal(Vector4f scalar)
/*     */   {
/* 558 */     this.x /= scalar.x;
/* 559 */     this.y /= scalar.y;
/* 560 */     this.z /= scalar.z;
/* 561 */     this.w /= scalar.w;
/* 562 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f negate()
/*     */   {
/* 573 */     return new Vector4f(-this.x, -this.y, -this.z, -this.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f negateLocal()
/*     */   {
/* 583 */     this.x = (-this.x);
/* 584 */     this.y = (-this.y);
/* 585 */     this.z = (-this.z);
/* 586 */     this.w = (-this.w);
/* 587 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f subtract(Vector4f vec)
/*     */   {
/* 601 */     return new Vector4f(this.x - vec.x, this.y - vec.y, this.z - vec.z, this.w - vec.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f subtractLocal(Vector4f vec)
/*     */   {
/* 614 */     if (vec == null) {
/* 615 */       logger.warning("Provided vector is null, null returned.");
/* 616 */       return null;
/*     */     }
/* 618 */     this.x -= vec.x;
/* 619 */     this.y -= vec.y;
/* 620 */     this.z -= vec.z;
/* 621 */     this.w -= vec.w;
/* 622 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f subtract(Vector4f vec, Vector4f result)
/*     */   {
/* 636 */     if (result == null) {
/* 637 */       result = new Vector4f();
/*     */     }
/* 639 */     this.x -= vec.x;
/* 640 */     this.y -= vec.y;
/* 641 */     this.z -= vec.z;
/* 642 */     this.w -= vec.w;
/* 643 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f subtract(float subtractX, float subtractY, float subtractZ, float subtractW)
/*     */   {
/* 662 */     return new Vector4f(this.x - subtractX, this.y - subtractY, this.z - subtractZ, this.w - subtractW);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f subtractLocal(float subtractX, float subtractY, float subtractZ, float subtractW)
/*     */   {
/* 681 */     this.x -= subtractX;
/* 682 */     this.y -= subtractY;
/* 683 */     this.z -= subtractZ;
/* 684 */     this.w -= subtractW;
/* 685 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f normalize()
/*     */   {
/* 700 */     float length = this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/* 701 */     if ((length != 1.0F) && (length != 0.0F)) {
/* 702 */       length = 1.0F / FastMath.sqrt(length);
/* 703 */       return new Vector4f(this.x * length, this.y * length, this.z * length, this.w * length);
/*     */     }
/* 705 */     return clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f normalizeLocal()
/*     */   {
/* 718 */     float length = this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/* 719 */     if ((length != 1.0F) && (length != 0.0F)) {
/* 720 */       length = 1.0F / FastMath.sqrt(length);
/* 721 */       this.x *= length;
/* 722 */       this.y *= length;
/* 723 */       this.z *= length;
/* 724 */       this.w *= length;
/*     */     }
/* 726 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void maxLocal(Vector4f other)
/*     */   {
/* 736 */     this.x = (other.x > this.x ? other.x : this.x);
/* 737 */     this.y = (other.y > this.y ? other.y : this.y);
/* 738 */     this.z = (other.z > this.z ? other.z : this.z);
/* 739 */     this.w = (other.w > this.w ? other.w : this.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void minLocal(Vector4f other)
/*     */   {
/* 749 */     this.x = (other.x < this.x ? other.x : this.x);
/* 750 */     this.y = (other.y < this.y ? other.y : this.y);
/* 751 */     this.z = (other.z < this.z ? other.z : this.z);
/* 752 */     this.w = (other.w < this.w ? other.w : this.w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector4f zero()
/*     */   {
/* 759 */     this.x = (this.y = this.z = this.w = 0.0F);
/* 760 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float angleBetween(Vector4f otherVector)
/*     */   {
/* 771 */     float dotProduct = dot(otherVector);
/* 772 */     float angle = FastMath.acos(dotProduct);
/* 773 */     return angle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f interpolate(Vector4f finalVec, float changeAmnt)
/*     */   {
/* 784 */     this.x = ((1.0F - changeAmnt) * this.x + changeAmnt * finalVec.x);
/* 785 */     this.y = ((1.0F - changeAmnt) * this.y + changeAmnt * finalVec.y);
/* 786 */     this.z = ((1.0F - changeAmnt) * this.z + changeAmnt * finalVec.z);
/* 787 */     this.w = ((1.0F - changeAmnt) * this.w + changeAmnt * finalVec.w);
/* 788 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector4f interpolate(Vector4f beginVec, Vector4f finalVec, float changeAmnt)
/*     */   {
/* 800 */     this.x = ((1.0F - changeAmnt) * beginVec.x + changeAmnt * finalVec.x);
/* 801 */     this.y = ((1.0F - changeAmnt) * beginVec.y + changeAmnt * finalVec.y);
/* 802 */     this.z = ((1.0F - changeAmnt) * beginVec.z + changeAmnt * finalVec.z);
/* 803 */     this.w = ((1.0F - changeAmnt) * beginVec.w + changeAmnt * finalVec.w);
/* 804 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isValidVector(Vector4f vector)
/*     */   {
/* 814 */     if (vector == null) return false;
/* 815 */     if ((Float.isNaN(vector.x)) || 
/* 816 */       (Float.isNaN(vector.y)) || 
/* 817 */       (Float.isNaN(vector.z)) || 
/* 818 */       (Float.isNaN(vector.w))) return false;
/* 819 */     if ((Float.isInfinite(vector.x)) || 
/* 820 */       (Float.isInfinite(vector.y)) || 
/* 821 */       (Float.isInfinite(vector.z)) || 
/* 822 */       (Float.isInfinite(vector.w))) return false;
/* 823 */     return true;
/*     */   }
/*     */   
/*     */   public Vector4f clone()
/*     */   {
/*     */     try {
/* 829 */       return (Vector4f)super.clone();
/*     */     } catch (CloneNotSupportedException e) {
/* 831 */       throw new AssertionError();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] toArray(float[] floats)
/*     */   {
/* 844 */     if (floats == null) {
/* 845 */       floats = new float[4];
/*     */     }
/* 847 */     floats[0] = this.x;
/* 848 */     floats[1] = this.y;
/* 849 */     floats[2] = this.z;
/* 850 */     floats[3] = this.w;
/* 851 */     return floats;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 863 */     if (!(o instanceof Vector4f)) { return false;
/*     */     }
/* 865 */     if (this == o) { return true;
/*     */     }
/* 867 */     Vector4f comp = (Vector4f)o;
/* 868 */     if (Float.compare(this.x, comp.x) != 0) return false;
/* 869 */     if (Float.compare(this.y, comp.y) != 0) return false;
/* 870 */     if (Float.compare(this.z, comp.z) != 0) return false;
/* 871 */     if (Float.compare(this.w, comp.w) != 0) return false;
/* 872 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 882 */     int hash = 37;
/* 883 */     hash += 37 * hash + Float.floatToIntBits(this.x);
/* 884 */     hash += 37 * hash + Float.floatToIntBits(this.y);
/* 885 */     hash += 37 * hash + Float.floatToIntBits(this.z);
/* 886 */     hash += 37 * hash + Float.floatToIntBits(this.w);
/* 887 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 899 */     return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
/*     */   }
/*     */   
/*     */   public float getX()
/*     */   {
/* 904 */     return this.x;
/*     */   }
/*     */   
/*     */   public Vector4f setX(float x) {
/* 908 */     this.x = x;
/* 909 */     return this;
/*     */   }
/*     */   
/*     */   public float getY() {
/* 913 */     return this.y;
/*     */   }
/*     */   
/*     */   public Vector4f setY(float y) {
/* 917 */     this.y = y;
/* 918 */     return this;
/*     */   }
/*     */   
/*     */   public float getZ() {
/* 922 */     return this.z;
/*     */   }
/*     */   
/*     */   public Vector4f setZ(float z) {
/* 926 */     this.z = z;
/* 927 */     return this;
/*     */   }
/*     */   
/*     */   public float getW() {
/* 931 */     return this.w;
/*     */   }
/*     */   
/*     */   public Vector4f setW(float w) {
/* 935 */     this.w = w;
/* 936 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float get(int index)
/*     */   {
/* 947 */     switch (index) {
/*     */     case 0: 
/* 949 */       return this.x;
/*     */     case 1: 
/* 951 */       return this.y;
/*     */     case 2: 
/* 953 */       return this.z;
/*     */     case 3: 
/* 955 */       return this.w;
/*     */     }
/* 957 */     throw new IllegalArgumentException("index must be either 0, 1, 2 or 3");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void set(int index, float value)
/*     */   {
/* 969 */     switch (index) {
/*     */     case 0: 
/* 971 */       this.x = value;
/* 972 */       return;
/*     */     case 1: 
/* 974 */       this.y = value;
/* 975 */       return;
/*     */     case 2: 
/* 977 */       this.z = value;
/* 978 */       return;
/*     */     case 3: 
/* 980 */       this.w = value;
/* 981 */       return;
/*     */     }
/* 983 */     throw new IllegalArgumentException("index must be either 0, 1, 2 or 3");
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Vector4f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */