/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.app.Fragment;
/*     */ import android.content.Context;
/*     */ import android.content.pm.ApplicationInfo;
/*     */ import android.os.Bundle;
/*     */ import android.os.Handler;
/*     */ import android.util.Log;
/*     */ import android.view.ViewGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARFragment
/*     */   extends Fragment
/*     */ {
/*     */   private static final String LOGTAG = "ARFragment";
/*     */   private ARActivity mARActivity;
/*     */   private ARView mGlView;
/*     */   private ARSurfaceRenderer mRenderer;
/*     */   
/*     */   static
/*     */   {
/*  27 */     System.loadLibrary("Kudan");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   private Handler handler = null;
/*  43 */   private Runnable runnable = null;
/*     */   
/*     */   public void onCreate(Bundle savedInstanceState) {
/*  46 */     Log.d("ARFragment", "onCreate");
/*     */     
/*  48 */     super.onCreate(savedInstanceState);
/*  49 */     setRetainInstance(true);
/*     */   }
/*     */   
/*     */   public void onAttach(Activity activity) {
/*  53 */     Log.d("ARFragment", "onAttach");
/*     */     
/*  55 */     super.onAttach(activity);
/*     */     
/*  57 */     this.mARActivity = ((ARActivity)activity);
/*     */     
/*  59 */     ARRenderer renderer = ARRenderer.getInstance();
/*  60 */     renderer.reset();
/*  61 */     renderer.setAssetManager(this.mARActivity.getAssets());
/*  62 */     renderer.setActivity(this.mARActivity);
/*  63 */     renderer.setDataDir(this.mARActivity.getApplicationContext().getApplicationInfo().dataDir);
/*     */     
/*  65 */     initApplicationAR(this.mARActivity);
/*     */   }
/*     */   
/*  68 */   final int focusDelay = 3000;
/*     */   
/*     */ 
/*     */   public void onResume()
/*     */   {
/*  73 */     Log.i("ARFragment", "onResume");
/*  74 */     super.onResume();
/*     */     
/*  76 */     ARGyroManager.getInstance().start();
/*     */     
/*     */ 
/*  79 */     if (this.mGlView != null) {
/*  80 */       this.mGlView.setVisibility(0);
/*  81 */       this.mGlView.onResume();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void onPause()
/*     */   {
/*  88 */     Log.d("ARFragment", "onPause");
/*  89 */     super.onPause();
/*     */     
/*  91 */     ARGyroManager.getInstance().stop();
/*     */     
/*  93 */     if (this.handler != null) {
/*  94 */       this.handler.removeCallbacks(this.runnable);
/*  95 */       this.handler = null;
/*  96 */       this.runnable = null;
/*     */     }
/*     */     
/*  99 */     if (this.mGlView != null) {
/* 100 */       this.mGlView.setVisibility(4);
/* 101 */       this.mGlView.onPause();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void onDestroy()
/*     */   {
/* 108 */     Log.d("ARFragment", "onDestroy");
/* 109 */     super.onDestroy();
/*     */     
/* 111 */     ARAPIKey.getInstance().deinitialise();
/* 112 */     ARArbiTrack.getInstance().deinitialise();
/* 113 */     ARGyroPlaceManager.getInstance().deinitialise();
/* 114 */     ARGyroManager.getInstance().deinitialise();
/* 115 */     ARImageTracker.getInstance().deinitialise();
/*     */     
/* 117 */     ARRenderer renderer = ARRenderer.getInstance();
/* 118 */     renderer.reset();
/*     */     
/* 120 */     System.gc();
/*     */   }
/*     */   
/*     */   private void initApplicationAR(ARActivity activity)
/*     */   {
/* 125 */     this.mGlView = new ARView(activity);
/* 126 */     this.mGlView.setPreserveEGLContextOnPause(true);
/*     */     
/*     */ 
/*     */ 
/* 130 */     ViewGroup rootLayout = (ViewGroup)activity.findViewById(16908290);
/* 131 */     rootLayout.addView(this.mGlView, 0);
/*     */   }
/*     */   
/*     */   public ARView getARView()
/*     */   {
/* 136 */     return this.mGlView;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */