/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARAlphaVideoTextureShader
/*    */   extends ARShaderProgram
/*    */ {
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nuniform mat4 uvTransform;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nvoid main()\n{\n    vec4 uv = vec4(vertexUV.x, vertexUV.y, 0, 1.0);\n    uv = uvTransform * uv;\n    uvCoord = vec2(uv.x, uv.y);\n    uvCoordMask.x = uvCoord.x + 0.5;\n    uvCoordMask.y = uvCoord.y;\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}";
/*    */   static final String fragmentString = "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nuniform samplerExternalOES uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    float alpha = texture2D(uvSampler, uvCoordMask).x;\n    col *= alpha;\n    gl_FragColor = col;\n}";
/*    */   
/*    */   public ARAlphaVideoTextureShader()
/*    */   {
/* 40 */     setShaderStrings("attribute vec4 vertexPosition;\nattribute vec2 vertexUV;\nuniform mat4 modelViewProjectionMatrix;\nuniform mat4 uvTransform;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nvoid main()\n{\n    vec4 uv = vec4(vertexUV.x, vertexUV.y, 0, 1.0);\n    uv = uvTransform * uv;\n    uvCoord = vec2(uv.x, uv.y);\n    uvCoordMask.x = uvCoord.x + 0.5;\n    uvCoordMask.y = uvCoord.y;\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}", "#extension GL_OES_EGL_image_external :require\nprecision mediump float;\nvarying vec2 uvCoord;\nvarying vec2 uvCoordMask;\nuniform samplerExternalOES uvSampler;\nvoid main()\n{\n    vec4 col = texture2D(uvSampler, uvCoord);\n    float alpha = texture2D(uvSampler, uvCoordMask).x;\n    col *= alpha;\n    gl_FragColor = col;\n}");
/*    */   }
/*    */   
/*    */   public static ARAlphaVideoTextureShader getShader() {
/* 44 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 46 */     boolean[] properties = { true };
/*    */     
/* 48 */     ARAlphaVideoTextureShader shader = (ARAlphaVideoTextureShader)shaderManager.findShader(ARAlphaVideoTextureShader.class, properties);
/* 49 */     if (shader != null)
/*    */     {
/* 51 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 55 */     shader = new ARAlphaVideoTextureShader();
/*    */     
/* 57 */     shaderManager.addShader(shader, properties);
/*    */     
/* 59 */     ARRenderer renderer = ARRenderer.getInstance();
/* 60 */     renderer.addShader(shader);
/*    */     
/* 62 */     return shader;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 67 */     int uvTransformHandle = GLES20.glGetUniformLocation(this.mShaderID, "uvTransform");
/* 68 */     if (uvTransformHandle >= 0) {
/* 69 */       GLES20.glUniformMatrix4fv(uvTransformHandle, 1, false, uvTransform, 0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARAlphaVideoTextureShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */