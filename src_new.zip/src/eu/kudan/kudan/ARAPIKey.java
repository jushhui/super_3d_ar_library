/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.os.AsyncTask;
/*     */ import android.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ 
/*     */ public class ARAPIKey
/*     */ {
/*     */   private static ARAPIKey singletonInstance;
/*     */   private String apiKey;
/*     */   private Context appContext;
/*     */   private static final String SWITCH_BASE_URL = "https://api.kudan.eu/licensing/check";
/*     */   private static final String SWITCH_FILE_NAME = "status.txt";
/*     */   private static final String SWITCH_FILE_DEMO_STRING = "DEMO_MODE";
/*     */   private static final String SWITCH_FILE_DEPART_STRING = "ASTA_LAVISTA";
/*     */   private static final String SWITCH_FILE_NOT_PRESENT = "File_Not_Found";
/*     */   
/*     */   private native void verifyAPILicenseKeyN(String paramString1, String paramString2);
/*     */   
/*     */   public static ARAPIKey getInstance()
/*     */   {
/*  29 */     if (singletonInstance == null) {
/*  30 */       singletonInstance = new ARAPIKey();
/*     */     }
/*  32 */     return singletonInstance;
/*     */   }
/*     */   
/*     */   public ARAPIKey() {
/*  36 */     this.apiKey = "GAWAE-FBVCC-XA8ST-GQVZV-93PQB-X7SBD-P6V4W-6RS9C-CQRLH-78YEU-385XP-T6MCG-2CNWB-YK8SR-8UUQ";
/*     */   }
/*     */   
/*     */
/*     */   
/*     */ 
/*     */   private String bundleID()
/*     */   {
/*  51 */     if (this.appContext != null)
/*     */     {
/*  53 */       return this.appContext.getPackageName();
/*     */     }
/*     */     
/*     */ 
/*  57 */     return "";
/*     */   }
/*     */   
/*     */   public final void checkKey(Context cont)
/*     */   {
/*  62 */     if ((cont != null) && (this.appContext == null)) {
/*  63 */       this.appContext = cont;
/*     */     }
/*     */     else {
/*  66 */       Log.e("", "Couldn't set context");
/*     */     }
/*     */     
/*  69 */     verifyAPILicenseKeyN("GAWAE-FBVCC-XA8ST-GQVZV-93PQB-X7SBD-P6V4W-6RS9C-CQRLH-78YEU-385XP-T6MCG-2CNWB-YK8SR-8UUQ", "eu.kudan.kudansamples");
/*  70 */     ////String combined = "https://api.kudan.eu/licensing/check/" + bundleID() + "/" + "status.txt";
/*  71 */     //new CheckRemoteLicensing(null).execute(new String[] { combined });
/*     */   }
/*     */   
/*     */   private void remoteServerIsHappy(String remoteString)
/*     */   {
/*  76 */     if (remoteString.equals("ASTA_LAVISTA")) {
/*  77 */       Log.e("", "The API key: " + this.apiKey + " is no longer valid.");
/*  78 */       System.exit(0);
/*     */     }
/*  80 */     else if (remoteString.equals("DEMO_MODE")) {
/*  81 */       Log.i("", "KudanAR Demo Mode.");
/*     */     } else {
/*  83 */       remoteString.equals("File_Not_Found");
/*     */     }
/*     */   }
/*     */   
/*     */   private class CheckRemoteLicensing extends AsyncTask<String, Void, String>
/*     */   {
/*     */     private CheckRemoteLicensing() {}
/*     */     
/*     */     protected String doInBackground(String... urls)
/*     */     {
/*     */       try {
/*  94 */         return ARAPIKey.this.getDataFromURL(urls[0]);
/*     */       } catch (IOException e) {}
/*  96 */       return "File_Not_Found";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void onPostExecute(String result)
/*     */     {
/* 103 */       ARAPIKey.this.remoteServerIsHappy(result);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String getDataFromURL(String myurl)
/*     */     throws IOException
/*     */   {
/* 111 */     InputStream inputStream = null;
/* 112 */     int len = 12;
/*     */     try
/*     */     {
/* 115 */       URL url = new URL(myurl);
/* 116 */       HttpsURLConnection conn = (HttpsURLConnection)url.openConnection();
/* 117 */       conn.setReadTimeout(10000);
/* 118 */       conn.setConnectTimeout(15000);
/* 119 */       conn.setRequestMethod("GET");
/* 120 */       conn.setDoInput(true);
/*     */       
/* 122 */       conn.connect();
/* 123 */       int response = conn.getResponseCode();
/* 124 */       if (response == 200)
/*     */       {
/* 126 */         inputStream = conn.getInputStream();
/*     */         
/*     */ 
/* 129 */         String contentAsString = readIt(inputStream, len);
/* 130 */         return contentAsString;
/*     */       }
/*     */       
/*     */ 
/* 134 */       return "File_Not_Found";
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 140 */       if (inputStream != null) {
/* 141 */         inputStream.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException
/*     */   {
/* 148 */     Reader reader = null;
/* 149 */     reader = new InputStreamReader(stream, "UTF-8");
/* 150 */     char[] buffer = new char[len];
/* 151 */     reader.read(buffer);
/* 152 */     return new String(buffer);
/*     */   }
/*     */   
/*     */   public void deinitialise()
/*     */   {
/* 157 */     this.appContext = null;
/*     */   }
/*     */ }


/* Location:              /Users/albert/Documents/Prog/KudanA/kudanar/kudanar.jar!/eu/kudan/kudan/ARAPIKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */