/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ import com.jme3.math.Vector3f;
/*    */ 
/*    */ public class ARColourShader extends ARShaderProgram
/*    */ {
/*  8 */   private float[] mTmpVector = new float[3];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static final String vertexString = "attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;void main()\n{\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static final String fragmentString = "precision mediump float;\nuniform vec3 colour;\nvoid main()\n{\n    gl_FragColor = vec4(colour, 1.0);\n}";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ARColourShader()
/*    */   {
/* 30 */     setShaderStrings("attribute vec4 vertexPosition;\nuniform mat4 modelViewProjectionMatrix;void main()\n{\n    gl_Position = modelViewProjectionMatrix * vertexPosition;\n}", "precision mediump float;\nuniform vec3 colour;\nvoid main()\n{\n    gl_FragColor = vec4(colour, 1.0);\n}");
/*    */   }
/*    */   
/*    */   public static ARColourShader getShader() {
/* 34 */     ARShaderManager shaderManager = ARShaderManager.getInstance();
/*    */     
/* 36 */     boolean[] properties = { true };
/*    */     
/* 38 */     ARColourShader shader = (ARColourShader)shaderManager.findShader(ARColourShader.class, properties);
/* 39 */     if (shader != null)
/*    */     {
/* 41 */       return shader;
/*    */     }
/*    */     
/*    */ 
/* 45 */     shader = new ARColourShader();
/*    */     
/* 47 */     shaderManager.addShader(shader, properties);
/*    */     
/* 49 */     ARRenderer renderer = ARRenderer.getInstance();
/* 50 */     renderer.addShader(shader);
/*    */     
/* 52 */     return shader;
/*    */   }
/*    */   
/*    */   public void setColour(Vector3f colour) {
/* 56 */     int colourUniformHandle = GLES20.glGetUniformLocation(this.mShaderID, "colour");
/* 57 */     if (colourUniformHandle >= 0) {
/* 58 */       this.mTmpVector[0] = colour.getX();
/* 59 */       this.mTmpVector[1] = colour.getY();
/* 60 */       this.mTmpVector[2] = colour.getZ();
/* 61 */       GLES20.glUniform3fv(colourUniformHandle, 1, this.mTmpVector, 0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARColourShader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */