/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.content.res.AssetFileDescriptor;
/*     */ import android.content.res.AssetManager;
/*     */ import java.io.FileDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class ARModelImporter
/*     */ {
/*     */   private int mNativeMem;
/*     */   private List<ARMesh> mMeshes;
/*     */   private List<ARNode> mNodes;
/*     */   private List<ARMeshNode> mMeshNodes;
/*     */   private List<ARAnimationChannel> mNodeAnimationChannels;
/*     */   private List<ARBlendAnimationChannel> mBlendAnimationChannels;
/*     */   private ARModelNode mModelNode;
/*     */   
/*     */   private native void initN();
/*     */   
/*     */   public ARModelImporter()
/*     */   {
/*  24 */     initN();
/*     */     
/*  26 */     this.mMeshes = new ArrayList();
/*  27 */     this.mNodes = new ArrayList();
/*  28 */     this.mMeshNodes = new ArrayList();
/*  29 */     this.mNodeAnimationChannels = new ArrayList();
/*  30 */     this.mBlendAnimationChannels = new ArrayList();
/*     */     
/*  32 */     this.mModelNode = new ARModelNode();
/*     */   }
/*     */   
/*     */   private native void destroyN(int paramInt);
/*     */   
/*  37 */   public void finalize() { destroyN(this.mNativeMem); }
/*     */   
/*     */   private native void loadFromPathN(String paramString);
/*     */   
/*     */   public void loadFromPath(String path) {
/*  42 */     loadFromPathN(path);
/*  43 */     process();
/*     */   }
/*     */   
/*     */   private native void loadFromAssetN(FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*     */   
/*     */   public void loadFromAsset(String asset) {
/*     */     try {
/*  50 */       ARRenderer renderer = ARRenderer.getInstance();
/*  51 */       AssetFileDescriptor fd = renderer.getAssetManager().openFd(asset);
/*  52 */       loadFromAssetN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength());
/*  53 */       fd.close();
/*  54 */       process();
/*     */     }
/*     */     catch (Exception e) {
/*  57 */       e.printStackTrace();
/*  58 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   private void process() {
/*  63 */     this.mModelNode.setMeshNodes(this.mMeshNodes);
/*  64 */     this.mModelNode.setNodeAnimationChannels(this.mNodeAnimationChannels);
/*  65 */     this.mModelNode.setBlendAnimationChannels(this.mBlendAnimationChannels);
/*     */     
/*     */ 
/*  68 */     for (ARNode node : this.mNodes)
/*     */     {
/*  70 */       if (node.getParent() == null) {
/*  71 */         this.mModelNode.addChild(node);
/*  72 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMesh(ARMesh mesh) {
/*  78 */     this.mMeshes.add(mesh);
/*     */   }
/*     */   
/*     */   private void addMeshNode(ARMeshNode meshNode) {
/*  82 */     this.mMeshNodes.add(meshNode);
/*     */   }
/*     */   
/*     */   private void addNode(ARNode node) {
/*  86 */     this.mNodes.add(node);
/*     */   }
/*     */   
/*     */   private void addAnimationChannel(ARNode node, int nativeMem) {
/*  90 */     ARAnimationChannel channel = new ARAnimationChannel(node, nativeMem);
/*  91 */     this.mNodeAnimationChannels.add(channel);
/*     */   }
/*     */   
/*     */   public ARNode getNode() {
/*  95 */     return this.mModelNode;
/*     */   }
/*     */   
/*     */   public List<ARMeshNode> getMeshNodes() {
/*  99 */     return this.mMeshNodes;
/*     */   }
/*     */   
/*     */   public void addBlendAnimationChannel(ARBlendShapeChannel channel, int nativeMem) {
/* 103 */     ARBlendAnimationChannel blendChannel = new ARBlendAnimationChannel(channel, nativeMem);
/*     */     
/* 105 */     this.mBlendAnimationChannels.add(blendChannel);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARModelImporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */