/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class ARModelNode extends ARNode
/*    */ {
/*    */   private List<ARMeshNode> mMeshNodes;
/*    */   private List<ARAnimationChannel> mNodeAnimationChannels;
/*    */   private List<ARBlendAnimationChannel> mBlendAnimationChannels;
/*    */   private int mFrame;
/*    */   private boolean isPlaying;
/*    */   
/*    */   public void setMeshNodes(List<ARMeshNode> meshNodes)
/*    */   {
/* 15 */     this.mMeshNodes = meshNodes;
/*    */   }
/*    */   
/*    */   public void setNodeAnimationChannels(List<ARAnimationChannel> animationChannels) {
/* 19 */     this.mNodeAnimationChannels = animationChannels;
/*    */   }
/*    */   
/*    */   public void setBlendAnimationChannels(List<ARBlendAnimationChannel> animationChannels) {
/* 23 */     this.mBlendAnimationChannels = animationChannels;
/*    */   }
/*    */   
/*    */   public void play()
/*    */   {
/* 28 */     this.isPlaying = true;
/*    */   }
/*    */   
/*    */   public void pause()
/*    */   {
/* 33 */     this.isPlaying = false;
/*    */   }
/*    */   
/*    */   public void reset()
/*    */   {
/* 38 */     this.mFrame = 0;
/* 39 */     this.isPlaying = true;
/*    */   }
/*    */   
/*    */   public void preRender() {
/* 43 */     super.preRender();
/*    */     
/*    */ 
/*    */ 
/* 47 */     if (this.isPlaying)
/*    */     {
/* 49 */       for (ARAnimationChannel channel : this.mNodeAnimationChannels) {
/* 50 */         boolean finished = channel.updateTransform(this.mFrame);
/* 51 */         if (finished)
/*    */         {
/* 53 */           this.mFrame = 0;
/* 54 */           break;
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 59 */       for (ARBlendAnimationChannel channel : this.mBlendAnimationChannels) {
/* 60 */         channel.update(this.mFrame);
/*    */       }
/*    */       
/* 63 */       this.mFrame += 1;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARModelNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */