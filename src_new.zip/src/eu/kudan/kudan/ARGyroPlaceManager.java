/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.jme3.math.Matrix4f;
/*    */ import com.jme3.math.Quaternion;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARGyroPlaceManager
/*    */   implements ARRendererListener
/*    */ {
/*    */   private static ARGyroPlaceManager gyroPlaceManager;
/* 12 */   private ARNode mWorld = new ARNode();
/*    */   
/*    */   public static ARGyroPlaceManager getInstance()
/*    */   {
/* 16 */     if (gyroPlaceManager == null) {
/* 17 */       gyroPlaceManager = new ARGyroPlaceManager();
/*    */     }
/* 19 */     return gyroPlaceManager;
/*    */   }
/*    */   
/*    */   public void initialise()
/*    */   {
/* 24 */     ARGyroManager gyroManager = ARGyroManager.getInstance();
/* 25 */     gyroManager.initialise();
/* 26 */     gyroManager.start();
/*    */     
/* 28 */     ARRenderer.getInstance().getActivity().getARView().getContentViewPort().getCamera().addChild(this.mWorld);
/* 29 */     ARRenderer.getInstance().addListener(this);
/*    */   }
/*    */   
/*    */   public void deinitialise()
/*    */   {
/* 34 */     this.mWorld = new ARNode();
/* 35 */     ARRenderer.getInstance().removeListener(this);
/*    */   }
/*    */   
/*    */   private native void getFloorPositionN(float[] paramArrayOfFloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*    */   
/*    */   public void preRender()
/*    */   {
/* 42 */     ARGyroManager gyroManager = ARGyroManager.getInstance();
/* 43 */     gyroManager.updateGyro();
/*    */     
/* 45 */     Quaternion gyroRot = gyroManager.getWorld().getOrientation();
/* 46 */     Matrix4f projMatrix = ARRenderer.getInstance().getActivity().getARView().getContentViewPort().getCamera().getProjectionMatrix();
/* 47 */     float[] gLProjMatrix = new float[16];
/* 48 */     projMatrix.get(gLProjMatrix, false);
/*    */     
/* 50 */     getFloorPositionN(gLProjMatrix, gyroRot.getX(), gyroRot.getY(), gyroRot.getZ(), gyroRot.getW(), -150.0F);
/*    */   }
/*    */   
/*    */   private void setWorldPosition(float x, float y, float z)
/*    */   {
/* 55 */     this.mWorld.setPosition(x, y, z);
/*    */   }
/*    */   
/*    */   private void setWorldOrientation(float x, float y, float z, float w)
/*    */   {
/* 60 */     this.mWorld.setOrientation(x, y, z, w);
/*    */   }
/*    */   
/*    */   public ARNode getWorld()
/*    */   {
/* 65 */     return this.mWorld;
/*    */   }
/*    */   
/*    */   public void postRender() {}
/*    */   
/*    */   public void rendererDidPause() {}
/*    */   
/*    */   public void rendererDidResume() {}
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARGyroPlaceManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */