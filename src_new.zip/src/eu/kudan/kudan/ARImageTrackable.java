/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.content.res.AssetFileDescriptor;
/*     */ import android.content.res.AssetManager;
/*     */ import java.io.FileDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class ARImageTrackable
/*     */ {
/*     */   private ARWorld mWorld;
/*     */   private String mName;
/*     */   private float mWidth;
/*     */   private float mHeight;
/*     */   private boolean mDetected;
/*     */   private List<ARImageTrackableListener> mListeners;
/*     */   private int mNativeMem;
/*     */   private boolean mLastDetectionState;
/*     */   
/*     */   private native void initN();
/*     */   
/*     */   private native void destroyN(int paramInt);
/*     */   
/*     */   public ARImageTrackable()
/*     */   {
/*  27 */     this.mWorld = new ARWorld();
/*  28 */     this.mListeners = new ArrayList();
/*  29 */     initN();
/*     */   }
/*     */   
/*     */   public ARImageTrackable(int nativeMem)
/*     */   {
/*  34 */     this.mListeners = new ArrayList();
/*  35 */     this.mWorld = new ARWorld();
/*  36 */     this.mNativeMem = nativeMem;
/*     */   }
/*     */   
/*     */   public ARImageTrackable(String name)
/*     */   {
/*  41 */     this();
/*     */   }
/*     */   
/*     */   private native void loadFromPathN(String paramString);
/*     */   
/*  46 */   public void loadFromPath(String path) { loadFromPathN(path); }
/*     */   
/*     */   private native void loadFromAssetN(FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*     */   
/*     */   public void loadFromAsset(String asset)
/*     */   {
/*     */     try {
/*  53 */       ARRenderer renderer = ARRenderer.getInstance();
/*  54 */       AssetFileDescriptor fd = renderer.getAssetManager().openFd(asset);
/*  55 */       loadFromAssetN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength());
/*  56 */       fd.close();
/*     */     }
/*     */     catch (Exception e) {
/*  59 */       e.printStackTrace();
/*  60 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   public void finalize() {
/*  65 */     destroyN(this.mNativeMem);
/*  66 */     this.mNativeMem = 0;
/*     */   }
/*     */   
/*     */   public ARWorld getWorld() {
/*  70 */     return this.mWorld;
/*     */   }
/*     */   
/*     */   private native void setNameN(String paramString);
/*     */   
/*  75 */   public void setName(String name) { setNameN(name); }
/*     */   
/*     */   private native String getNameN();
/*     */   
/*     */   public String getName() {
/*  80 */     return getNameN();
/*     */   }
/*     */   
/*     */   public boolean getDetected() {
/*  84 */     return this.mDetected;
/*     */   }
/*     */   
/*     */   public void trackerStartFrame() {
/*  88 */     this.mLastDetectionState = this.mDetected;
/*     */   }
/*     */   
/*     */   private native float getWidthN();
/*     */   
/*  93 */   public float getWidth() { return getWidthN(); }
/*     */   
/*     */   private native float getHeightN();
/*     */   
/*     */   public float getHeight() {
/*  98 */     return getHeightN();
/*     */   }
/*     */   
/*     */   public void trackerEndFrame() {
/* 102 */     if (this.mDetected)
/*     */     {
/*     */ 
/* 105 */       if (!this.mLastDetectionState)
/*     */       {
/* 107 */         for (ARImageTrackableListener listener : this.mListeners) {
/* 108 */           listener.didDetect(this);
/*     */         }
/*     */       }
/*     */       
/* 112 */       for (ARImageTrackableListener listener : this.mListeners) {
/* 113 */         listener.didTrack(this);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 118 */     else if (this.mLastDetectionState)
/*     */     {
/* 120 */       for (ARImageTrackableListener listener : this.mListeners) {
/* 121 */         listener.didLose(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void trackerSetDetected(boolean detected)
/*     */   {
/* 128 */     this.mDetected = detected;
/*     */   }
/*     */   
/*     */   public List<ARImageTrackableListener> getListeners() {
/* 132 */     return this.mListeners;
/*     */   }
/*     */   
/*     */   public void addListener(ARImageTrackableListener listener) {
/* 136 */     this.mListeners.add(listener);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARImageTrackable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */