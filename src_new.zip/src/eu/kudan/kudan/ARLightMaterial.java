/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import com.jme3.math.Matrix3f;
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Vector3f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARLightMaterial
/*     */   extends ARMaterial
/*     */ {
/*     */   private ARLightShader mShader;
/*  16 */   private Vector3f mColour = new Vector3f();
/*  17 */   private Vector3f mDiffuse = new Vector3f();
/*  18 */   private Vector3f mAmbient = new Vector3f();
/*  19 */   private Vector3f mSpecular = new Vector3f();
/*  20 */   private float mShininess = 1.0F;
/*  21 */   private float mAlpha = 1.0F;
/*     */   
/*     */   private ARTexture2D mTexture;
/*     */   
/*     */   private ARTexture2D mOcclusionTexture;
/*     */   
/*     */   private ARTexture3D mCubeTexture;
/*     */   
/*     */   private float mReflectivity;
/*     */   
/*     */   private boolean mHasReflection;
/*     */   private boolean mHasTexture;
/*     */   private boolean mHasAlpha;
/*     */   private boolean mHasBones;
/*  35 */   private Matrix4f mCachedBoneFullTransform = new Matrix4f();
/*  36 */   private Matrix4f mCachedNodeFullTransform = new Matrix4f();
/*     */   
/*  38 */   private List<Matrix4f> mCachedBones = new ArrayList(20);
/*  39 */   private List<Matrix3f> mCachedBonesRotation = new ArrayList(20);
/*     */   
/*     */   private void chooseShader(ARMeshNode meshNode) {
/*  42 */     ARMesh mesh = meshNode.getMesh();
/*     */     
/*  44 */     boolean hasBones = false;
/*  45 */     boolean hasMorph = false;
/*  46 */     boolean hasReflection = false;
/*  47 */     boolean hasTexture = false;
/*  48 */     boolean hasAlpha = false;
/*     */     
/*  50 */     hasBones = mesh.getBones().size() > 0;
/*     */     
/*  52 */     if (this.mCubeTexture != null) {
/*  53 */       hasReflection = true;
/*     */     }
/*     */     
/*  56 */     if (this.mTexture != null) {
/*  57 */       hasTexture = true;
/*     */     }
/*     */     
/*  60 */     if (this.mAlpha < 1.0F) {
/*  61 */       hasAlpha = true;
/*     */     }
/*     */     
/*  64 */     this.mShader = ARLightShader.getShader(hasReflection, hasTexture, hasAlpha, hasBones, hasMorph);
/*  65 */     this.mShader.compileShaders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColour(float r, float g, float b)
/*     */   {
/*  74 */     this.mColour.set(r, g, b);
/*     */   }
/*     */   
/*     */   public Vector3f getColour() {
/*  78 */     return this.mColour;
/*     */   }
/*     */   
/*     */   public void setDiffuse(float r, float g, float b)
/*     */   {
/*  83 */     this.mDiffuse.set(r, g, b);
/*     */   }
/*     */   
/*     */   public Vector3f getDiffuse() {
/*  87 */     return this.mDiffuse;
/*     */   }
/*     */   
/*     */   public void setAmbient(float r, float g, float b)
/*     */   {
/*  92 */     this.mAmbient.set(r, g, b);
/*     */   }
/*     */   
/*     */   public Vector3f getAmbient() {
/*  96 */     return this.mAmbient;
/*     */   }
/*     */   
/*     */   public void setSpecular(float r, float g, float b)
/*     */   {
/* 101 */     this.mSpecular.set(r, g, b);
/*     */   }
/*     */   
/*     */   public Vector3f getSpecular() {
/* 105 */     return this.mSpecular;
/*     */   }
/*     */   
/*     */   public void setShininess(float shininess) {
/* 109 */     if (shininess > 0.0F) {
/* 110 */       this.mShininess = shininess;
/*     */     }
/*     */   }
/*     */   
/*     */   public float getShininess() {
/* 115 */     return this.mShininess;
/*     */   }
/*     */   
/*     */   public float getAlpha() {
/* 119 */     return this.mAlpha;
/*     */   }
/*     */   
/*     */   public void setAlpha(float alpha) {
/* 123 */     this.mAlpha = alpha;
/*     */   }
/*     */   
/*     */   public void setReflectivity(float reflectivity)
/*     */   {
/* 128 */     this.mReflectivity = reflectivity;
/*     */   }
/*     */   
/*     */   public float getReflectivity() {
/* 132 */     return this.mReflectivity;
/*     */   }
/*     */   
/*     */   public void setTexture(ARTexture2D texture) {
/* 136 */     this.mTexture = texture;
/*     */   }
/*     */   
/*     */   public void setCubeTexture(ARTexture3D cubeTexture) {
/* 140 */     this.mCubeTexture = cubeTexture;
/*     */   }
/*     */   
/*     */   public boolean prepareRendererWithNode(ARNode node) {
/* 144 */     if (!super.prepareRendererWithNode(node)) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     chooseShader((ARMeshNode)node);
/*     */     
/* 150 */     this.mShader.prepareRenderer();
/*     */     
/* 152 */     this.mShader.setDiffuse(this.mDiffuse);
/* 153 */     this.mShader.setAmbient(this.mAmbient);
/* 154 */     this.mShader.setSpecular(this.mSpecular);
/* 155 */     this.mShader.setShininess(this.mShininess);
/* 156 */     if (this.mHasAlpha) {
/* 157 */       this.mShader.setAlpha(this.mAlpha);
/*     */     }
/* 159 */     this.mShader.setReflectivity(this.mReflectivity);
/* 160 */     this.mShader.setColour(this.mColour);
/* 161 */     this.mShader.setUniforms();
/*     */     
/*     */ 
/* 164 */     if (this.mTexture != null) {
/* 165 */       this.mTexture.prepareRenderer(1);
/*     */     }
/* 167 */     if (this.mCubeTexture != null) {
/* 168 */       this.mCubeTexture.prepareRenderer(0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 173 */     ARMeshNode meshNode = (ARMeshNode)node;
/* 174 */     ARMesh mesh = meshNode.getMesh();
/*     */     
/* 176 */     if (mesh.getBones().size() > 0)
/*     */     {
/*     */ 
/* 179 */       int i = 0;
/* 180 */       for (ARBoneNode bone : mesh.getBones())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 199 */         i++;
/*     */       }
/* 201 */       this.mShader.setBones(ARRenderer.getInstance().getBones(), mesh.getBones().size());
/*     */     }
/*     */     
/* 204 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARLightMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */