/*   */ package eu.kudan.kudan;
/*   */ 
/*   */ public class NativeBuffer {
/*   */   private int mNativeMem;
/*   */   
/*   */   private native void initN();
/*   */   
/* 8 */   public NativeBuffer() { initN(); }
/*   */   
/*   */   public void finalize() {}
/*   */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\NativeBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */