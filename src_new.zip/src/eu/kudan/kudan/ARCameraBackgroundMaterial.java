/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import com.jme3.math.Matrix4f;
/*    */ 
/*    */ public class ARCameraBackgroundMaterial
/*    */   extends ARMaterial
/*    */ {
/*    */   private ARTexture mTexture;
/*    */   private ARCameraBackgroundShader mShader;
/*    */   private float[] mUVTransform;
/*    */   private Matrix4f mMarkerModelViewProjection;
/*    */   
/*    */   public void setMarkerModelViewProjection(Matrix4f matrix)
/*    */   {
/* 15 */     this.mMarkerModelViewProjection = matrix;
/*    */   }
/*    */   
/*    */   public Matrix4f getMarkerModelViewProjection() {
/* 19 */     return this.mMarkerModelViewProjection;
/*    */   }
/*    */   
/*    */   public void setTexture(ARTexture texture)
/*    */   {
/* 24 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public ARTexture getTexture() {
/* 28 */     return this.mTexture;
/*    */   }
/*    */   
/*    */ 
/*    */   public ARCameraBackgroundMaterial()
/*    */   {
/* 34 */     this.mShader = ARCameraBackgroundShader.getShader();
/*    */   }
/*    */   
/*    */   public ARCameraBackgroundMaterial(ARTexture texture) {
/* 38 */     this();
/* 39 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node)
/*    */   {
/* 44 */     boolean b = super.prepareRendererWithNode(node);
/* 45 */     if (!b) {
/* 46 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 50 */     this.mShader.prepareRenderer();
/*    */     
/* 52 */     this.mUVTransform = ARCameraStream.getInstance().getCameraTransform();
/* 53 */     this.mShader.setUVTransform(this.mUVTransform);
/*    */     
/*    */ 
/* 56 */     float[] f = new float[16];
/* 57 */     this.mMarkerModelViewProjection.get(f, false);
/*    */     
/*    */ 
/* 60 */     this.mShader.setMarkerModelViewProjection(f);
/* 61 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 69 */     this.mUVTransform = uvTransform;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARCameraBackgroundMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */