/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ 
/*    */ public class ARTextureMaterial
/*    */   extends ARMaterial
/*    */ {
/*    */   private ARTexture mTexture;
/*    */   private ARTextureShader mShader;
/*    */   
/*    */   public ARTextureMaterial()
/*    */   {
/* 12 */     this.mShader = ARTextureShader.getShader();
/*    */   }
/*    */   
/*    */   public ARTextureMaterial(ARTexture texture) {
/* 16 */     this();
/* 17 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public void setTexture(ARTexture newTexture)
/*    */   {
/* 22 */     this.mTexture = newTexture;
/*    */   }
/*    */   
/*    */   public ARTexture getTexture()
/*    */   {
/* 27 */     return this.mTexture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node) {
/* 31 */     boolean b = super.prepareRendererWithNode(node);
/* 32 */     if (!b) {
/* 33 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 37 */     this.mShader.prepareRenderer();
/* 38 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTextureMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */