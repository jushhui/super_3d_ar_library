﻿

package eu.kudan.kudan;

import android.content.res.AssetManager;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.opengl.GLES20;
import android.util.Log;
import com.jme3.math.Matrix3f;
import com.jme3.math.Matrix4f;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import eu.kudan.kudan.ARActivity;
import eu.kudan.kudan.ARCamera;
import eu.kudan.kudan.ARIndexBuffer;
import eu.kudan.kudan.ARMeshNode;
import eu.kudan.kudan.ARNode;
import eu.kudan.kudan.ARRenderTarget;
import eu.kudan.kudan.ARRendererListener;
import eu.kudan.kudan.ARShaderManager;
import eu.kudan.kudan.ARShaderProgram;
import eu.kudan.kudan.ARTexture;
import eu.kudan.kudan.ARVertexBuffer;
import eu.kudan.kudan.ARVideoTexture;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ARRenderer {
    private static ARRenderer renderer;
    public List<ARRendererListener> mListeners;
    private long renderTime;
    private Matrix4f mProjectionMatrix;
    private Matrix4f mModelViewMatrix;
    private Matrix4f mModelMatrix;
    private Matrix4f mModelViewProjectionMatrix = new Matrix4f();
    private Matrix3f mNormalMatrix;
    private Vector3f mWorldCameraPosition;
    private Vector3f mLightPosition = new Vector3f();
    private float mBlendInfluence;
    private List<Matrix4f> mBones;
    private ARCamera mCamera;
    private AssetManager mAssetManager;
    private String mDataDir;
    public Vector2f cameraFBOResolution;
    private List<ARRenderTarget> mRenderTargets = new ArrayList();
    private ARRenderTarget mDefaultRenderTarget;
    private List<MediaPlayer> mMediaPlayers = new ArrayList();
    private List<ARVertexBuffer> mVertexBuffers = new ArrayList();
    private List<ARIndexBuffer> mIndexBuffers = new ArrayList();
    private List<ARTexture> mTextures = new ArrayList();
    private List<ARShaderProgram> mShaders = new ArrayList();
    public Vector2f mScreenSize;
    private Vector2f mCameraSize;
    private ARActivity mActivity;
    private Point mTouchCoords = null;
    private boolean mRenderForCapture;
    private ARVideoTexture mActiveVideoTexture = null;
    private int mCameraFBO;
    private int mCaptureFBO;
    private Vector3f mNextColour = new Vector3f(0.0F, 0.0F, 8.0F);
    private boolean[] vertexAttributes = new boolean[10];

    public ARRenderer() {
    }

    public static ARRenderer getInstance() {
        if(renderer == null) {
            renderer = new ARRenderer();
        }

        return renderer;
    }

    public long getRenderTime() {
        return this.renderTime;
    }

    public void setBlendInfluence(float influence) {
        this.mBlendInfluence = influence;
    }

    public float getBlendInfluence() {
        return this.mBlendInfluence;
    }

    public void setBones(List<Matrix4f> bones) {
        this.mBones = bones;
    }

    public List<Matrix4f> getBones() {
        return this.mBones;
    }

    public void addRenderTarget(ARRenderTarget renderTarget) {
        this.mRenderTargets.add(renderTarget);
    }

    public List<ARRenderTarget> getRenderTargets() {
        return this.mRenderTargets;
    }

    public ARRenderTarget getDefaultRenderTarget() {
        return this.mDefaultRenderTarget;
    }

    public String getDataDir() {
        return this.mDataDir;
    }

    public void setDataDir(String dataDir) {
        this.mDataDir = dataDir;
    }

    public ARActivity getActivity() {
        return this.mActivity;
    }

    public void setActivity(ARActivity mActivity) {
        this.mActivity = mActivity;
    }

    public void setScreenSize(int x, int y) {
        this.mScreenSize = new Vector2f((float)x, (float)y);
    }

    public void setCameraSize(int x, int y) {
        this.mCameraSize = new Vector2f((float)x, (float)y);
    }

    public Matrix4f getProjectionMatrix() {
        return this.mProjectionMatrix;
    }

    public void setProjectionMatrix(Matrix4f projectionMatrix) {
        this.mProjectionMatrix = projectionMatrix;
    }

    public Matrix4f getModelViewMatrix() {
        return this.mModelViewMatrix;
    }

    public void setModelViewMatrix(Matrix4f modelViewMatrix) {
        this.mModelViewMatrix = modelViewMatrix;
    }

    public Matrix4f getModelMatrix() {
        return this.mModelMatrix;
    }

    public void setModelMatrix(Matrix4f modelMatrix) {
        this.mModelMatrix = modelMatrix;
    }

    public Matrix3f getNormalMatrix() {
        return this.mNormalMatrix;
    }

    public void setNormalMatrix(Matrix3f normalMatrix) {
        this.mNormalMatrix = normalMatrix;
    }

    public Vector3f getWorldCameraPosition() {
        return this.mWorldCameraPosition;
    }

    public void setWorldCameraPosition(Vector3f worldCameraPosition) {
        this.mWorldCameraPosition = worldCameraPosition;
    }

    public Vector3f getLightPosition() {
        return this.mLightPosition;
    }

    public void setLightPosition(Vector3f lightPosition) {
        this.mLightPosition.set(lightPosition);
    }

    public Matrix4f getModelViewProjectionMatrix() {
        return this.mProjectionMatrix.mult(this.mModelViewMatrix);
    }

    public ARCamera getCamera() {
        return this.mCamera;
    }

    public void setCamera(ARCamera camera) {
        this.mCamera = camera;
    }

    private void flattenScene(ARNode node, List<ARNode> flatNodes) {
        if(node.getVisible()) {
            flatNodes.add(node);
            Iterator var4 = node.getChildren().iterator();

            while(var4.hasNext()) {
                ARNode child = (ARNode)var4.next();
                this.flattenScene(child, flatNodes);
            }

        }
    }

    private boolean nearEnough(int a, int b) {
        boolean distance = true;
        return Math.abs(a - b) > 2?false:Math.abs(b - a) <= 2;
    }

    public boolean getRenderForCapture() {
        return this.mRenderForCapture;
    }

    public void cameraDraw() {
        GLES20.glBindFramebuffer('赀', this.mCameraFBO);
    }

    public void render() {
        this.renderTime = System.currentTimeMillis();
        List renderTarget = this.mListeners;
        ARRendererListener listener;
        Iterator var3;
        synchronized(this.mListeners) {
            var3 = this.mListeners.iterator();

            while(true) {
                if(!var3.hasNext()) {
                    break;
                }

                listener = (ARRendererListener)var3.next();
                listener.preRender();
            }
        }

        Collections.sort(this.mRenderTargets, new Comparator<ARRenderTarget>() {
            public int compare(ARRenderTarget lhs, ARRenderTarget rhs) {
                int a = lhs.getPriority();
                int b = rhs.getPriority();
                return a - b;
            }
        });
        Iterator listener1 = this.mRenderTargets.iterator();

        while(listener1.hasNext()) {
            ARRenderTarget renderTarget1 = (ARRenderTarget)listener1.next();
            renderTarget1.draw();
        }

        renderTarget = this.mListeners;
        synchronized(this.mListeners) {
            var3 = this.mListeners.iterator();

            while(var3.hasNext()) {
                listener = (ARRendererListener)var3.next();
                listener.postRender();
            }

        }
    }

    public void draw() {
        ArrayList flatNodes = new ArrayList();
        ArrayList occlusionNodes = new ArrayList();
        ArrayList opaqueNodes = new ArrayList();
        ArrayList translucentNodes = new ArrayList();
        this.flattenScene(this.getCamera(), flatNodes);
        Iterator var6 = flatNodes.iterator();

        ARNode node;
        while(var6.hasNext()) {
            node = (ARNode)var6.next();
            node.preRender();
        }

        this.mRenderForCapture = false;
        var6 = flatNodes.iterator();

        while(var6.hasNext()) {
            node = (ARNode)var6.next();
            if(node instanceof ARMeshNode) {
                ARMeshNode meshNode = (ARMeshNode)node;
                if(meshNode.getMaterial() != null) {
                    if(meshNode.getMaterial().getDepthOnly()) {
                        occlusionNodes.add(meshNode);
                    } else if(!meshNode.getMaterial().getTransparent()) {
                        opaqueNodes.add(meshNode);
                    } else if(meshNode.getMaterial().getTransparent()) {
                        translucentNodes.add(meshNode);
                    }
                }
            }
        }

        var6 = occlusionNodes.iterator();

        while(var6.hasNext()) {
            node = (ARNode)var6.next();
            node.render();
        }

        var6 = opaqueNodes.iterator();

        while(var6.hasNext()) {
            node = (ARNode)var6.next();
            node.render();
        }

        Collections.sort(translucentNodes, new Comparator<ARNode>() {
            public int compare(ARNode a, ARNode b) {
                Vector3f centre = new Vector3f(0.0F, 0.0F, 0.0F);
                Vector3f centreA = a.getFullTransform().mult(centre);
                Vector3f centreB = b.getFullTransform().mult(centre);
                float distanceA = centre.distance(centreA);
                float distanceB = centre.distance(centreB);
                return distanceA > distanceB?-1:(distanceB > distanceA?1:0);
            }
        });
        GLES20.glDisable(2884);
        var6 = translucentNodes.iterator();

        while(var6.hasNext()) {
            node = (ARNode)var6.next();
            node.render();
        }

        GLES20.glEnable(2884);
    }

    public AssetManager getAssetManager() {
        return this.mAssetManager;
    }

    public void setAssetManager(AssetManager assetManager) {
        this.mAssetManager = assetManager;
    }

    public void reset() {
        this.mMediaPlayers = new ArrayList();
        this.mVertexBuffers = new ArrayList();
        this.mIndexBuffers = new ArrayList();
        this.mTextures = new ArrayList();
        this.mShaders = new ArrayList();
        this.mRenderTargets = new ArrayList();
        ARShaderManager shaderManager = ARShaderManager.getInstance();
        shaderManager.reset();
        this.mActivity = null;
        this.mTouchCoords = null;
        this.mListeners = new ArrayList();
    }

    public void makeActiveVideoTexture(ARVideoTexture videoTexture) {
        if(this.mActiveVideoTexture != null) {
            this.mActiveVideoTexture.spill();
        }

        this.mActiveVideoTexture = videoTexture;
        this.mActiveVideoTexture.open();
    }

    public void addMediaPlayer(MediaPlayer mediaPlayer) {
        this.mMediaPlayers.add(mediaPlayer);
    }

    public List<MediaPlayer> getMediaPlayers() {
        return this.mMediaPlayers;
    }

    public List<ARVertexBuffer> getVertexBuffers() {
        return this.mVertexBuffers;
    }

    public List<ARIndexBuffer> getIndexBuffers() {
        return this.mIndexBuffers;
    }

    public List<ARTexture> getTextures() {
        return this.mTextures;
    }

    public List<ARShaderProgram> getShaders() {
        return this.mShaders;
    }

    public void addVertexBuffer(ARVertexBuffer vertexBuffer) {
        this.mVertexBuffers.add(vertexBuffer);
    }

    public void addIndexBuffer(ARIndexBuffer indexBuffer) {
        this.mIndexBuffers.add(indexBuffer);
    }

    public void addTexture(ARTexture texture) {
        this.mTextures.add(texture);
    }

    public void addShader(ARShaderProgram shader) {
        this.mShaders.add(shader);
    }

    public void loadContext() {
        Iterator var2 = this.mIndexBuffers.iterator();

        while(var2.hasNext()) {
            ARIndexBuffer renderTarget = (ARIndexBuffer)var2.next();
            renderTarget.loadData();
        }

        var2 = this.mVertexBuffers.iterator();

        while(var2.hasNext()) {
            ARVertexBuffer renderTarget1 = (ARVertexBuffer)var2.next();
            renderTarget1.loadData();
        }

        var2 = this.mTextures.iterator();

        while(var2.hasNext()) {
            ARTexture renderTarget2 = (ARTexture)var2.next();
            renderTarget2.loadData();
        }

        var2 = this.mShaders.iterator();

        while(var2.hasNext()) {
            ARShaderProgram renderTarget3 = (ARShaderProgram)var2.next();
            renderTarget3.compileShaders();
        }

        var2 = this.mRenderTargets.iterator();

        while(var2.hasNext()) {
            ARRenderTarget renderTarget4 = (ARRenderTarget)var2.next();
            renderTarget4.create();
        }

    }

    public void setupCameraFBO() {
        int[] n = new int[1];
        GLES20.glGenFramebuffers(1, n, 0);
        int fboID = n[0];
        this.mCameraFBO = fboID;
        GLES20.glBindFramebuffer('赀', fboID);
        GLES20.glGenTextures(1, n, 0);
        int textureID = n[0];
        GLES20.glBindTexture(3553, textureID);
        Log.i("CAPTURE", "texture ID: " + textureID);
        GLES20.glTexParameterf(3553, 10241, 9729.0F);
        GLES20.glTexParameterf(3553, 10240, 9729.0F);
        GLES20.glTexParameterf(3553, 10243, 33071.0F);
        GLES20.glTexParameterf(3553, 10242, 33071.0F);
        GLES20.glTexImage2D(3553, 0, 6408, (int)this.cameraFBOResolution.getX(), (int)this.cameraFBOResolution.getY(), 0, 6408, 5121, (Buffer)null);
        GLES20.glFramebufferTexture2D('赀', '賠', 3553, textureID, 0);
    }

    public void setupCaptureFBO() {
        int[] n = new int[1];
        GLES20.glGenFramebuffers(1, n, 0);
        int fboID = n[0];
        this.mCaptureFBO = fboID;
        GLES20.glBindFramebuffer('赀', fboID);
        GLES20.glGenTextures(1, n, 0);
        int textureID = n[0];
        GLES20.glBindTexture(3553, textureID);
        GLES20.glTexParameterf(3553, 10241, 9729.0F);
        GLES20.glTexParameterf(3553, 10240, 9729.0F);
        GLES20.glTexParameterf(3553, 10243, 33071.0F);
        GLES20.glTexParameterf(3553, 10242, 33071.0F);
        GLES20.glTexImage2D(3553, 0, 6408, 1, 1, 0, 6408, 5121, (Buffer)null);
        GLES20.glFramebufferTexture2D('赀', '賠', 3553, textureID, 0);
        GLES20.glGenRenderbuffers(1, n, 0);
        int depthBuffer = n[0];
        GLES20.glBindRenderbuffer('赁', depthBuffer);
        GLES20.glRenderbufferStorage('赁', '膥', 1, 1);
        GLES20.glFramebufferRenderbuffer('赀', '贀', '赁', depthBuffer);
    }

    public void setTouchCoords(Point point) {
        Log.i("AR", "set touch coords");
        this.mTouchCoords = point;
    }

    public Vector3f getNextCaptureColour() {
        Vector3f nextColour = new Vector3f(this.mNextColour);
        float r = this.mNextColour.getX();
        float g = this.mNextColour.getY();
        float b = this.mNextColour.getZ();
        b += 8.0F;
        if(b >= 256.0F) {
            b = 0.0F;
            g += 8.0F;
        }

        if(g >= 256.0F) {
            g = 0.0F;
            r += 8.0F;
        }

        this.mNextColour.set(r, g, b);
        return nextColour;
    }

    public void enableVertexAttribute(int n) {
        if(!this.vertexAttributes[n]) {
            GLES20.glEnableVertexAttribArray(n);
            this.vertexAttributes[n] = true;
        }
    }

    public void disableVertexAttribute(int n) {
        if(this.vertexAttributes[n]) {
            GLES20.glDisableVertexAttribArray(n);
            this.vertexAttributes[n] = false;
        }
    }

    public void pause() {
        Iterator var2 = this.mListeners.iterator();

        while(var2.hasNext()) {
            ARRendererListener listener = (ARRendererListener)var2.next();
            listener.rendererDidPause();
        }

    }

    public synchronized void addListener(ARRendererListener listener) {
        this.mListeners.add(listener);
    }

    public synchronized void removeListener(ARRendererListener listener) {
        this.mListeners.remove(listener);
    }

    public void resume() {
        Iterator var2 = this.mListeners.iterator();

        while(var2.hasNext()) {
            ARRendererListener listener = (ARRendererListener)var2.next();
            listener.rendererDidResume();
        }

    }
}
