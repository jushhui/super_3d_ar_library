/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARAlphaVideoNode extends ARMeshNode {
/*    */   private ARVideoTexture mVideoTexture;
/*    */   
/*    */   public ARVideoTexture getVideoTexture() {
/*  7 */     return this.mVideoTexture;
/*    */   }
/*    */   
/*    */   public void setVideoTexture(ARVideoTexture videoTexture) {
/* 11 */     this.mVideoTexture = videoTexture;
/*    */   }
/*    */   
/*    */ 
/*    */   public ARAlphaVideoNode(ARVideoTexture videoTexture)
/*    */   {
/* 17 */     this.mVideoTexture = videoTexture;
/*    */     
/* 19 */     ARMesh mesh = new ARMesh();
/* 20 */     mesh.createTestMeshWithUvs(videoTexture.getWidth() / 2, videoTexture.getHeight(), 0.0F, 0.5F, 0.0F, 1.0F);
/*    */     
/* 22 */     setMesh(mesh);
/*    */     
/* 24 */     ARAlphaVideoTextureMaterial material = new ARAlphaVideoTextureMaterial(videoTexture);
/* 25 */     setMaterial(material);
/*    */     
/* 27 */     material.setTransparent(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARAlphaVideoNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */