/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import java.nio.IntBuffer;
/*    */ 
/*    */ public class ARTexture
/*    */ {
/*    */   protected int mNativeMem;
/*    */   protected int mTextureID;
/*    */   
/*    */   private native void initN();
/*    */   
/*    */   private native void destroyN(int paramInt);
/*    */   
/*    */   public ARTexture() {
/* 15 */     ARRenderer renderer = ARRenderer.getInstance();
/* 16 */     renderer.addTexture(this);
/* 17 */     initN();
/*    */   }
/*    */   
/*    */   public void finalize() {
/* 21 */     destroyN(this.mNativeMem);
/*    */   }
/*    */   
/*    */   public void createTexture() {
/* 25 */     IntBuffer buffer = IntBuffer.allocate(1);
/* 26 */     android.opengl.GLES20.glGenTextures(1, buffer);
/* 27 */     this.mTextureID = buffer.get(0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void bindTexture(int unit) {}
/*    */   
/*    */ 
/*    */   private native void loadDataN(java.io.FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*    */   
/*    */ 
/*    */   public void loadData() {}
/*    */   
/*    */ 
/*    */   public void prepareRenderer(int unit) {}
/*    */   
/*    */ 
/*    */   public int getTextureID()
/*    */   {
/* 46 */     return this.mTextureID;
/*    */   }
/*    */   
/*    */   public void setTextureID(int textureID) {
/* 50 */     this.mTextureID = textureID;
/*    */   }
/*    */   
/*    */   private native int getWidthN();
/*    */   
/*    */   private native int getHeightN();
/*    */   
/* 57 */   public int getWidth() { return getWidthN(); }
/*    */   
/*    */   public int getHeight()
/*    */   {
/* 61 */     return getHeightN();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */