package eu.kudan.kudan;

public abstract interface ARRendererListener
{
  public abstract void preRender();
  
  public abstract void postRender();
  
  public abstract void rendererDidPause();
  
  public abstract void rendererDidResume();
}


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARRendererListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */