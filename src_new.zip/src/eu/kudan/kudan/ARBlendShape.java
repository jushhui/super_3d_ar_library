/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARBlendShape {
/*    */   private int mNativeMem;
/*    */   private float mFullWeight;
/*    */   
/*    */   public ARBlendShape(int nativeMem, float fullWeight) {
/*  8 */     this.mNativeMem = nativeMem;
/*  9 */     this.mFullWeight = fullWeight;
/*    */   }
/*    */   
/*    */   public float getFullWeight() {
/* 13 */     return this.mFullWeight;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARBlendShape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */