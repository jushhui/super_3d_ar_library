﻿

package eu.kudan.kudan;

import android.opengl.GLES20;
import eu.kudan.kudan.ARCamera;
import eu.kudan.kudan.ARRenderer;
import eu.kudan.kudan.ARViewPort;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ARRenderTarget {
    private ARCamera mCamera = new ARCamera();
    protected int mFramebufferID;
    private boolean mShouldClear = true;
    private boolean mShouldClearDepth = true;
    private int mPriority;
    private List<ARViewPort> mViewPorts = new ArrayList();

    public ARRenderTarget() {
        ARRenderer renderer = ARRenderer.getInstance();
        renderer.addRenderTarget(this);
    }

    public void setPriority(int priority) {
        this.mPriority = priority;
    }

    public int getPriority() {
        return this.mPriority;
    }

    public void setShouldClear(boolean shouldClear) {
        this.mShouldClear = shouldClear;
    }

    public boolean getShouldClear() {
        return this.mShouldClear;
    }

    public void setShouldClearDepth(boolean shouldClearDepth) {
        this.mShouldClearDepth = shouldClearDepth;
    }

    public boolean getShouldClearDepth() {
        return this.mShouldClearDepth;
    }

    public void clear() {
        int flags = 0;
        if(this.mShouldClear) {
            flags |= 16384;
        }

        if(this.mShouldClearDepth) {
            GLES20.glDepthMask(true);
            flags |= 256;
        }

        if(flags != 0) {
            GLES20.glClear(flags);
        }

    }

    public void setCamera(ARCamera camera) {
        this.mCamera = camera;
    }

    public ARCamera getCamera() {
        return this.mCamera;
    }

    public void create() {
    }

    public void bind() {
        GLES20.glBindFramebuffer('赀', 0);
    }

    public void draw() {
        ARRenderer renderer = ARRenderer.getInstance();
        this.bind();
        this.clear();
        if(this.mCamera != null) {
            Collections.sort(this.mViewPorts, new Comparator<ARViewPort>() {
                public int compare(ARViewPort lhs, ARViewPort rhs) {
                    int a = lhs.getZOrder();
                    int b = rhs.getZOrder();
                    return a - b;
                }
            });
            Iterator var3 = this.mViewPorts.iterator();

            while(var3.hasNext()) {
                ARViewPort viewPort = (ARViewPort)var3.next();
                ARCamera camera = viewPort.getCamera();
                if(camera != null) {
                    GLES20.glViewport(viewPort.getOffsetX(), viewPort.getOffsetY(), viewPort.getWidth(), viewPort.getHeight());
                    renderer.setCamera(camera);
                    renderer.setProjectionMatrix(camera.getProjectionMatrix());
                    renderer.draw();
                }
            }

        }
    }

    public List<ARViewPort> getViewPorts() {
        return this.mViewPorts;
    }

    public void addViewPort(ARViewPort viewPort) {
        this.mViewPorts.add(viewPort);
    }
}
