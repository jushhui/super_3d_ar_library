/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ import java.nio.IntBuffer;
/*    */ import java.nio.ShortBuffer;
/*    */ 
/*    */ 
/*    */ public class ARIndexBuffer
/*    */ {
/*    */   private int mBufferID;
/*    */   private ShortBuffer mIndexData;
/*    */   private NativeMesh mNativeMesh;
/*    */   private int mNativeMem;
/*    */   
/*    */   ARIndexBuffer()
/*    */   {
/* 17 */     ARRenderer renderer = ARRenderer.getInstance();
/* 18 */     renderer.addIndexBuffer(this);
/*    */   }
/*    */   
/*    */   ARIndexBuffer(NativeMesh nativeMesh) {
/* 22 */     this();
/* 23 */     this.mNativeMesh = nativeMesh;
/*    */   }
/*    */   
/*    */   ARIndexBuffer(int nativeBuffer) {
/* 27 */     this();
/* 28 */     this.mNativeMem = nativeBuffer;
/*    */   }
/*    */   
/*    */   public void setIndexData(short[] indexData) {
/* 32 */     this.mIndexData = ShortBuffer.allocate(indexData.length);
/* 33 */     this.mIndexData.put(indexData);
/* 34 */     this.mIndexData.flip();
/*    */   }
/*    */   
/*    */   void createBuffer() {
/* 38 */     IntBuffer buffer = IntBuffer.allocate(1);
/* 39 */     GLES20.glGenBuffers(1, buffer);
/*    */     
/* 41 */     this.mBufferID = buffer.get(0);
/*    */   }
/*    */   
/*    */ 
/* 45 */   public void bindBuffer() { GLES20.glBindBuffer(34963, this.mBufferID); }
/*    */   
/*    */   private native void loadDataN(int paramInt);
/*    */   
/*    */   public void loadData() {
/* 50 */     createBuffer();
/* 51 */     bindBuffer();
/*    */     
/* 53 */     if (this.mNativeMem == 0) {
/* 54 */       int size = this.mIndexData.capacity() * 2;
/*    */       
/* 56 */       GLES20.glBufferData(34963, size, this.mIndexData, 35044);
/*    */     } else {
/* 58 */       loadDataN(this.mNativeMem);
/*    */     }
/*    */   }
/*    */   
/*    */   public void prepareRenderer() {
/* 63 */     bindBuffer();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARIndexBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */