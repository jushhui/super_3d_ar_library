/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.graphics.SurfaceTexture;
/*    */ 
/*    */ public class ARVideoTextureMaterial extends ARMaterial
/*    */ {
/*    */   private ARTextureOES mTexture;
/*    */   private ARVideoTextureShader mShader;
/*    */   private float[] mUVTransform;
/*    */   
/*    */   public ARVideoTextureMaterial()
/*    */   {
/* 13 */     this.mUVTransform = new float[16];
/* 14 */     this.mShader = ARVideoTextureShader.getShader();
/*    */   }
/*    */   
/*    */   public ARVideoTextureMaterial(ARTextureOES texture) {
/* 18 */     this();
/* 19 */     this.mTexture = texture;
/*    */   }
/*    */   
/*    */   public boolean prepareRendererWithNode(ARNode node)
/*    */   {
/* 24 */     boolean b = super.prepareRendererWithNode(node);
/* 25 */     if (!b) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     if (this.mTexture.getSurfaceTexture() != null) {
/* 30 */       this.mTexture.getSurfaceTexture().getTransformMatrix(this.mUVTransform);
/*    */     }
/*    */     
/* 33 */     this.mShader.prepareRenderer();
/* 34 */     this.mShader.setUVTransform(this.mUVTransform);
/*    */     
/* 36 */     this.mTexture.prepareRenderer(0);
/*    */     
/*    */ 
/* 39 */     return true;
/*    */   }
/*    */   
/*    */   public void setUVTransform(float[] uvTransform)
/*    */   {
/* 44 */     this.mUVTransform = uvTransform;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARVideoTextureMaterial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */