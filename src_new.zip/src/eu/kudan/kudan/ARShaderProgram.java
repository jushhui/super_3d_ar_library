/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.opengl.GLES20;
/*     */ import android.util.Log;
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Vector3f;
/*     */ 
/*     */ public class ARShaderProgram
/*     */ {
/*     */   private String mVertexShaderString;
/*     */   private String mFragmentShaderString;
/*     */   protected int mShaderID;
/*  13 */   private float[] mTmpMatrix = new float[16];
/*  14 */   private float[] mTmpMatrix9 = new float[9];
/*  15 */   private float[] mTmpVector3 = new float[3];
/*     */   
/*  17 */   private boolean mIsCompiled = false;
/*     */   
/*     */   static int initShader(int shaderType, String source)
/*     */   {
/*  21 */     int shader = GLES20.glCreateShader(shaderType);
/*  22 */     if (shader != 0)
/*     */     {
/*  24 */       GLES20.glShaderSource(shader, source);
/*  25 */       GLES20.glCompileShader(shader);
/*     */       
/*  27 */       int[] glStatusVar = new int[1];
/*  28 */       GLES20.glGetShaderiv(shader, 35713, glStatusVar, 
/*  29 */         0);
/*  30 */       if (glStatusVar[0] == 0)
/*     */       {
/*  32 */         Log.e("KudanAR", "couldn't compile shader" + shaderType + " : " + 
/*  33 */           GLES20.glGetShaderInfoLog(shader));
/*  34 */         GLES20.glDeleteShader(shader);
/*  35 */         shader = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  40 */     return shader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int createShader(String vertexShaderSrc, String fragmentShaderSrc)
/*     */   {
/*  47 */     int vertShader = initShader(35633, vertexShaderSrc);
/*  48 */     int fragShader = initShader(35632, 
/*  49 */       fragmentShaderSrc);
/*     */     
/*  51 */     if ((vertShader == 0) || (fragShader == 0)) {
/*  52 */       return 0;
/*     */     }
/*  54 */     int program = GLES20.glCreateProgram();
/*  55 */     if (program != 0)
/*     */     {
/*  57 */       GLES20.glAttachShader(program, vertShader);
/*  58 */       checkError();
/*     */       
/*  60 */       GLES20.glAttachShader(program, fragShader);
/*  61 */       checkError();
/*     */       
/*  63 */       int PositionAttribute = 0;
/*  64 */       int NormalAttribute = 1;
/*  65 */       int UVAttribute = 2;
/*  66 */       int BoneIndexAttribute = 3;
/*  67 */       int BoneWeightAttribute = 4;
/*     */       
/*  69 */       GLES20.glBindAttribLocation(program, 0, "vertexPosition");
/*  70 */       GLES20.glBindAttribLocation(program, 1, "vertexNormal");
/*  71 */       GLES20.glBindAttribLocation(program, 2, "vertexUV");
/*  72 */       GLES20.glBindAttribLocation(program, 3, "boneIndex");
/*  73 */       GLES20.glBindAttribLocation(program, 4, "boneWeight");
/*     */       
/*     */ 
/*     */ 
/*  77 */       GLES20.glLinkProgram(program);
/*  78 */       int[] glStatusVar = new int[1];
/*  79 */       GLES20.glGetProgramiv(program, 35714, glStatusVar, 
/*  80 */         0);
/*  81 */       if (glStatusVar[0] == 0)
/*     */       {
/*  83 */         Log.e(
/*  84 */           "KudanAR", 
/*  85 */           "Couldn't link shader: " + 
/*  86 */           GLES20.glGetProgramInfoLog(program));
/*  87 */         GLES20.glDeleteProgram(program);
/*  88 */         program = 0;
/*     */       }
/*     */     }
/*     */     
/*  92 */     return program;
/*     */   }
/*     */   
/*     */ 
/*     */   public static void checkError()
/*     */   {
/*  98 */     for (int error = GLES20.glGetError(); error != 0; error = 
/*  99 */           GLES20.glGetError()) {
/* 100 */       Log.e(
/* 101 */         "KudanAR", 
/* 102 */         "gl error: " + Integer.toHexString(error));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setShaderStrings(String vertexShaderString, String fragmentShaderString)
/*     */   {
/* 110 */     this.mVertexShaderString = vertexShaderString;
/* 111 */     this.mFragmentShaderString = fragmentShaderString;
/*     */   }
/*     */   
/*     */   public void compileShaders() {
/* 115 */     if (this.mIsCompiled) {
/* 116 */       return;
/*     */     }
/*     */     
/* 119 */     this.mIsCompiled = true;
/* 120 */     this.mShaderID = createShader(this.mVertexShaderString, this.mFragmentShaderString);
/*     */   }
/*     */   
/*     */   public void useProgram()
/*     */   {
/* 125 */     GLES20.glUseProgram(this.mShaderID);
/*     */   }
/*     */   
/*     */   public void prepareRenderer() {
/* 129 */     useProgram();
/* 130 */     setGlobalUniforms();
/*     */   }
/*     */   
/*     */   private void setGlobalUniforms() {
/* 134 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/* 136 */     int modelViewProjectionUniformHandle = GLES20.glGetUniformLocation(this.mShaderID, "modelViewProjectionMatrix");
/* 137 */     if (modelViewProjectionUniformHandle >= 0) {
/* 138 */       renderer.getModelViewProjectionMatrix().get(this.mTmpMatrix, false);
/* 139 */       GLES20.glUniformMatrix4fv(modelViewProjectionUniformHandle, 1, false, this.mTmpMatrix, 0);
/*     */     }
/*     */     
/* 142 */     int modelViewUniformHandle = GLES20.glGetUniformLocation(this.mShaderID, "modelViewMatrix");
/* 143 */     if (modelViewUniformHandle >= 0) {
/* 144 */       renderer.getModelViewMatrix().get(this.mTmpMatrix, false);
/* 145 */       GLES20.glUniformMatrix4fv(modelViewUniformHandle, 1, false, this.mTmpMatrix, 0);
/*     */     }
/*     */     
/* 148 */     int modelUniformHandle = GLES20.glGetUniformLocation(this.mShaderID, "modelMatrix");
/* 149 */     if (modelUniformHandle >= 0) {
/* 150 */       renderer.getModelMatrix().get(this.mTmpMatrix, false);
/* 151 */       GLES20.glUniformMatrix4fv(modelUniformHandle, 1, false, this.mTmpMatrix, 0);
/*     */     }
/*     */     
/* 154 */     int normalUniformHandle = GLES20.glGetUniformLocation(this.mShaderID, "normalMatrix");
/* 155 */     if (normalUniformHandle >= 0) {
/* 156 */       renderer.getNormalMatrix().get(this.mTmpMatrix9, false);
/* 157 */       GLES20.glUniformMatrix3fv(normalUniformHandle, 1, false, this.mTmpMatrix9, 0);
/*     */     }
/*     */     
/* 160 */     int worldCameraHandle = GLES20.glGetUniformLocation(this.mShaderID, "worldCameraPosition");
/* 161 */     if (worldCameraHandle >= 0) {
/* 162 */       Vector3f worldCamPosition = renderer.getWorldCameraPosition();
/* 163 */       this.mTmpVector3[0] = worldCamPosition.getX();
/* 164 */       this.mTmpVector3[1] = worldCamPosition.getY();
/* 165 */       this.mTmpVector3[2] = worldCamPosition.getZ();
/* 166 */       GLES20.glUniform3fv(worldCameraHandle, 1, this.mTmpVector3, 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARShaderProgram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */