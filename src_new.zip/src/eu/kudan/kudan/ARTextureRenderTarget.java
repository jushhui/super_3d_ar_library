/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ public class ARTextureRenderTarget extends ARRenderTarget
/*    */ {
/*    */   private int mWidth;
/*    */   private int mHeight;
/*    */   private ARTexture2D mTexture;
/*    */   
/*    */   public ARTextureRenderTarget(int width, int height)
/*    */   {
/* 13 */     this.mWidth = width;
/* 14 */     this.mHeight = height;
/*    */   }
/*    */   
/*    */   public void bind() {
/* 18 */     GLES20.glBindFramebuffer(36160, this.mFramebufferID);
/*    */   }
/*    */   
/*    */   public void create() {
/* 22 */     int[] n = new int[1];
/* 23 */     GLES20.glGenFramebuffers(1, n, 0);
/*    */     
/* 25 */     int fboID = n[0];
/* 26 */     this.mFramebufferID = fboID;
/*    */     
/* 28 */     GLES20.glBindFramebuffer(36160, fboID);
/* 29 */     GLES20.glGenTextures(1, n, 0);
/*    */     
/* 31 */     int textureID = n[0];
/* 32 */     GLES20.glBindTexture(3553, textureID);
/*    */     
/* 34 */     android.util.Log.i("ARTextureRenderTarget", "create texture framebuffer with ID: " + textureID + " " + this.mWidth + "x" + this.mHeight);
/*    */     
/* 36 */     GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 37 */     GLES20.glTexParameterf(3553, 10240, 9729.0F);
/* 38 */     GLES20.glTexParameterf(3553, 10243, 33071.0F);
/* 39 */     GLES20.glTexParameterf(3553, 10242, 33071.0F);
/*    */     
/* 41 */     GLES20.glTexImage2D(3553, 0, 6408, this.mWidth, this.mHeight, 0, 6408, 5121, null);
/*    */     
/* 43 */     GLES20.glFramebufferTexture2D(36160, 36064, 3553, textureID, 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTextureRenderTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */