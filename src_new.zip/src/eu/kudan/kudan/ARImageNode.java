/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class ARImageNode
/*    */   extends ARMeshNode
/*    */ {
/*    */   public ARImageNode() {}
/*    */   
/*    */   public ARImageNode(String assetName)
/*    */   {
/* 10 */     this();
/*    */     
/*    */ 
/*    */ 
/* 14 */     ARTexture2D texture = new ARTexture2D();
/* 15 */     texture.loadFromAsset(assetName);
/* 16 */     ARTextureMaterial textureMaterial = new ARTextureMaterial(texture);
/* 17 */     textureMaterial.setTransparent(true);
/* 18 */     setMaterial(textureMaterial);
/*    */     
/* 20 */     ARMesh mesh = new ARMesh();
/* 21 */     mesh.createTestMesh2(texture.getWidth(), texture.getHeight());
/*    */     
/* 23 */     setMesh(mesh);
/*    */   }
/*    */   
/*    */   public ARImageNode(ARTexture2D texture) {
/* 27 */     this();
/* 28 */     ARTextureMaterial textureMaterial = new ARTextureMaterial(texture);
/* 29 */     textureMaterial.setTransparent(true);
/* 30 */     setMaterial(textureMaterial);
/*    */     
/* 32 */     ARMesh mesh = new ARMesh();
/* 33 */     mesh.createTestMesh2(texture.getWidth(), texture.getHeight());
/*    */     
/* 35 */     setMesh(mesh);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARImageNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */