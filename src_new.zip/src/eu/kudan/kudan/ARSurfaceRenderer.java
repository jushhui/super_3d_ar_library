/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ import android.opengl.GLSurfaceView.Renderer;
/*    */ import android.util.Log;
/*    */ import com.jme3.math.Matrix4f;
/*    */ import javax.microedition.khronos.egl.EGLConfig;
/*    */ import javax.microedition.khronos.opengles.GL10;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARSurfaceRenderer
/*    */   implements GLSurfaceView.Renderer
/*    */ {
/* 17 */   boolean mIsActive = false;
/*    */   
/*    */   ARCameraStream camStream;
/*    */   
/*    */   ARTexture2D camTexture;
/*    */   
/*    */   ARView mArView;
/* 24 */   private Matrix4f mProjectionMatrix = null;
/*    */   
/*    */ 
/* 27 */   private long mLastTime = 0L;
/* 28 */   private int mFramesRendered = 0;
/*    */   
/*    */   public ARSurfaceRenderer(ARView view)
/*    */   {
/* 32 */     this.mArView = view;
/*    */   }
/*    */   
/*    */ 
/*    */   public void onDrawFrame(GL10 gl)
/*    */   {
/* 38 */     synchronized () {
/* 39 */       this.mArView.preRender();
/* 40 */       renderFrame();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onSurfaceCreated(GL10 gl, EGLConfig config)
/*    */   {
/* 46 */     initRendering();
/*    */   }
/*    */   
/*    */ 
/*    */   public void onSurfaceChanged(GL10 gl, int width, int height) {}
/*    */   
/*    */ 
/* 53 */   boolean loaded = false;
/*    */   
/*    */   private void initRendering() {
/* 56 */     Log.i("AR", "initRendering");
/*    */     
/* 58 */     GLES20.glClearColor(1.0F, 0.0F, 0.0F, 1.0F);
/*    */     
/* 60 */     ARRenderer renderer = ARRenderer.getInstance();
/*    */     
/*    */ 
/* 63 */     renderer.loadContext();
/*    */   }
/*    */   
/*    */ 
/*    */   private synchronized void renderFrame()
/*    */   {
/* 69 */     ARRenderer renderer = ARRenderer.getInstance();
/*    */     
/*    */ 
/*    */ 
/* 73 */     GLES20.glColorMask(true, true, true, true);
/*    */     
/*    */ 
/*    */ 
/* 77 */     GLES20.glDisable(3042);
/*    */     
/*    */ 
/* 80 */     renderer.render();
/*    */     
/*    */ 
/* 83 */     long curTime = System.currentTimeMillis();
/* 84 */     if (this.mLastTime == 0L) {
/* 85 */       this.mLastTime = curTime;
/*    */     }
/*    */     
/* 88 */     this.mFramesRendered += 1;
/*    */     
/* 90 */     if (curTime - this.mLastTime > 5000L) {
/* 91 */       float fps = this.mFramesRendered / ((float)(curTime - this.mLastTime) / 1000.0F);
/* 92 */       Log.i("AR", "fps: " + fps);
/*    */       
/* 94 */       this.mFramesRendered = 0;
/* 95 */       this.mLastTime = curTime;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARSurfaceRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */