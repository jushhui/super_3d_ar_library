/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ public class NativeMesh {
/*    */   private int mNativeMem;
/*    */   
/*    */   private native void initN();
/*    */   
/*  8 */   public NativeMesh() { initN(); }
/*    */   
/*    */   native boolean getHasNormalsN();
/*    */   
/*    */   public boolean getHasNormals() {
/* 13 */     return getHasNormalsN();
/*    */   }
/*    */   
/*    */   native boolean getHasUVsN();
/*    */   
/* 18 */   public boolean getHasUVs() { return getHasUVsN(); }
/*    */   
/*    */   native boolean getHasTangentsN();
/*    */   
/*    */   public boolean getHasTangents() {
/* 23 */     return getHasTangentsN();
/*    */   }
/*    */   
/*    */   native boolean getHasBonesN();
/*    */   
/* 28 */   public boolean getHasBones() { return getHasBones(); }
/*    */   
/*    */   native int getMaxBonesN();
/*    */   
/*    */   public int getMaxBones() {
/* 33 */     return getMaxBonesN();
/*    */   }
/*    */   
/*    */   native int getNumberOfBonesN();
/*    */   
/* 38 */   public int getNumberOfBones() { return getNumberOfBonesN(); }
/*    */   
/*    */   native int getNumberOfIndicesN();
/*    */   
/*    */   public int getNumberOfIndices() {
/* 43 */     return getNumberOfIndicesN();
/*    */   }
/*    */   
/*    */   private native void releaseN();
/*    */   
/* 48 */   public void finalize() { releaseN(); }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\NativeMesh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */