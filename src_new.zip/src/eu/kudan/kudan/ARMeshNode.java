/*     */ package eu.kudan.kudan;
/*     */ 
/*     */ import android.opengl.GLES20;
/*     */ import com.jme3.math.Matrix3f;
/*     */ import com.jme3.math.Matrix4f;
/*     */ import com.jme3.math.Quaternion;
/*     */ import com.jme3.math.Vector3f;
/*     */ 
/*     */ public class ARMeshNode
/*     */   extends ARNode
/*     */ {
/*     */   private ARMesh mMesh;
/*     */   private ARMaterial mMaterial;
/*  14 */   private Matrix3f mWorldOrientation = new Matrix3f();
/*  15 */   private Matrix4f mWorldInverse = new Matrix4f();
/*  16 */   private Vector3f mZeroVector = new Vector3f(0.0F, 0.0F, 0.0F);
/*  17 */   private Vector3f mYVector = new Vector3f(0.0F, 1.0F, 0.0F);
/*  18 */   private Vector3f mLightVector = new Vector3f();
/*  19 */   private Vector3f mWorldCameraPosition = new Vector3f();
/*     */   
/*     */   private Vector3f mCaptureColour;
/*     */   
/*     */   private ARMaterial mCaptureMaterial;
/*     */   
/*     */   public ARMeshNode()
/*     */   {
/*  27 */     ARRenderer renderer = ARRenderer.getInstance();
/*  28 */     this.mCaptureColour = renderer.getNextCaptureColour();
/*     */     
/*  30 */     Vector3f col = this.mCaptureColour.mult(0.00390625F);
/*  31 */     this.mCaptureMaterial = new ARColourMaterial(col);
/*     */   }
/*     */   
/*     */   public Vector3f getCaptureColour() {
/*  35 */     return this.mCaptureColour;
/*     */   }
/*     */   
/*     */   public ARMesh getMesh() {
/*  39 */     return this.mMesh;
/*     */   }
/*     */   
/*     */   public void setMesh(ARMesh mesh) {
/*  43 */     this.mMesh = mesh;
/*     */   }
/*     */   
/*     */   public ARMaterial getMaterial() {
/*  47 */     return this.mMaterial;
/*     */   }
/*     */   
/*     */   public void setMaterial(ARMaterial material) {
/*  51 */     this.mMaterial = material;
/*     */   }
/*     */   
/*     */   public void render() {
/*  55 */     super.render();
/*     */     
/*     */ 
/*  58 */     ARRenderer renderer = ARRenderer.getInstance();
/*     */     
/*  60 */     renderer.setModelViewMatrix(getFullTransform());
/*  61 */     renderer.setModelMatrix(getWorldTransform());
/*     */     
/*  63 */     Quaternion worldOrientation = getWorld().getWorldOrientation();
/*     */     
/*  65 */     this.mWorldOrientation.set(getFullOrientation());
/*  66 */     this.mWorldOrientation.scale(getWorldScale());
/*  67 */     renderer.setNormalMatrix(this.mWorldOrientation);
/*     */     
/*  69 */     this.mWorldInverse.set(getWorld().getWorldTransform());
/*  70 */     this.mWorldInverse.invertLocal();
/*  71 */     this.mWorldInverse.mult(this.mZeroVector, this.mWorldCameraPosition);
/*  72 */     renderer.setWorldCameraPosition(this.mWorldCameraPosition);
/*     */     
/*     */ 
/*     */ 
/*  76 */     renderer.setLightPosition(worldOrientation.mult(this.mLightVector));
/*     */     
/*  78 */     this.mMesh.prepareRenderer(this);
/*     */     
/*  80 */     if (!renderer.getRenderForCapture()) {
/*  81 */       this.mMaterial.prepareRendererWithNode(this);
/*     */     } else {
/*  83 */       this.mCaptureMaterial.prepareRendererWithNode(this);
/*     */     }
/*     */     
/*  86 */     GLES20.glEnable(2929);
/*  87 */     GLES20.glDisable(2884);
/*  88 */     GLES20.glBlendFunc(770, 771);
/*     */     
/*  90 */     if (!this.mMaterial.getTransparent()) {
/*  91 */       GLES20.glDisable(3042);
/*     */     } else {
/*  93 */       GLES20.glEnable(3042);
/*     */     }
/*     */     
/*  96 */     glDraw();
/*     */   }
/*     */   
/*     */   public Vector3f getLightDirection() {
/* 100 */     return this.mLightVector;
/*     */   }
/*     */   
/*     */   public void setLightDirection(Vector3f mLightVector) {
/* 104 */     this.mLightVector = mLightVector;
/*     */   }
/*     */   
/*     */   protected void glDraw() {
/* 108 */     GLES20.glDrawElements(4, this.mMesh.getNumberOfIndices(), 5123, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARMeshNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */