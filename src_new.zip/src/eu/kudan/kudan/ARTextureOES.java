/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.graphics.SurfaceTexture;
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARTextureOES
/*    */   extends ARTexture
/*    */ {
/*    */   protected SurfaceTexture mSurfaceTexture;
/*    */   
/*    */   public void setSurfaceTexture(SurfaceTexture surfaceTexture)
/*    */   {
/* 15 */     this.mSurfaceTexture = surfaceTexture;
/*    */   }
/*    */   
/*    */   public SurfaceTexture getSurfaceTexture() {
/* 19 */     return this.mSurfaceTexture;
/*    */   }
/*    */   
/*    */   public ARTextureOES(int textureID)
/*    */   {
/* 24 */     this.mTextureID = textureID;
/*    */   }
/*    */   
/*    */ 
/*    */   public ARTextureOES() {}
/*    */   
/*    */ 
/*    */   public void bindTexture(int unit)
/*    */   {
/* 33 */     int texUnit = 33984;
/* 34 */     if (unit == 1) {
/* 35 */       texUnit = 33985;
/*    */     }
/* 37 */     if (unit == 2) {
/* 38 */       texUnit = 33986;
/*    */     }
/*    */     
/* 41 */     GLES20.glActiveTexture(texUnit);
/* 42 */     GLES20.glBindTexture(36197, this.mTextureID);
/*    */   }
/*    */   
/*    */   public void prepareRenderer(int unit)
/*    */   {
/* 47 */     bindTexture(unit);
/* 48 */     GLES20.glTexParameterf(3553, 10241, 9729.0F);
/* 49 */     GLES20.glTexParameterf(3553, 10240, 9729.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTextureOES.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */