/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.content.res.AssetFileDescriptor;
/*    */ import android.util.Log;
/*    */ import java.io.FileDescriptor;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ARTrackableSet
/*    */ {
/*    */   private List<ARImageTrackable> mTrackables;
/*    */   
/*    */   public ARTrackableSet()
/*    */   {
/* 14 */     this.mTrackables = new java.util.ArrayList();
/*    */   }
/*    */   
/*    */   public List<ARImageTrackable> getTrackables() {
/* 18 */     return this.mTrackables;
/*    */   }
/*    */   
/*    */   private native void loadFromPathN(String paramString);
/*    */   
/* 23 */   public void loadFromPath(String path) { loadFromPathN(path); }
/*    */   
/*    */   private native void loadFromAssetN(FileDescriptor paramFileDescriptor, int paramInt1, int paramInt2);
/*    */   
/*    */   public void loadFromAsset(String asset)
/*    */   {
/*    */     try {
/* 30 */       ARRenderer renderer = ARRenderer.getInstance();
/* 31 */       AssetFileDescriptor fd = renderer.getAssetManager().openFd(asset);
/* 32 */       loadFromAssetN(fd.getFileDescriptor(), (int)fd.getStartOffset(), (int)fd.getLength());
/* 33 */       fd.close();
/*    */     }
/*    */     catch (Exception e) {
/* 36 */       e.printStackTrace();
/* 37 */       return;
/*    */     }
/*    */   }
/*    */   
/*    */   private void createTrackableWithNativeMem(int nativeMem) {
/* 42 */     ARImageTrackable trackable = new ARImageTrackable(nativeMem);
/* 43 */     this.mTrackables.add(trackable);
/*    */     
/* 45 */     Log.i("KudanAR", "adding: " + trackable.getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARTrackableSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */