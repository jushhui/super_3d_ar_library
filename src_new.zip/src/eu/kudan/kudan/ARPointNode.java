/*    */ package eu.kudan.kudan;
/*    */ 
/*    */ import android.opengl.GLES20;
/*    */ 
/*    */ public class ARPointNode
/*    */   extends ARMeshNode
/*    */ {
/*    */   private int mNumberOfPoints;
/*    */   
/*    */   public ARPointNode()
/*    */   {
/* 12 */     ARMesh mesh = new ARMesh();
/* 13 */     mesh.createTestMeshNoUV(10.0F, 10.0F);
/*    */     
/* 15 */     setMesh(mesh);
/*    */   }
/*    */   
/*    */ 
/*    */   public void setNumberOfPoints(int numberOfPoints)
/*    */   {
/* 21 */     this.mNumberOfPoints = numberOfPoints;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void glDraw()
/*    */   {
/* 27 */     GLES20.glClear(256);
/* 28 */     GLES20.glDisable(2929);
/* 29 */     GLES20.glDrawArrays(0, 0, this.mNumberOfPoints);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\eu\kudan\kudan\ARPointNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */