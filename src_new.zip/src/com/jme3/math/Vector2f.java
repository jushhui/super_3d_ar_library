/*     */ package com.jme3.math;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.Serializable;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Vector2f
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*  49 */   private static final Logger logger = Logger.getLogger(Vector2f.class.getName());
/*     */   
/*  51 */   public static final Vector2f ZERO = new Vector2f(0.0F, 0.0F);
/*  52 */   public static final Vector2f UNIT_XY = new Vector2f(1.0F, 1.0F);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f(float x, float y)
/*     */   {
/*  72 */     this.x = x;
/*  73 */     this.y = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector2f()
/*     */   {
/*  80 */     this.x = (this.y = 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f(Vector2f vector2f)
/*     */   {
/*  90 */     this.x = vector2f.x;
/*  91 */     this.y = vector2f.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f set(float x, float y)
/*     */   {
/* 104 */     this.x = x;
/* 105 */     this.y = y;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f set(Vector2f vec)
/*     */   {
/* 117 */     this.x = vec.x;
/* 118 */     this.y = vec.y;
/* 119 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f add(Vector2f vec)
/*     */   {
/* 132 */     if (vec == null) {
/* 133 */       logger.warning("Provided vector is null, null returned.");
/* 134 */       return null;
/*     */     }
/* 136 */     return new Vector2f(this.x + vec.x, this.y + vec.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f addLocal(Vector2f vec)
/*     */   {
/* 149 */     if (vec == null) {
/* 150 */       logger.warning("Provided vector is null, null returned.");
/* 151 */       return null;
/*     */     }
/* 153 */     this.x += vec.x;
/* 154 */     this.y += vec.y;
/* 155 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f addLocal(float addX, float addY)
/*     */   {
/* 170 */     this.x += addX;
/* 171 */     this.y += addY;
/* 172 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f add(Vector2f vec, Vector2f result)
/*     */   {
/* 186 */     if (vec == null) {
/* 187 */       logger.warning("Provided vector is null, null returned.");
/* 188 */       return null;
/*     */     }
/* 190 */     if (result == null)
/* 191 */       result = new Vector2f();
/* 192 */     this.x += vec.x;
/* 193 */     this.y += vec.y;
/* 194 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float dot(Vector2f vec)
/*     */   {
/* 206 */     if (vec == null) {
/* 207 */       logger.warning("Provided vector is null, 0 returned.");
/* 208 */       return 0.0F;
/*     */     }
/* 210 */     return this.x * vec.x + this.y * vec.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector3f cross(Vector2f v)
/*     */   {
/* 222 */     return new Vector3f(0.0F, 0.0F, determinant(v));
/*     */   }
/*     */   
/*     */   public float determinant(Vector2f v) {
/* 226 */     return this.x * v.y - this.y * v.x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f interpolate(Vector2f finalVec, float changeAmnt)
/*     */   {
/* 240 */     this.x = ((1.0F - changeAmnt) * this.x + changeAmnt * finalVec.x);
/* 241 */     this.y = ((1.0F - changeAmnt) * this.y + changeAmnt * finalVec.y);
/* 242 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f interpolate(Vector2f beginVec, Vector2f finalVec, float changeAmnt)
/*     */   {
/* 259 */     this.x = ((1.0F - changeAmnt) * beginVec.x + changeAmnt * finalVec.x);
/* 260 */     this.y = ((1.0F - changeAmnt) * beginVec.y + changeAmnt * finalVec.y);
/* 261 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isValidVector(Vector2f vector)
/*     */   {
/* 273 */     if (vector == null) return false;
/* 274 */     if ((Float.isNaN(vector.x)) || 
/* 275 */       (Float.isNaN(vector.y))) return false;
/* 276 */     if ((Float.isInfinite(vector.x)) || 
/* 277 */       (Float.isInfinite(vector.y))) return false;
/* 278 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float length()
/*     */   {
/* 287 */     return FastMath.sqrt(lengthSquared());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float lengthSquared()
/*     */   {
/* 297 */     return this.x * this.x + this.y * this.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float distanceSquared(Vector2f v)
/*     */   {
/* 308 */     double dx = this.x - v.x;
/* 309 */     double dy = this.y - v.y;
/* 310 */     return (float)(dx * dx + dy * dy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float distanceSquared(float otherX, float otherY)
/*     */   {
/* 322 */     double dx = this.x - otherX;
/* 323 */     double dy = this.y - otherY;
/* 324 */     return (float)(dx * dx + dy * dy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float distance(Vector2f v)
/*     */   {
/* 335 */     return FastMath.sqrt(distanceSquared(v));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f mult(float scalar)
/*     */   {
/* 347 */     return new Vector2f(this.x * scalar, this.y * scalar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f multLocal(float scalar)
/*     */   {
/* 359 */     this.x *= scalar;
/* 360 */     this.y *= scalar;
/* 361 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f multLocal(Vector2f vec)
/*     */   {
/* 374 */     if (vec == null) {
/* 375 */       logger.warning("Provided vector is null, null returned.");
/* 376 */       return null;
/*     */     }
/* 378 */     this.x *= vec.x;
/* 379 */     this.y *= vec.y;
/* 380 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f mult(float scalar, Vector2f product)
/*     */   {
/* 395 */     if (product == null) {
/* 396 */       product = new Vector2f();
/*     */     }
/*     */     
/* 399 */     this.x *= scalar;
/* 400 */     this.y *= scalar;
/* 401 */     return product;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f divide(float scalar)
/*     */   {
/* 413 */     return new Vector2f(this.x / scalar, this.y / scalar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f divideLocal(float scalar)
/*     */   {
/* 426 */     this.x /= scalar;
/* 427 */     this.y /= scalar;
/* 428 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f negate()
/*     */   {
/* 438 */     return new Vector2f(-this.x, -this.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f negateLocal()
/*     */   {
/* 447 */     this.x = (-this.x);
/* 448 */     this.y = (-this.y);
/* 449 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f subtract(Vector2f vec)
/*     */   {
/* 462 */     return subtract(vec, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f subtract(Vector2f vec, Vector2f store)
/*     */   {
/* 478 */     if (store == null)
/* 479 */       store = new Vector2f();
/* 480 */     this.x -= vec.x;
/* 481 */     this.y -= vec.y;
/* 482 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f subtract(float valX, float valY)
/*     */   {
/* 496 */     return new Vector2f(this.x - valX, this.y - valY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f subtractLocal(Vector2f vec)
/*     */   {
/* 509 */     if (vec == null) {
/* 510 */       logger.warning("Provided vector is null, null returned.");
/* 511 */       return null;
/*     */     }
/* 513 */     this.x -= vec.x;
/* 514 */     this.y -= vec.y;
/* 515 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f subtractLocal(float valX, float valY)
/*     */   {
/* 530 */     this.x -= valX;
/* 531 */     this.y -= valY;
/* 532 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f normalize()
/*     */   {
/* 541 */     float length = length();
/* 542 */     if (length != 0.0F) {
/* 543 */       return divide(length);
/*     */     }
/*     */     
/* 546 */     return divide(1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector2f normalizeLocal()
/*     */   {
/* 556 */     float length = length();
/* 557 */     if (length != 0.0F) {
/* 558 */       return divideLocal(length);
/*     */     }
/*     */     
/* 561 */     return divideLocal(1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float smallestAngleBetween(Vector2f otherVector)
/*     */   {
/* 574 */     float dotProduct = dot(otherVector);
/* 575 */     float angle = FastMath.acos(dotProduct);
/* 576 */     return angle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float angleBetween(Vector2f otherVector)
/*     */   {
/* 590 */     float angle = FastMath.atan2(otherVector.y, otherVector.x) - 
/* 591 */       FastMath.atan2(this.y, this.x);
/* 592 */     return angle;
/*     */   }
/*     */   
/*     */   public float getX() {
/* 596 */     return this.x;
/*     */   }
/*     */   
/*     */   public Vector2f setX(float x) {
/* 600 */     this.x = x;
/* 601 */     return this;
/*     */   }
/*     */   
/*     */   public float getY() {
/* 605 */     return this.y;
/*     */   }
/*     */   
/*     */   public Vector2f setY(float y) {
/* 609 */     this.y = y;
/* 610 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 620 */     return FastMath.atan2(this.y, this.x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector2f zero()
/*     */   {
/* 627 */     this.x = (this.y = 0.0F);
/* 628 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 639 */     int hash = 37;
/* 640 */     hash += 37 * hash + Float.floatToIntBits(this.x);
/* 641 */     hash += 37 * hash + Float.floatToIntBits(this.y);
/* 642 */     return hash;
/*     */   }
/*     */   
/*     */   public Vector2f clone()
/*     */   {
/*     */     try {
/* 648 */       return (Vector2f)super.clone();
/*     */     } catch (CloneNotSupportedException e) {
/* 650 */       throw new AssertionError();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] toArray(float[] floats)
/*     */   {
/* 663 */     if (floats == null) {
/* 664 */       floats = new float[2];
/*     */     }
/* 666 */     floats[0] = this.x;
/* 667 */     floats[1] = this.y;
/* 668 */     return floats;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 680 */     if (!(o instanceof Vector2f)) {
/* 681 */       return false;
/*     */     }
/*     */     
/* 684 */     if (this == o) {
/* 685 */       return true;
/*     */     }
/*     */     
/* 688 */     Vector2f comp = (Vector2f)o;
/* 689 */     if (Float.compare(this.x, comp.x) != 0)
/* 690 */       return false;
/* 691 */     if (Float.compare(this.y, comp.y) != 0)
/* 692 */       return false;
/* 693 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 704 */     return "(" + this.x + ", " + this.y + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 718 */     this.x = in.readFloat();
/* 719 */     this.y = in.readFloat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 731 */     out.writeFloat(this.x);
/* 732 */     out.writeFloat(this.y);
/*     */   }
/*     */   
/*     */   public void rotateAroundOrigin(float angle, boolean cw)
/*     */   {
/* 737 */     if (cw)
/* 738 */       angle = -angle;
/* 739 */     float newX = FastMath.cos(angle) * this.x - FastMath.sin(angle) * this.y;
/* 740 */     float newY = FastMath.sin(angle) * this.x + FastMath.cos(angle) * this.y;
/* 741 */     this.x = newX;
/* 742 */     this.y = newY;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Vector2f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */