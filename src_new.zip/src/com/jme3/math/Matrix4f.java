/*      */ package com.jme3.math;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Matrix4f
/*      */   implements Cloneable, Serializable
/*      */ {
/*      */   static final long serialVersionUID = 1L;
/*   58 */   private static final Logger logger = Logger.getLogger(Matrix4f.class.getName());
/*      */   public float m00;
/*      */   public float m01;
/*      */   public float m02;
/*      */   public float m03;
/*   63 */   public float m10; public float m11; public float m12; public float m13; public float m20; public float m21; public float m22; public float m23; public float m30; public float m31; public float m32; public float m33; public static final Matrix4f ZERO = new Matrix4f(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*   64 */   public static final Matrix4f IDENTITY = new Matrix4f();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f()
/*      */   {
/*   72 */     loadIdentity();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f(float m00, float m01, float m02, float m03, float m10, float m11, float m12, float m13, float m20, float m21, float m22, float m23, float m30, float m31, float m32, float m33)
/*      */   {
/*   83 */     this.m00 = m00;
/*   84 */     this.m01 = m01;
/*   85 */     this.m02 = m02;
/*   86 */     this.m03 = m03;
/*   87 */     this.m10 = m10;
/*   88 */     this.m11 = m11;
/*   89 */     this.m12 = m12;
/*   90 */     this.m13 = m13;
/*   91 */     this.m20 = m20;
/*   92 */     this.m21 = m21;
/*   93 */     this.m22 = m22;
/*   94 */     this.m23 = m23;
/*   95 */     this.m30 = m30;
/*   96 */     this.m31 = m31;
/*   97 */     this.m32 = m32;
/*   98 */     this.m33 = m33;
/*      */   }
/*      */   
/*      */   public Matrix4f(float focalX, float focalY, float prinX, float prinY, boolean rotate)
/*      */   {
/*      */     float pY;
/*      */     float width;
/*      */     float height;
/*      */     float fX;
/*      */     float fY;
/*      */     float pX;
/*      */     float pY;
/*  110 */     if (rotate) {
/*  111 */       float width = 480.0F;
/*  112 */       float height = 640.0F;
/*  113 */       float fX = focalY;
/*  114 */       float fY = focalX;
/*  115 */       float pX = prinY;
/*  116 */       pY = prinX;
/*      */     } else {
/*  118 */       width = 640.0F;
/*  119 */       height = 480.0F;
/*  120 */       fX = focalX;
/*  121 */       fY = focalY;
/*  122 */       pX = prinX;
/*  123 */       pY = prinY;
/*      */     }
/*      */     
/*  126 */     float far = 10000.0F;
/*  127 */     float near = 10.0F;
/*      */     
/*  129 */     float[] m = new float[16];
/*  130 */     m[0] = (2.0F * fX / width);
/*  131 */     m[5] = (2.0F * fY / height);
/*  132 */     m[8] = (2.0F * (pX / width) - 1.0F);
/*  133 */     m[9] = (2.0F * (pY / height) - 1.0F);
/*  134 */     m[10] = (-(far + near) / (far - near));
/*  135 */     m[11] = -1.0F;
/*  136 */     m[14] = (-2.0F * far * near / (far - near));
/*      */     
/*  138 */     set(m, false);
/*      */   }
/*      */   
/*      */   public Matrix4f(float focalX, float focalY, float prinX, float prinY)
/*      */   {
/*  143 */     this(focalX, focalY, prinX, prinY, false);
/*      */   }
/*      */   
/*      */   public Matrix4f(float left, float right, float bottom, float top, float near, float far)
/*      */   {
/*  148 */     float[] m = new float[16];
/*  149 */     for (int i = 0; i < 16; i++) {
/*  150 */       m[i] = 0.0F;
/*      */     }
/*      */     
/*  153 */     m[0] = (2.0F / (right - left));
/*  154 */     m[5] = (2.0F / (top - bottom));
/*  155 */     m[10] = (2.0F / (near - far));
/*  156 */     m[12] = (-(right + left) / (right - left));
/*  157 */     m[13] = (-(top + bottom) / (top - bottom));
/*  158 */     m[14] = ((far + near) / (far - near));
/*  159 */     m[15] = 1.0F;
/*      */     
/*  161 */     Matrix4f mat = new Matrix4f(m);
/*  162 */     set(mat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f(float[] array)
/*      */   {
/*  172 */     set(array, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f(Matrix4f mat)
/*      */   {
/*  184 */     copy(mat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copy(Matrix4f matrix)
/*      */   {
/*  196 */     if (matrix == null) {
/*  197 */       loadIdentity();
/*      */     } else {
/*  199 */       this.m00 = matrix.m00;
/*  200 */       this.m01 = matrix.m01;
/*  201 */       this.m02 = matrix.m02;
/*  202 */       this.m03 = matrix.m03;
/*  203 */       this.m10 = matrix.m10;
/*  204 */       this.m11 = matrix.m11;
/*  205 */       this.m12 = matrix.m12;
/*  206 */       this.m13 = matrix.m13;
/*  207 */       this.m20 = matrix.m20;
/*  208 */       this.m21 = matrix.m21;
/*  209 */       this.m22 = matrix.m22;
/*  210 */       this.m23 = matrix.m23;
/*  211 */       this.m30 = matrix.m30;
/*  212 */       this.m31 = matrix.m31;
/*  213 */       this.m32 = matrix.m32;
/*  214 */       this.m33 = matrix.m33;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void get(float[] matrix)
/*      */   {
/*  227 */     get(matrix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void get(float[] matrix, boolean rowMajor)
/*      */   {
/*  241 */     if (matrix.length != 16) {
/*  242 */       throw new IllegalArgumentException(
/*  243 */         "Array must be of size 16.");
/*      */     }
/*      */     
/*  246 */     if (rowMajor) {
/*  247 */       matrix[0] = this.m00;
/*  248 */       matrix[1] = this.m01;
/*  249 */       matrix[2] = this.m02;
/*  250 */       matrix[3] = this.m03;
/*  251 */       matrix[4] = this.m10;
/*  252 */       matrix[5] = this.m11;
/*  253 */       matrix[6] = this.m12;
/*  254 */       matrix[7] = this.m13;
/*  255 */       matrix[8] = this.m20;
/*  256 */       matrix[9] = this.m21;
/*  257 */       matrix[10] = this.m22;
/*  258 */       matrix[11] = this.m23;
/*  259 */       matrix[12] = this.m30;
/*  260 */       matrix[13] = this.m31;
/*  261 */       matrix[14] = this.m32;
/*  262 */       matrix[15] = this.m33;
/*      */     } else {
/*  264 */       matrix[0] = this.m00;
/*  265 */       matrix[4] = this.m01;
/*  266 */       matrix[8] = this.m02;
/*  267 */       matrix[12] = this.m03;
/*  268 */       matrix[1] = this.m10;
/*  269 */       matrix[5] = this.m11;
/*  270 */       matrix[9] = this.m12;
/*  271 */       matrix[13] = this.m13;
/*  272 */       matrix[2] = this.m20;
/*  273 */       matrix[6] = this.m21;
/*  274 */       matrix[10] = this.m22;
/*  275 */       matrix[14] = this.m23;
/*  276 */       matrix[3] = this.m30;
/*  277 */       matrix[7] = this.m31;
/*  278 */       matrix[11] = this.m32;
/*  279 */       matrix[15] = this.m33;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void get(float[] matrix, int offset, boolean rowMajor)
/*      */   {
/*  289 */     if (rowMajor) {
/*  290 */       matrix[(0 + offset)] = this.m00;
/*  291 */       matrix[(1 + offset)] = this.m01;
/*  292 */       matrix[(2 + offset)] = this.m02;
/*  293 */       matrix[(3 + offset)] = this.m03;
/*  294 */       matrix[(4 + offset)] = this.m10;
/*  295 */       matrix[(5 + offset)] = this.m11;
/*  296 */       matrix[(6 + offset)] = this.m12;
/*  297 */       matrix[(7 + offset)] = this.m13;
/*  298 */       matrix[(8 + offset)] = this.m20;
/*  299 */       matrix[(9 + offset)] = this.m21;
/*  300 */       matrix[(10 + offset)] = this.m22;
/*  301 */       matrix[(11 + offset)] = this.m23;
/*  302 */       matrix[(12 + offset)] = this.m30;
/*  303 */       matrix[(13 + offset)] = this.m31;
/*  304 */       matrix[(14 + offset)] = this.m32;
/*  305 */       matrix[(15 + offset)] = this.m33;
/*      */     } else {
/*  307 */       matrix[(0 + offset)] = this.m00;
/*  308 */       matrix[(4 + offset)] = this.m01;
/*  309 */       matrix[(8 + offset)] = this.m02;
/*  310 */       matrix[(12 + offset)] = this.m03;
/*  311 */       matrix[(1 + offset)] = this.m10;
/*  312 */       matrix[(5 + offset)] = this.m11;
/*  313 */       matrix[(9 + offset)] = this.m12;
/*  314 */       matrix[(13 + offset)] = this.m13;
/*  315 */       matrix[(2 + offset)] = this.m20;
/*  316 */       matrix[(6 + offset)] = this.m21;
/*  317 */       matrix[(10 + offset)] = this.m22;
/*  318 */       matrix[(14 + offset)] = this.m23;
/*  319 */       matrix[(3 + offset)] = this.m30;
/*  320 */       matrix[(7 + offset)] = this.m31;
/*  321 */       matrix[(11 + offset)] = this.m32;
/*  322 */       matrix[(15 + offset)] = this.m33;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float get(int i, int j)
/*      */   {
/*  339 */     switch (i) {
/*      */     case 0: 
/*  341 */       switch (j) {
/*      */       case 0: 
/*  343 */         return this.m00;
/*      */       case 1: 
/*  345 */         return this.m01;
/*      */       case 2: 
/*  347 */         return this.m02;
/*      */       case 3: 
/*  349 */         return this.m03;
/*      */       }
/*      */     case 1: 
/*  352 */       switch (j) {
/*      */       case 0: 
/*  354 */         return this.m10;
/*      */       case 1: 
/*  356 */         return this.m11;
/*      */       case 2: 
/*  358 */         return this.m12;
/*      */       case 3: 
/*  360 */         return this.m13;
/*      */       }
/*      */     case 2: 
/*  363 */       switch (j) {
/*      */       case 0: 
/*  365 */         return this.m20;
/*      */       case 1: 
/*  367 */         return this.m21;
/*      */       case 2: 
/*  369 */         return this.m22;
/*      */       case 3: 
/*  371 */         return this.m23;
/*      */       }
/*      */     case 3: 
/*  374 */       switch (j) {
/*      */       case 0: 
/*  376 */         return this.m30;
/*      */       case 1: 
/*  378 */         return this.m31;
/*      */       case 2: 
/*  380 */         return this.m32;
/*      */       case 3: 
/*  382 */         return this.m33;
/*      */       }
/*      */       break;
/*      */     }
/*  386 */     logger.warning("Invalid matrix index.");
/*  387 */     throw new IllegalArgumentException("Invalid indices into matrix.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] getColumn(int i)
/*      */   {
/*  399 */     return getColumn(i, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] getColumn(int i, float[] store)
/*      */   {
/*  414 */     if (store == null) {
/*  415 */       store = new float[4];
/*      */     }
/*  417 */     switch (i) {
/*      */     case 0: 
/*  419 */       store[0] = this.m00;
/*  420 */       store[1] = this.m10;
/*  421 */       store[2] = this.m20;
/*  422 */       store[3] = this.m30;
/*  423 */       break;
/*      */     case 1: 
/*  425 */       store[0] = this.m01;
/*  426 */       store[1] = this.m11;
/*  427 */       store[2] = this.m21;
/*  428 */       store[3] = this.m31;
/*  429 */       break;
/*      */     case 2: 
/*  431 */       store[0] = this.m02;
/*  432 */       store[1] = this.m12;
/*  433 */       store[2] = this.m22;
/*  434 */       store[3] = this.m32;
/*  435 */       break;
/*      */     case 3: 
/*  437 */       store[0] = this.m03;
/*  438 */       store[1] = this.m13;
/*  439 */       store[2] = this.m23;
/*  440 */       store[3] = this.m33;
/*  441 */       break;
/*      */     default: 
/*  443 */       logger.warning("Invalid column index.");
/*  444 */       throw new IllegalArgumentException("Invalid column index. " + i);
/*      */     }
/*  446 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumn(int i, float[] column)
/*      */   {
/*  461 */     if (column == null) {
/*  462 */       logger.warning("Column is null. Ignoring.");
/*  463 */       return;
/*      */     }
/*  465 */     switch (i) {
/*      */     case 0: 
/*  467 */       this.m00 = column[0];
/*  468 */       this.m10 = column[1];
/*  469 */       this.m20 = column[2];
/*  470 */       this.m30 = column[3];
/*  471 */       break;
/*      */     case 1: 
/*  473 */       this.m01 = column[0];
/*  474 */       this.m11 = column[1];
/*  475 */       this.m21 = column[2];
/*  476 */       this.m31 = column[3];
/*  477 */       break;
/*      */     case 2: 
/*  479 */       this.m02 = column[0];
/*  480 */       this.m12 = column[1];
/*  481 */       this.m22 = column[2];
/*  482 */       this.m32 = column[3];
/*  483 */       break;
/*      */     case 3: 
/*  485 */       this.m03 = column[0];
/*  486 */       this.m13 = column[1];
/*  487 */       this.m23 = column[2];
/*  488 */       this.m33 = column[3];
/*  489 */       break;
/*      */     default: 
/*  491 */       logger.warning("Invalid column index.");
/*  492 */       throw new IllegalArgumentException("Invalid column index. " + i);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(int i, int j, float value)
/*      */   {
/*  510 */     switch (i) {
/*      */     case 0: 
/*  512 */       switch (j) {
/*      */       case 0: 
/*  514 */         this.m00 = value;
/*  515 */         return;
/*      */       case 1: 
/*  517 */         this.m01 = value;
/*  518 */         return;
/*      */       case 2: 
/*  520 */         this.m02 = value;
/*  521 */         return;
/*      */       case 3: 
/*  523 */         this.m03 = value;
/*  524 */         return;
/*      */       }
/*      */     case 1: 
/*  527 */       switch (j) {
/*      */       case 0: 
/*  529 */         this.m10 = value;
/*  530 */         return;
/*      */       case 1: 
/*  532 */         this.m11 = value;
/*  533 */         return;
/*      */       case 2: 
/*  535 */         this.m12 = value;
/*  536 */         return;
/*      */       case 3: 
/*  538 */         this.m13 = value;
/*  539 */         return;
/*      */       }
/*      */     case 2: 
/*  542 */       switch (j) {
/*      */       case 0: 
/*  544 */         this.m20 = value;
/*  545 */         return;
/*      */       case 1: 
/*  547 */         this.m21 = value;
/*  548 */         return;
/*      */       case 2: 
/*  550 */         this.m22 = value;
/*  551 */         return;
/*      */       case 3: 
/*  553 */         this.m23 = value;
/*  554 */         return;
/*      */       }
/*      */     case 3: 
/*  557 */       switch (j) {
/*      */       case 0: 
/*  559 */         this.m30 = value;
/*  560 */         return;
/*      */       case 1: 
/*  562 */         this.m31 = value;
/*  563 */         return;
/*      */       case 2: 
/*  565 */         this.m32 = value;
/*  566 */         return;
/*      */       case 3: 
/*  568 */         this.m33 = value; return;
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*  573 */     logger.warning("Invalid matrix index.");
/*  574 */     throw new IllegalArgumentException("Invalid indices into matrix.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(float[][] matrix)
/*      */   {
/*  587 */     if ((matrix.length != 4) || (matrix[0].length != 4)) {
/*  588 */       throw new IllegalArgumentException(
/*  589 */         "Array must be of size 16.");
/*      */     }
/*      */     
/*  592 */     this.m00 = matrix[0][0];
/*  593 */     this.m01 = matrix[0][1];
/*  594 */     this.m02 = matrix[0][2];
/*  595 */     this.m03 = matrix[0][3];
/*  596 */     this.m10 = matrix[1][0];
/*  597 */     this.m11 = matrix[1][1];
/*  598 */     this.m12 = matrix[1][2];
/*  599 */     this.m13 = matrix[1][3];
/*  600 */     this.m20 = matrix[2][0];
/*  601 */     this.m21 = matrix[2][1];
/*  602 */     this.m22 = matrix[2][2];
/*  603 */     this.m23 = matrix[2][3];
/*  604 */     this.m30 = matrix[3][0];
/*  605 */     this.m31 = matrix[3][1];
/*  606 */     this.m32 = matrix[3][2];
/*  607 */     this.m33 = matrix[3][3];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(float m00, float m01, float m02, float m03, float m10, float m11, float m12, float m13, float m20, float m21, float m22, float m23, float m30, float m31, float m32, float m33)
/*      */   {
/*  619 */     this.m00 = m00;
/*  620 */     this.m01 = m01;
/*  621 */     this.m02 = m02;
/*  622 */     this.m03 = m03;
/*  623 */     this.m10 = m10;
/*  624 */     this.m11 = m11;
/*  625 */     this.m12 = m12;
/*  626 */     this.m13 = m13;
/*  627 */     this.m20 = m20;
/*  628 */     this.m21 = m21;
/*  629 */     this.m22 = m22;
/*  630 */     this.m23 = m23;
/*  631 */     this.m30 = m30;
/*  632 */     this.m31 = m31;
/*  633 */     this.m32 = m32;
/*  634 */     this.m33 = m33;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f set(Matrix4f matrix)
/*      */   {
/*  644 */     this.m00 = matrix.m00;
/*  645 */     this.m01 = matrix.m01;
/*  646 */     this.m02 = matrix.m02;
/*  647 */     this.m03 = matrix.m03;
/*  648 */     this.m10 = matrix.m10;
/*  649 */     this.m11 = matrix.m11;
/*  650 */     this.m12 = matrix.m12;
/*  651 */     this.m13 = matrix.m13;
/*  652 */     this.m20 = matrix.m20;
/*  653 */     this.m21 = matrix.m21;
/*  654 */     this.m22 = matrix.m22;
/*  655 */     this.m23 = matrix.m23;
/*  656 */     this.m30 = matrix.m30;
/*  657 */     this.m31 = matrix.m31;
/*  658 */     this.m32 = matrix.m32;
/*  659 */     this.m33 = matrix.m33;
/*  660 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(float[] matrix)
/*      */   {
/*  671 */     set(matrix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(float[] matrix, boolean rowMajor)
/*      */   {
/*  684 */     if (matrix.length != 16) {
/*  685 */       throw new IllegalArgumentException(
/*  686 */         "Array must be of size 16.");
/*      */     }
/*      */     
/*  689 */     if (rowMajor) {
/*  690 */       this.m00 = matrix[0];
/*  691 */       this.m01 = matrix[1];
/*  692 */       this.m02 = matrix[2];
/*  693 */       this.m03 = matrix[3];
/*  694 */       this.m10 = matrix[4];
/*  695 */       this.m11 = matrix[5];
/*  696 */       this.m12 = matrix[6];
/*  697 */       this.m13 = matrix[7];
/*  698 */       this.m20 = matrix[8];
/*  699 */       this.m21 = matrix[9];
/*  700 */       this.m22 = matrix[10];
/*  701 */       this.m23 = matrix[11];
/*  702 */       this.m30 = matrix[12];
/*  703 */       this.m31 = matrix[13];
/*  704 */       this.m32 = matrix[14];
/*  705 */       this.m33 = matrix[15];
/*      */     } else {
/*  707 */       this.m00 = matrix[0];
/*  708 */       this.m01 = matrix[4];
/*  709 */       this.m02 = matrix[8];
/*  710 */       this.m03 = matrix[12];
/*  711 */       this.m10 = matrix[1];
/*  712 */       this.m11 = matrix[5];
/*  713 */       this.m12 = matrix[9];
/*  714 */       this.m13 = matrix[13];
/*  715 */       this.m20 = matrix[2];
/*  716 */       this.m21 = matrix[6];
/*  717 */       this.m22 = matrix[10];
/*  718 */       this.m23 = matrix[14];
/*  719 */       this.m30 = matrix[3];
/*  720 */       this.m31 = matrix[7];
/*  721 */       this.m32 = matrix[11];
/*  722 */       this.m33 = matrix[15];
/*      */     }
/*      */   }
/*      */   
/*      */   public Matrix4f transpose() {
/*  727 */     float[] tmp = new float[16];
/*  728 */     get(tmp, true);
/*  729 */     Matrix4f mat = new Matrix4f(tmp);
/*  730 */     return mat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f transposeLocal()
/*      */   {
/*  739 */     float tmp = this.m01;
/*  740 */     this.m01 = this.m10;
/*  741 */     this.m10 = tmp;
/*      */     
/*  743 */     tmp = this.m02;
/*  744 */     this.m02 = this.m20;
/*  745 */     this.m20 = tmp;
/*      */     
/*  747 */     tmp = this.m03;
/*  748 */     this.m03 = this.m30;
/*  749 */     this.m30 = tmp;
/*      */     
/*  751 */     tmp = this.m12;
/*  752 */     this.m12 = this.m21;
/*  753 */     this.m21 = tmp;
/*      */     
/*  755 */     tmp = this.m13;
/*  756 */     this.m13 = this.m31;
/*  757 */     this.m31 = tmp;
/*      */     
/*  759 */     tmp = this.m23;
/*  760 */     this.m23 = this.m32;
/*  761 */     this.m32 = tmp;
/*      */     
/*  763 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillFloatArray(float[] f, boolean columnMajor)
/*      */   {
/*  807 */     if (columnMajor) {
/*  808 */       f[0] = this.m00;
/*  809 */       f[1] = this.m10;
/*  810 */       f[2] = this.m20;
/*  811 */       f[3] = this.m30;
/*  812 */       f[4] = this.m01;
/*  813 */       f[5] = this.m11;
/*  814 */       f[6] = this.m21;
/*  815 */       f[7] = this.m31;
/*  816 */       f[8] = this.m02;
/*  817 */       f[9] = this.m12;
/*  818 */       f[10] = this.m22;
/*  819 */       f[11] = this.m32;
/*  820 */       f[12] = this.m03;
/*  821 */       f[13] = this.m13;
/*  822 */       f[14] = this.m23;
/*  823 */       f[15] = this.m33;
/*      */     } else {
/*  825 */       f[0] = this.m00;
/*  826 */       f[1] = this.m01;
/*  827 */       f[2] = this.m02;
/*  828 */       f[3] = this.m03;
/*  829 */       f[4] = this.m10;
/*  830 */       f[5] = this.m11;
/*  831 */       f[6] = this.m12;
/*  832 */       f[7] = this.m13;
/*  833 */       f[8] = this.m20;
/*  834 */       f[9] = this.m21;
/*  835 */       f[10] = this.m22;
/*  836 */       f[11] = this.m23;
/*  837 */       f[12] = this.m30;
/*  838 */       f[13] = this.m31;
/*  839 */       f[14] = this.m32;
/*  840 */       f[15] = this.m33;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f readFloatBuffer(FloatBuffer fb)
/*      */   {
/*  850 */     return readFloatBuffer(fb, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f readFloatBuffer(FloatBuffer fb, boolean columnMajor)
/*      */   {
/*  862 */     if (columnMajor) {
/*  863 */       this.m00 = fb.get();
/*  864 */       this.m10 = fb.get();
/*  865 */       this.m20 = fb.get();
/*  866 */       this.m30 = fb.get();
/*  867 */       this.m01 = fb.get();
/*  868 */       this.m11 = fb.get();
/*  869 */       this.m21 = fb.get();
/*  870 */       this.m31 = fb.get();
/*  871 */       this.m02 = fb.get();
/*  872 */       this.m12 = fb.get();
/*  873 */       this.m22 = fb.get();
/*  874 */       this.m32 = fb.get();
/*  875 */       this.m03 = fb.get();
/*  876 */       this.m13 = fb.get();
/*  877 */       this.m23 = fb.get();
/*  878 */       this.m33 = fb.get();
/*      */     } else {
/*  880 */       this.m00 = fb.get();
/*  881 */       this.m01 = fb.get();
/*  882 */       this.m02 = fb.get();
/*  883 */       this.m03 = fb.get();
/*  884 */       this.m10 = fb.get();
/*  885 */       this.m11 = fb.get();
/*  886 */       this.m12 = fb.get();
/*  887 */       this.m13 = fb.get();
/*  888 */       this.m20 = fb.get();
/*  889 */       this.m21 = fb.get();
/*  890 */       this.m22 = fb.get();
/*  891 */       this.m23 = fb.get();
/*  892 */       this.m30 = fb.get();
/*  893 */       this.m31 = fb.get();
/*  894 */       this.m32 = fb.get();
/*  895 */       this.m33 = fb.get();
/*      */     }
/*  897 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadIdentity()
/*      */   {
/*  906 */     this.m01 = (this.m02 = this.m03 = 0.0F);
/*  907 */     this.m10 = (this.m12 = this.m13 = 0.0F);
/*  908 */     this.m20 = (this.m21 = this.m23 = 0.0F);
/*  909 */     this.m30 = (this.m31 = this.m32 = 0.0F);
/*  910 */     this.m00 = (this.m11 = this.m22 = this.m33 = 1.0F);
/*      */   }
/*      */   
/*      */   public void fromFrustum(float near, float far, float left, float right, float top, float bottom, boolean parallel) {
/*  914 */     loadIdentity();
/*  915 */     if (parallel)
/*      */     {
/*  917 */       this.m00 = (2.0F / (right - left));
/*      */       
/*  919 */       this.m11 = (2.0F / (top - bottom));
/*  920 */       this.m22 = (-2.0F / (far - near));
/*  921 */       this.m33 = 1.0F;
/*      */       
/*      */ 
/*  924 */       this.m03 = (-(right + left) / (right - left));
/*      */       
/*  926 */       this.m13 = (-(top + bottom) / (top - bottom));
/*  927 */       this.m23 = (-(far + near) / (far - near));
/*      */     } else {
/*  929 */       this.m00 = (2.0F * near / (right - left));
/*  930 */       this.m11 = (2.0F * near / (top - bottom));
/*  931 */       this.m32 = -1.0F;
/*  932 */       this.m33 = -0.0F;
/*      */       
/*      */ 
/*  935 */       this.m02 = ((right + left) / (right - left));
/*      */       
/*      */ 
/*  938 */       this.m12 = ((top + bottom) / (top - bottom));
/*      */       
/*      */ 
/*  941 */       this.m22 = (-(far + near) / (far - near));
/*      */       
/*      */ 
/*  944 */       this.m23 = (-(2.0F * far * near) / (far - near));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromAngleAxis(float angle, Vector3f axis)
/*      */   {
/*  959 */     Vector3f normAxis = axis.normalize();
/*  960 */     fromAngleNormalAxis(angle, normAxis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fromAngleNormalAxis(float angle, Vector3f axis)
/*      */   {
/*  973 */     zero();
/*  974 */     this.m33 = 1.0F;
/*      */     
/*  976 */     float fCos = FastMath.cos(angle);
/*  977 */     float fSin = FastMath.sin(angle);
/*  978 */     float fOneMinusCos = 1.0F - fCos;
/*  979 */     float fX2 = axis.x * axis.x;
/*  980 */     float fY2 = axis.y * axis.y;
/*  981 */     float fZ2 = axis.z * axis.z;
/*  982 */     float fXYM = axis.x * axis.y * fOneMinusCos;
/*  983 */     float fXZM = axis.x * axis.z * fOneMinusCos;
/*  984 */     float fYZM = axis.y * axis.z * fOneMinusCos;
/*  985 */     float fXSin = axis.x * fSin;
/*  986 */     float fYSin = axis.y * fSin;
/*  987 */     float fZSin = axis.z * fSin;
/*      */     
/*  989 */     this.m00 = (fX2 * fOneMinusCos + fCos);
/*  990 */     this.m01 = (fXYM - fZSin);
/*  991 */     this.m02 = (fXZM + fYSin);
/*  992 */     this.m10 = (fXYM + fZSin);
/*  993 */     this.m11 = (fY2 * fOneMinusCos + fCos);
/*  994 */     this.m12 = (fYZM - fXSin);
/*  995 */     this.m20 = (fXZM - fYSin);
/*  996 */     this.m21 = (fYZM + fXSin);
/*  997 */     this.m22 = (fZ2 * fOneMinusCos + fCos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void multLocal(float scalar)
/*      */   {
/* 1007 */     this.m00 *= scalar;
/* 1008 */     this.m01 *= scalar;
/* 1009 */     this.m02 *= scalar;
/* 1010 */     this.m03 *= scalar;
/* 1011 */     this.m10 *= scalar;
/* 1012 */     this.m11 *= scalar;
/* 1013 */     this.m12 *= scalar;
/* 1014 */     this.m13 *= scalar;
/* 1015 */     this.m20 *= scalar;
/* 1016 */     this.m21 *= scalar;
/* 1017 */     this.m22 *= scalar;
/* 1018 */     this.m23 *= scalar;
/* 1019 */     this.m30 *= scalar;
/* 1020 */     this.m31 *= scalar;
/* 1021 */     this.m32 *= scalar;
/* 1022 */     this.m33 *= scalar;
/*      */   }
/*      */   
/*      */   public Matrix4f mult(float scalar) {
/* 1026 */     Matrix4f out = new Matrix4f();
/* 1027 */     out.set(this);
/* 1028 */     out.multLocal(scalar);
/* 1029 */     return out;
/*      */   }
/*      */   
/*      */   public Matrix4f mult(float scalar, Matrix4f store) {
/* 1033 */     store.set(this);
/* 1034 */     store.multLocal(scalar);
/* 1035 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f mult(Matrix4f in2)
/*      */   {
/* 1048 */     return mult(in2, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f mult(Matrix4f in2, Matrix4f store)
/*      */   {
/* 1064 */     if (store == null) {
/* 1065 */       store = new Matrix4f();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1073 */     float temp00 = this.m00 * in2.m00 + 
/* 1074 */       this.m01 * in2.m10 + 
/* 1075 */       this.m02 * in2.m20 + 
/* 1076 */       this.m03 * in2.m30;
/* 1077 */     float temp01 = this.m00 * in2.m01 + 
/* 1078 */       this.m01 * in2.m11 + 
/* 1079 */       this.m02 * in2.m21 + 
/* 1080 */       this.m03 * in2.m31;
/* 1081 */     float temp02 = this.m00 * in2.m02 + 
/* 1082 */       this.m01 * in2.m12 + 
/* 1083 */       this.m02 * in2.m22 + 
/* 1084 */       this.m03 * in2.m32;
/* 1085 */     float temp03 = this.m00 * in2.m03 + 
/* 1086 */       this.m01 * in2.m13 + 
/* 1087 */       this.m02 * in2.m23 + 
/* 1088 */       this.m03 * in2.m33;
/*      */     
/* 1090 */     float temp10 = this.m10 * in2.m00 + 
/* 1091 */       this.m11 * in2.m10 + 
/* 1092 */       this.m12 * in2.m20 + 
/* 1093 */       this.m13 * in2.m30;
/* 1094 */     float temp11 = this.m10 * in2.m01 + 
/* 1095 */       this.m11 * in2.m11 + 
/* 1096 */       this.m12 * in2.m21 + 
/* 1097 */       this.m13 * in2.m31;
/* 1098 */     float temp12 = this.m10 * in2.m02 + 
/* 1099 */       this.m11 * in2.m12 + 
/* 1100 */       this.m12 * in2.m22 + 
/* 1101 */       this.m13 * in2.m32;
/* 1102 */     float temp13 = this.m10 * in2.m03 + 
/* 1103 */       this.m11 * in2.m13 + 
/* 1104 */       this.m12 * in2.m23 + 
/* 1105 */       this.m13 * in2.m33;
/*      */     
/* 1107 */     float temp20 = this.m20 * in2.m00 + 
/* 1108 */       this.m21 * in2.m10 + 
/* 1109 */       this.m22 * in2.m20 + 
/* 1110 */       this.m23 * in2.m30;
/* 1111 */     float temp21 = this.m20 * in2.m01 + 
/* 1112 */       this.m21 * in2.m11 + 
/* 1113 */       this.m22 * in2.m21 + 
/* 1114 */       this.m23 * in2.m31;
/* 1115 */     float temp22 = this.m20 * in2.m02 + 
/* 1116 */       this.m21 * in2.m12 + 
/* 1117 */       this.m22 * in2.m22 + 
/* 1118 */       this.m23 * in2.m32;
/* 1119 */     float temp23 = this.m20 * in2.m03 + 
/* 1120 */       this.m21 * in2.m13 + 
/* 1121 */       this.m22 * in2.m23 + 
/* 1122 */       this.m23 * in2.m33;
/*      */     
/* 1124 */     float temp30 = this.m30 * in2.m00 + 
/* 1125 */       this.m31 * in2.m10 + 
/* 1126 */       this.m32 * in2.m20 + 
/* 1127 */       this.m33 * in2.m30;
/* 1128 */     float temp31 = this.m30 * in2.m01 + 
/* 1129 */       this.m31 * in2.m11 + 
/* 1130 */       this.m32 * in2.m21 + 
/* 1131 */       this.m33 * in2.m31;
/* 1132 */     float temp32 = this.m30 * in2.m02 + 
/* 1133 */       this.m31 * in2.m12 + 
/* 1134 */       this.m32 * in2.m22 + 
/* 1135 */       this.m33 * in2.m32;
/* 1136 */     float temp33 = this.m30 * in2.m03 + 
/* 1137 */       this.m31 * in2.m13 + 
/* 1138 */       this.m32 * in2.m23 + 
/* 1139 */       this.m33 * in2.m33;
/*      */     
/* 1141 */     store.m00 = temp00;
/* 1142 */     store.m01 = temp01;
/* 1143 */     store.m02 = temp02;
/* 1144 */     store.m03 = temp03;
/* 1145 */     store.m10 = temp10;
/* 1146 */     store.m11 = temp11;
/* 1147 */     store.m12 = temp12;
/* 1148 */     store.m13 = temp13;
/* 1149 */     store.m20 = temp20;
/* 1150 */     store.m21 = temp21;
/* 1151 */     store.m22 = temp22;
/* 1152 */     store.m23 = temp23;
/* 1153 */     store.m30 = temp30;
/* 1154 */     store.m31 = temp31;
/* 1155 */     store.m32 = temp32;
/* 1156 */     store.m33 = temp33;
/*      */     
/* 1158 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f multLocal(Matrix4f in2)
/*      */   {
/* 1172 */     return mult(in2, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec)
/*      */   {
/* 1184 */     return mult(vec, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f mult(Vector3f vec, Vector3f store)
/*      */   {
/* 1198 */     if (store == null) {
/* 1199 */       store = new Vector3f();
/*      */     }
/*      */     
/* 1202 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/* 1203 */     store.x = (this.m00 * vx + this.m01 * vy + this.m02 * vz + this.m03);
/* 1204 */     store.y = (this.m10 * vx + this.m11 * vy + this.m12 * vz + this.m13);
/* 1205 */     store.z = (this.m20 * vx + this.m21 * vy + this.m22 * vz + this.m23);
/*      */     
/* 1207 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector4f mult(Vector4f vec)
/*      */   {
/* 1219 */     return mult(vec, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector4f mult(Vector4f vec, Vector4f store)
/*      */   {
/* 1233 */     if (vec == null) {
/* 1234 */       logger.warning("Source vector is null, null result returned.");
/* 1235 */       return null;
/*      */     }
/* 1237 */     if (store == null) {
/* 1238 */       store = new Vector4f();
/*      */     }
/*      */     
/* 1241 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;float vw = vec.w;
/* 1242 */     store.x = (this.m00 * vx + this.m01 * vy + this.m02 * vz + this.m03 * vw);
/* 1243 */     store.y = (this.m10 * vx + this.m11 * vy + this.m12 * vz + this.m13 * vw);
/* 1244 */     store.z = (this.m20 * vx + this.m21 * vy + this.m22 * vz + this.m23 * vw);
/* 1245 */     store.w = (this.m30 * vx + this.m31 * vy + this.m32 * vz + this.m33 * vw);
/*      */     
/* 1247 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector4f multAcross(Vector4f vec)
/*      */   {
/* 1260 */     return multAcross(vec, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector4f multAcross(Vector4f vec, Vector4f store)
/*      */   {
/* 1274 */     if (vec == null) {
/* 1275 */       logger.warning("Source vector is null, null result returned.");
/* 1276 */       return null;
/*      */     }
/* 1278 */     if (store == null) {
/* 1279 */       store = new Vector4f();
/*      */     }
/*      */     
/* 1282 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;float vw = vec.w;
/* 1283 */     store.x = (this.m00 * vx + this.m10 * vy + this.m20 * vz + this.m30 * vw);
/* 1284 */     store.y = (this.m01 * vx + this.m11 * vy + this.m21 * vz + this.m31 * vw);
/* 1285 */     store.z = (this.m02 * vx + this.m12 * vy + this.m22 * vz + this.m32 * vw);
/* 1286 */     store.z = (this.m03 * vx + this.m13 * vy + this.m23 * vz + this.m33 * vw);
/*      */     
/* 1288 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multNormal(Vector3f vec, Vector3f store)
/*      */   {
/* 1302 */     if (store == null) {
/* 1303 */       store = new Vector3f();
/*      */     }
/*      */     
/* 1306 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/* 1307 */     store.x = (this.m00 * vx + this.m01 * vy + this.m02 * vz);
/* 1308 */     store.y = (this.m10 * vx + this.m11 * vy + this.m12 * vz);
/* 1309 */     store.z = (this.m20 * vx + this.m21 * vy + this.m22 * vz);
/*      */     
/* 1311 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multNormalAcross(Vector3f vec, Vector3f store)
/*      */   {
/* 1325 */     if (store == null) {
/* 1326 */       store = new Vector3f();
/*      */     }
/*      */     
/* 1329 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/* 1330 */     store.x = (this.m00 * vx + this.m10 * vy + this.m20 * vz);
/* 1331 */     store.y = (this.m01 * vx + this.m11 * vy + this.m21 * vz);
/* 1332 */     store.z = (this.m02 * vx + this.m12 * vy + this.m22 * vz);
/*      */     
/* 1334 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float multProj(Vector3f vec, Vector3f store)
/*      */   {
/* 1349 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/* 1350 */     store.x = (this.m00 * vx + this.m01 * vy + this.m02 * vz + this.m03);
/* 1351 */     store.y = (this.m10 * vx + this.m11 * vy + this.m12 * vz + this.m13);
/* 1352 */     store.z = (this.m20 * vx + this.m21 * vy + this.m22 * vz + this.m23);
/* 1353 */     return this.m30 * vx + this.m31 * vy + this.m32 * vz + this.m33;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Vector3f multAcross(Vector3f vec, Vector3f store)
/*      */   {
/* 1367 */     if (vec == null) {
/* 1368 */       logger.warning("Source vector is null, null result returned.");
/* 1369 */       return null;
/*      */     }
/* 1371 */     if (store == null) {
/* 1372 */       store = new Vector3f();
/*      */     }
/*      */     
/* 1375 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/* 1376 */     store.x = (this.m00 * vx + this.m10 * vy + this.m20 * vz + this.m30 * 1.0F);
/* 1377 */     store.y = (this.m01 * vx + this.m11 * vy + this.m21 * vz + this.m31 * 1.0F);
/* 1378 */     store.z = (this.m02 * vx + this.m12 * vy + this.m22 * vz + this.m32 * 1.0F);
/*      */     
/* 1380 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Quaternion mult(Quaternion vec, Quaternion store)
/*      */   {
/* 1395 */     if (vec == null) {
/* 1396 */       logger.warning("Source vector is null, null result returned.");
/* 1397 */       return null;
/*      */     }
/* 1399 */     if (store == null) {
/* 1400 */       store = new Quaternion();
/*      */     }
/*      */     
/* 1403 */     float x = this.m00 * vec.x + this.m10 * vec.y + this.m20 * vec.z + this.m30 * vec.w;
/* 1404 */     float y = this.m01 * vec.x + this.m11 * vec.y + this.m21 * vec.z + this.m31 * vec.w;
/* 1405 */     float z = this.m02 * vec.x + this.m12 * vec.y + this.m22 * vec.z + this.m32 * vec.w;
/* 1406 */     float w = this.m03 * vec.x + this.m13 * vec.y + this.m23 * vec.z + this.m33 * vec.w;
/* 1407 */     store.x = x;
/* 1408 */     store.y = y;
/* 1409 */     store.z = z;
/* 1410 */     store.w = w;
/*      */     
/* 1412 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] mult(float[] vec4f)
/*      */   {
/* 1424 */     if ((vec4f == null) || (vec4f.length != 4)) {
/* 1425 */       logger.warning("invalid array given, must be nonnull and length 4");
/* 1426 */       return null;
/*      */     }
/*      */     
/* 1429 */     float x = vec4f[0];float y = vec4f[1];float z = vec4f[2];float w = vec4f[3];
/*      */     
/* 1431 */     vec4f[0] = (this.m00 * x + this.m01 * y + this.m02 * z + this.m03 * w);
/* 1432 */     vec4f[1] = (this.m10 * x + this.m11 * y + this.m12 * z + this.m13 * w);
/* 1433 */     vec4f[2] = (this.m20 * x + this.m21 * y + this.m22 * z + this.m23 * w);
/* 1434 */     vec4f[3] = (this.m30 * x + this.m31 * y + this.m32 * z + this.m33 * w);
/*      */     
/* 1436 */     return vec4f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] multAcross(float[] vec4f)
/*      */   {
/* 1448 */     if ((vec4f == null) || (vec4f.length != 4)) {
/* 1449 */       logger.warning("invalid array given, must be nonnull and length 4");
/* 1450 */       return null;
/*      */     }
/*      */     
/* 1453 */     float x = vec4f[0];float y = vec4f[1];float z = vec4f[2];float w = vec4f[3];
/*      */     
/* 1455 */     vec4f[0] = (this.m00 * x + this.m10 * y + this.m20 * z + this.m30 * w);
/* 1456 */     vec4f[1] = (this.m01 * x + this.m11 * y + this.m21 * z + this.m31 * w);
/* 1457 */     vec4f[2] = (this.m02 * x + this.m12 * y + this.m22 * z + this.m32 * w);
/* 1458 */     vec4f[3] = (this.m03 * x + this.m13 * y + this.m23 * z + this.m33 * w);
/*      */     
/* 1460 */     return vec4f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f invert()
/*      */   {
/* 1469 */     return invert(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f invert(Matrix4f store)
/*      */   {
/* 1478 */     if (store == null) {
/* 1479 */       store = new Matrix4f();
/*      */     }
/*      */     
/* 1482 */     float fA0 = this.m00 * this.m11 - this.m01 * this.m10;
/* 1483 */     float fA1 = this.m00 * this.m12 - this.m02 * this.m10;
/* 1484 */     float fA2 = this.m00 * this.m13 - this.m03 * this.m10;
/* 1485 */     float fA3 = this.m01 * this.m12 - this.m02 * this.m11;
/* 1486 */     float fA4 = this.m01 * this.m13 - this.m03 * this.m11;
/* 1487 */     float fA5 = this.m02 * this.m13 - this.m03 * this.m12;
/* 1488 */     float fB0 = this.m20 * this.m31 - this.m21 * this.m30;
/* 1489 */     float fB1 = this.m20 * this.m32 - this.m22 * this.m30;
/* 1490 */     float fB2 = this.m20 * this.m33 - this.m23 * this.m30;
/* 1491 */     float fB3 = this.m21 * this.m32 - this.m22 * this.m31;
/* 1492 */     float fB4 = this.m21 * this.m33 - this.m23 * this.m31;
/* 1493 */     float fB5 = this.m22 * this.m33 - this.m23 * this.m32;
/* 1494 */     float fDet = fA0 * fB5 - fA1 * fB4 + fA2 * fB3 + fA3 * fB2 - fA4 * fB1 + fA5 * fB0;
/*      */     
/* 1496 */     if (FastMath.abs(fDet) <= 0.0F) {
/* 1497 */       throw new ArithmeticException("This matrix cannot be inverted");
/*      */     }
/*      */     
/* 1500 */     store.m00 = (this.m11 * fB5 - this.m12 * fB4 + this.m13 * fB3);
/* 1501 */     store.m10 = (-this.m10 * fB5 + this.m12 * fB2 - this.m13 * fB1);
/* 1502 */     store.m20 = (this.m10 * fB4 - this.m11 * fB2 + this.m13 * fB0);
/* 1503 */     store.m30 = (-this.m10 * fB3 + this.m11 * fB1 - this.m12 * fB0);
/* 1504 */     store.m01 = (-this.m01 * fB5 + this.m02 * fB4 - this.m03 * fB3);
/* 1505 */     store.m11 = (this.m00 * fB5 - this.m02 * fB2 + this.m03 * fB1);
/* 1506 */     store.m21 = (-this.m00 * fB4 + this.m01 * fB2 - this.m03 * fB0);
/* 1507 */     store.m31 = (this.m00 * fB3 - this.m01 * fB1 + this.m02 * fB0);
/* 1508 */     store.m02 = (this.m31 * fA5 - this.m32 * fA4 + this.m33 * fA3);
/* 1509 */     store.m12 = (-this.m30 * fA5 + this.m32 * fA2 - this.m33 * fA1);
/* 1510 */     store.m22 = (this.m30 * fA4 - this.m31 * fA2 + this.m33 * fA0);
/* 1511 */     store.m32 = (-this.m30 * fA3 + this.m31 * fA1 - this.m32 * fA0);
/* 1512 */     store.m03 = (-this.m21 * fA5 + this.m22 * fA4 - this.m23 * fA3);
/* 1513 */     store.m13 = (this.m20 * fA5 - this.m22 * fA2 + this.m23 * fA1);
/* 1514 */     store.m23 = (-this.m20 * fA4 + this.m21 * fA2 - this.m23 * fA0);
/* 1515 */     store.m33 = (this.m20 * fA3 - this.m21 * fA1 + this.m22 * fA0);
/*      */     
/* 1517 */     float fInvDet = 1.0F / fDet;
/* 1518 */     store.multLocal(fInvDet);
/*      */     
/* 1520 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f invertLocal()
/*      */   {
/* 1530 */     float fA0 = this.m00 * this.m11 - this.m01 * this.m10;
/* 1531 */     float fA1 = this.m00 * this.m12 - this.m02 * this.m10;
/* 1532 */     float fA2 = this.m00 * this.m13 - this.m03 * this.m10;
/* 1533 */     float fA3 = this.m01 * this.m12 - this.m02 * this.m11;
/* 1534 */     float fA4 = this.m01 * this.m13 - this.m03 * this.m11;
/* 1535 */     float fA5 = this.m02 * this.m13 - this.m03 * this.m12;
/* 1536 */     float fB0 = this.m20 * this.m31 - this.m21 * this.m30;
/* 1537 */     float fB1 = this.m20 * this.m32 - this.m22 * this.m30;
/* 1538 */     float fB2 = this.m20 * this.m33 - this.m23 * this.m30;
/* 1539 */     float fB3 = this.m21 * this.m32 - this.m22 * this.m31;
/* 1540 */     float fB4 = this.m21 * this.m33 - this.m23 * this.m31;
/* 1541 */     float fB5 = this.m22 * this.m33 - this.m23 * this.m32;
/* 1542 */     float fDet = fA0 * fB5 - fA1 * fB4 + fA2 * fB3 + fA3 * fB2 - fA4 * fB1 + fA5 * fB0;
/*      */     
/* 1544 */     if (FastMath.abs(fDet) <= 0.0F) {
/* 1545 */       return zero();
/*      */     }
/*      */     
/* 1548 */     float f00 = this.m11 * fB5 - this.m12 * fB4 + this.m13 * fB3;
/* 1549 */     float f10 = -this.m10 * fB5 + this.m12 * fB2 - this.m13 * fB1;
/* 1550 */     float f20 = this.m10 * fB4 - this.m11 * fB2 + this.m13 * fB0;
/* 1551 */     float f30 = -this.m10 * fB3 + this.m11 * fB1 - this.m12 * fB0;
/* 1552 */     float f01 = -this.m01 * fB5 + this.m02 * fB4 - this.m03 * fB3;
/* 1553 */     float f11 = this.m00 * fB5 - this.m02 * fB2 + this.m03 * fB1;
/* 1554 */     float f21 = -this.m00 * fB4 + this.m01 * fB2 - this.m03 * fB0;
/* 1555 */     float f31 = this.m00 * fB3 - this.m01 * fB1 + this.m02 * fB0;
/* 1556 */     float f02 = this.m31 * fA5 - this.m32 * fA4 + this.m33 * fA3;
/* 1557 */     float f12 = -this.m30 * fA5 + this.m32 * fA2 - this.m33 * fA1;
/* 1558 */     float f22 = this.m30 * fA4 - this.m31 * fA2 + this.m33 * fA0;
/* 1559 */     float f32 = -this.m30 * fA3 + this.m31 * fA1 - this.m32 * fA0;
/* 1560 */     float f03 = -this.m21 * fA5 + this.m22 * fA4 - this.m23 * fA3;
/* 1561 */     float f13 = this.m20 * fA5 - this.m22 * fA2 + this.m23 * fA1;
/* 1562 */     float f23 = -this.m20 * fA4 + this.m21 * fA2 - this.m23 * fA0;
/* 1563 */     float f33 = this.m20 * fA3 - this.m21 * fA1 + this.m22 * fA0;
/*      */     
/* 1565 */     this.m00 = f00;
/* 1566 */     this.m01 = f01;
/* 1567 */     this.m02 = f02;
/* 1568 */     this.m03 = f03;
/* 1569 */     this.m10 = f10;
/* 1570 */     this.m11 = f11;
/* 1571 */     this.m12 = f12;
/* 1572 */     this.m13 = f13;
/* 1573 */     this.m20 = f20;
/* 1574 */     this.m21 = f21;
/* 1575 */     this.m22 = f22;
/* 1576 */     this.m23 = f23;
/* 1577 */     this.m30 = f30;
/* 1578 */     this.m31 = f31;
/* 1579 */     this.m32 = f32;
/* 1580 */     this.m33 = f33;
/*      */     
/* 1582 */     float fInvDet = 1.0F / fDet;
/* 1583 */     multLocal(fInvDet);
/*      */     
/* 1585 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f adjoint()
/*      */   {
/* 1594 */     return adjoint(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransform(Vector3f position, Vector3f scale, Matrix3f rotMat)
/*      */   {
/* 1604 */     this.m00 = (scale.x * rotMat.m00);
/* 1605 */     this.m01 = (scale.y * rotMat.m01);
/* 1606 */     this.m02 = (scale.z * rotMat.m02);
/* 1607 */     this.m03 = position.x;
/* 1608 */     this.m10 = (scale.x * rotMat.m10);
/* 1609 */     this.m11 = (scale.y * rotMat.m11);
/* 1610 */     this.m12 = (scale.z * rotMat.m12);
/* 1611 */     this.m13 = position.y;
/* 1612 */     this.m20 = (scale.x * rotMat.m20);
/* 1613 */     this.m21 = (scale.y * rotMat.m21);
/* 1614 */     this.m22 = (scale.z * rotMat.m22);
/* 1615 */     this.m23 = position.z;
/*      */     
/*      */ 
/* 1618 */     this.m30 = 0.0F;
/* 1619 */     this.m31 = 0.0F;
/* 1620 */     this.m32 = 0.0F;
/* 1621 */     this.m33 = 1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f adjoint(Matrix4f store)
/*      */   {
/* 1632 */     if (store == null) {
/* 1633 */       store = new Matrix4f();
/*      */     }
/*      */     
/* 1636 */     float fA0 = this.m00 * this.m11 - this.m01 * this.m10;
/* 1637 */     float fA1 = this.m00 * this.m12 - this.m02 * this.m10;
/* 1638 */     float fA2 = this.m00 * this.m13 - this.m03 * this.m10;
/* 1639 */     float fA3 = this.m01 * this.m12 - this.m02 * this.m11;
/* 1640 */     float fA4 = this.m01 * this.m13 - this.m03 * this.m11;
/* 1641 */     float fA5 = this.m02 * this.m13 - this.m03 * this.m12;
/* 1642 */     float fB0 = this.m20 * this.m31 - this.m21 * this.m30;
/* 1643 */     float fB1 = this.m20 * this.m32 - this.m22 * this.m30;
/* 1644 */     float fB2 = this.m20 * this.m33 - this.m23 * this.m30;
/* 1645 */     float fB3 = this.m21 * this.m32 - this.m22 * this.m31;
/* 1646 */     float fB4 = this.m21 * this.m33 - this.m23 * this.m31;
/* 1647 */     float fB5 = this.m22 * this.m33 - this.m23 * this.m32;
/*      */     
/* 1649 */     store.m00 = (this.m11 * fB5 - this.m12 * fB4 + this.m13 * fB3);
/* 1650 */     store.m10 = (-this.m10 * fB5 + this.m12 * fB2 - this.m13 * fB1);
/* 1651 */     store.m20 = (this.m10 * fB4 - this.m11 * fB2 + this.m13 * fB0);
/* 1652 */     store.m30 = (-this.m10 * fB3 + this.m11 * fB1 - this.m12 * fB0);
/* 1653 */     store.m01 = (-this.m01 * fB5 + this.m02 * fB4 - this.m03 * fB3);
/* 1654 */     store.m11 = (this.m00 * fB5 - this.m02 * fB2 + this.m03 * fB1);
/* 1655 */     store.m21 = (-this.m00 * fB4 + this.m01 * fB2 - this.m03 * fB0);
/* 1656 */     store.m31 = (this.m00 * fB3 - this.m01 * fB1 + this.m02 * fB0);
/* 1657 */     store.m02 = (this.m31 * fA5 - this.m32 * fA4 + this.m33 * fA3);
/* 1658 */     store.m12 = (-this.m30 * fA5 + this.m32 * fA2 - this.m33 * fA1);
/* 1659 */     store.m22 = (this.m30 * fA4 - this.m31 * fA2 + this.m33 * fA0);
/* 1660 */     store.m32 = (-this.m30 * fA3 + this.m31 * fA1 - this.m32 * fA0);
/* 1661 */     store.m03 = (-this.m21 * fA5 + this.m22 * fA4 - this.m23 * fA3);
/* 1662 */     store.m13 = (this.m20 * fA5 - this.m22 * fA2 + this.m23 * fA1);
/* 1663 */     store.m23 = (-this.m20 * fA4 + this.m21 * fA2 - this.m23 * fA0);
/* 1664 */     store.m33 = (this.m20 * fA3 - this.m21 * fA1 + this.m22 * fA0);
/*      */     
/* 1666 */     return store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float determinant()
/*      */   {
/* 1675 */     float fA0 = this.m00 * this.m11 - this.m01 * this.m10;
/* 1676 */     float fA1 = this.m00 * this.m12 - this.m02 * this.m10;
/* 1677 */     float fA2 = this.m00 * this.m13 - this.m03 * this.m10;
/* 1678 */     float fA3 = this.m01 * this.m12 - this.m02 * this.m11;
/* 1679 */     float fA4 = this.m01 * this.m13 - this.m03 * this.m11;
/* 1680 */     float fA5 = this.m02 * this.m13 - this.m03 * this.m12;
/* 1681 */     float fB0 = this.m20 * this.m31 - this.m21 * this.m30;
/* 1682 */     float fB1 = this.m20 * this.m32 - this.m22 * this.m30;
/* 1683 */     float fB2 = this.m20 * this.m33 - this.m23 * this.m30;
/* 1684 */     float fB3 = this.m21 * this.m32 - this.m22 * this.m31;
/* 1685 */     float fB4 = this.m21 * this.m33 - this.m23 * this.m31;
/* 1686 */     float fB5 = this.m22 * this.m33 - this.m23 * this.m32;
/* 1687 */     float fDet = fA0 * fB5 - fA1 * fB4 + fA2 * fB3 + fA3 * fB2 - fA4 * fB1 + fA5 * fB0;
/* 1688 */     return fDet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Matrix4f zero()
/*      */   {
/* 1697 */     this.m00 = (this.m01 = this.m02 = this.m03 = 0.0F);
/* 1698 */     this.m10 = (this.m11 = this.m12 = this.m13 = 0.0F);
/* 1699 */     this.m20 = (this.m21 = this.m22 = this.m23 = 0.0F);
/* 1700 */     this.m30 = (this.m31 = this.m32 = this.m33 = 0.0F);
/* 1701 */     return this;
/*      */   }
/*      */   
/*      */   public Matrix4f add(Matrix4f mat) {
/* 1705 */     Matrix4f result = new Matrix4f();
/* 1706 */     this.m00 += mat.m00;
/* 1707 */     this.m01 += mat.m01;
/* 1708 */     this.m02 += mat.m02;
/* 1709 */     this.m03 += mat.m03;
/* 1710 */     this.m10 += mat.m10;
/* 1711 */     this.m11 += mat.m11;
/* 1712 */     this.m12 += mat.m12;
/* 1713 */     this.m13 += mat.m13;
/* 1714 */     this.m20 += mat.m20;
/* 1715 */     this.m21 += mat.m21;
/* 1716 */     this.m22 += mat.m22;
/* 1717 */     this.m23 += mat.m23;
/* 1718 */     this.m30 += mat.m30;
/* 1719 */     this.m31 += mat.m31;
/* 1720 */     this.m32 += mat.m32;
/* 1721 */     this.m33 += mat.m33;
/* 1722 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocal(Matrix4f mat)
/*      */   {
/* 1732 */     this.m00 += mat.m00;
/* 1733 */     this.m01 += mat.m01;
/* 1734 */     this.m02 += mat.m02;
/* 1735 */     this.m03 += mat.m03;
/* 1736 */     this.m10 += mat.m10;
/* 1737 */     this.m11 += mat.m11;
/* 1738 */     this.m12 += mat.m12;
/* 1739 */     this.m13 += mat.m13;
/* 1740 */     this.m20 += mat.m20;
/* 1741 */     this.m21 += mat.m21;
/* 1742 */     this.m22 += mat.m22;
/* 1743 */     this.m23 += mat.m23;
/* 1744 */     this.m30 += mat.m30;
/* 1745 */     this.m31 += mat.m31;
/* 1746 */     this.m32 += mat.m32;
/* 1747 */     this.m33 += mat.m33;
/*      */   }
/*      */   
/*      */   public Vector3f toTranslationVector() {
/* 1751 */     return new Vector3f(this.m03, this.m13, this.m23);
/*      */   }
/*      */   
/*      */   public void toTranslationVector(Vector3f vector) {
/* 1755 */     vector.set(this.m03, this.m13, this.m23);
/*      */   }
/*      */   
/*      */   public Quaternion toRotationQuat() {
/* 1759 */     Quaternion quat = new Quaternion();
/* 1760 */     quat.fromRotationMatrix(toRotationMatrix());
/* 1761 */     return quat;
/*      */   }
/*      */   
/*      */   public void toRotationQuat(Quaternion q) {
/* 1765 */     q.fromRotationMatrix(toRotationMatrix());
/*      */   }
/*      */   
/*      */   public Matrix3f toRotationMatrix() {
/* 1769 */     return new Matrix3f(this.m00, this.m01, this.m02, this.m10, this.m11, this.m12, this.m20, this.m21, this.m22);
/*      */   }
/*      */   
/*      */   public void toRotationMatrix(Matrix3f mat)
/*      */   {
/* 1774 */     mat.m00 = this.m00;
/* 1775 */     mat.m01 = this.m01;
/* 1776 */     mat.m02 = this.m02;
/* 1777 */     mat.m10 = this.m10;
/* 1778 */     mat.m11 = this.m11;
/* 1779 */     mat.m12 = this.m12;
/* 1780 */     mat.m20 = this.m20;
/* 1781 */     mat.m21 = this.m21;
/* 1782 */     mat.m22 = this.m22;
/*      */   }
/*      */   
/*      */   public void setScale(float x, float y, float z)
/*      */   {
/* 1787 */     this.m00 *= x;
/* 1788 */     this.m11 *= y;
/* 1789 */     this.m22 *= z;
/*      */   }
/*      */   
/*      */   public void setScale(Vector3f scale) {
/* 1793 */     this.m00 *= scale.x;
/* 1794 */     this.m11 *= scale.y;
/* 1795 */     this.m22 *= scale.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTranslation(float[] translation)
/*      */   {
/* 1807 */     if (translation.length != 3) {
/* 1808 */       throw new IllegalArgumentException(
/* 1809 */         "Translation size must be 3.");
/*      */     }
/* 1811 */     this.m03 = translation[0];
/* 1812 */     this.m13 = translation[1];
/* 1813 */     this.m23 = translation[2];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTranslation(float x, float y, float z)
/*      */   {
/* 1827 */     this.m03 = x;
/* 1828 */     this.m13 = y;
/* 1829 */     this.m23 = z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTranslation(Vector3f translation)
/*      */   {
/* 1839 */     this.m03 = translation.x;
/* 1840 */     this.m13 = translation.y;
/* 1841 */     this.m23 = translation.z;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInverseTranslation(float[] translation)
/*      */   {
/* 1854 */     if (translation.length != 3) {
/* 1855 */       throw new IllegalArgumentException(
/* 1856 */         "Translation size must be 3.");
/*      */     }
/* 1858 */     this.m03 = (-translation[0]);
/* 1859 */     this.m13 = (-translation[1]);
/* 1860 */     this.m23 = (-translation[2]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void angleRotation(Vector3f angles)
/*      */   {
/* 1876 */     float angle = angles.z * 0.017453292F;
/* 1877 */     float sy = FastMath.sin(angle);
/* 1878 */     float cy = FastMath.cos(angle);
/* 1879 */     angle = angles.y * 0.017453292F;
/* 1880 */     float sp = FastMath.sin(angle);
/* 1881 */     float cp = FastMath.cos(angle);
/* 1882 */     angle = angles.x * 0.017453292F;
/* 1883 */     float sr = FastMath.sin(angle);
/* 1884 */     float cr = FastMath.cos(angle);
/*      */     
/*      */ 
/* 1887 */     this.m00 = (cp * cy);
/* 1888 */     this.m10 = (cp * sy);
/* 1889 */     this.m20 = (-sp);
/* 1890 */     this.m01 = (sr * sp * cy + cr * -sy);
/* 1891 */     this.m11 = (sr * sp * sy + cr * cy);
/* 1892 */     this.m21 = (sr * cp);
/* 1893 */     this.m02 = (cr * sp * cy + -sr * -sy);
/* 1894 */     this.m12 = (cr * sp * sy + -sr * cy);
/* 1895 */     this.m22 = (cr * cp);
/* 1896 */     this.m03 = 0.0F;
/* 1897 */     this.m13 = 0.0F;
/* 1898 */     this.m23 = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRotationQuaternion(Quaternion quat)
/*      */   {
/* 1911 */     quat.toRotationMatrix(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInverseRotationRadians(float[] angles)
/*      */   {
/* 1924 */     if (angles.length != 3) {
/* 1925 */       throw new IllegalArgumentException(
/* 1926 */         "Angles must be of size 3.");
/*      */     }
/* 1928 */     double cr = FastMath.cos(angles[0]);
/* 1929 */     double sr = FastMath.sin(angles[0]);
/* 1930 */     double cp = FastMath.cos(angles[1]);
/* 1931 */     double sp = FastMath.sin(angles[1]);
/* 1932 */     double cy = FastMath.cos(angles[2]);
/* 1933 */     double sy = FastMath.sin(angles[2]);
/*      */     
/* 1935 */     this.m00 = ((float)(cp * cy));
/* 1936 */     this.m10 = ((float)(cp * sy));
/* 1937 */     this.m20 = ((float)-sp);
/*      */     
/* 1939 */     double srsp = sr * sp;
/* 1940 */     double crsp = cr * sp;
/*      */     
/* 1942 */     this.m01 = ((float)(srsp * cy - cr * sy));
/* 1943 */     this.m11 = ((float)(srsp * sy + cr * cy));
/* 1944 */     this.m21 = ((float)(sr * cp));
/*      */     
/* 1946 */     this.m02 = ((float)(crsp * cy + sr * sy));
/* 1947 */     this.m12 = ((float)(crsp * sy - sr * cy));
/* 1948 */     this.m22 = ((float)(cr * cp));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInverseRotationDegrees(float[] angles)
/*      */   {
/* 1961 */     if (angles.length != 3) {
/* 1962 */       throw new IllegalArgumentException(
/* 1963 */         "Angles must be of size 3.");
/*      */     }
/* 1965 */     float[] vec = new float[3];
/* 1966 */     angles[0] *= 57.295776F;
/* 1967 */     angles[1] *= 57.295776F;
/* 1968 */     angles[2] *= 57.295776F;
/* 1969 */     setInverseRotationRadians(vec);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void inverseTranslateVect(float[] vec)
/*      */   {
/* 1983 */     if (vec.length != 3) {
/* 1984 */       throw new IllegalArgumentException(
/* 1985 */         "vec must be of size 3.");
/*      */     }
/*      */     
/* 1988 */     vec[0] -= this.m03;
/* 1989 */     vec[1] -= this.m13;
/* 1990 */     vec[2] -= this.m23;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void inverseTranslateVect(Vector3f data)
/*      */   {
/* 2004 */     data.x -= this.m03;
/* 2005 */     data.y -= this.m13;
/* 2006 */     data.z -= this.m23;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void translateVect(Vector3f data)
/*      */   {
/* 2020 */     data.x += this.m03;
/* 2021 */     data.y += this.m13;
/* 2022 */     data.z += this.m23;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void inverseRotateVect(Vector3f vec)
/*      */   {
/* 2034 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/*      */     
/* 2036 */     vec.x = (vx * this.m00 + vy * this.m10 + vz * this.m20);
/* 2037 */     vec.y = (vx * this.m01 + vy * this.m11 + vz * this.m21);
/* 2038 */     vec.z = (vx * this.m02 + vy * this.m12 + vz * this.m22);
/*      */   }
/*      */   
/*      */   public void rotateVect(Vector3f vec) {
/* 2042 */     float vx = vec.x;float vy = vec.y;float vz = vec.z;
/*      */     
/* 2044 */     vec.x = (vx * this.m00 + vy * this.m01 + vz * this.m02);
/* 2045 */     vec.y = (vx * this.m10 + vy * this.m11 + vz * this.m12);
/* 2046 */     vec.z = (vx * this.m20 + vy * this.m21 + vz * this.m22);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2062 */     StringBuilder result = new StringBuilder("Matrix4f\n[\n");
/* 2063 */     result.append(" ");
/* 2064 */     result.append(this.m00);
/* 2065 */     result.append("  ");
/* 2066 */     result.append(this.m01);
/* 2067 */     result.append("  ");
/* 2068 */     result.append(this.m02);
/* 2069 */     result.append("  ");
/* 2070 */     result.append(this.m03);
/* 2071 */     result.append(" \n");
/* 2072 */     result.append(" ");
/* 2073 */     result.append(this.m10);
/* 2074 */     result.append("  ");
/* 2075 */     result.append(this.m11);
/* 2076 */     result.append("  ");
/* 2077 */     result.append(this.m12);
/* 2078 */     result.append("  ");
/* 2079 */     result.append(this.m13);
/* 2080 */     result.append(" \n");
/* 2081 */     result.append(" ");
/* 2082 */     result.append(this.m20);
/* 2083 */     result.append("  ");
/* 2084 */     result.append(this.m21);
/* 2085 */     result.append("  ");
/* 2086 */     result.append(this.m22);
/* 2087 */     result.append("  ");
/* 2088 */     result.append(this.m23);
/* 2089 */     result.append(" \n");
/* 2090 */     result.append(" ");
/* 2091 */     result.append(this.m30);
/* 2092 */     result.append("  ");
/* 2093 */     result.append(this.m31);
/* 2094 */     result.append("  ");
/* 2095 */     result.append(this.m32);
/* 2096 */     result.append("  ");
/* 2097 */     result.append(this.m33);
/* 2098 */     result.append(" \n]");
/* 2099 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 2113 */     int hash = 37;
/* 2114 */     hash = 37 * hash + Float.floatToIntBits(this.m00);
/* 2115 */     hash = 37 * hash + Float.floatToIntBits(this.m01);
/* 2116 */     hash = 37 * hash + Float.floatToIntBits(this.m02);
/* 2117 */     hash = 37 * hash + Float.floatToIntBits(this.m03);
/*      */     
/* 2119 */     hash = 37 * hash + Float.floatToIntBits(this.m10);
/* 2120 */     hash = 37 * hash + Float.floatToIntBits(this.m11);
/* 2121 */     hash = 37 * hash + Float.floatToIntBits(this.m12);
/* 2122 */     hash = 37 * hash + Float.floatToIntBits(this.m13);
/*      */     
/* 2124 */     hash = 37 * hash + Float.floatToIntBits(this.m20);
/* 2125 */     hash = 37 * hash + Float.floatToIntBits(this.m21);
/* 2126 */     hash = 37 * hash + Float.floatToIntBits(this.m22);
/* 2127 */     hash = 37 * hash + Float.floatToIntBits(this.m23);
/*      */     
/* 2129 */     hash = 37 * hash + Float.floatToIntBits(this.m30);
/* 2130 */     hash = 37 * hash + Float.floatToIntBits(this.m31);
/* 2131 */     hash = 37 * hash + Float.floatToIntBits(this.m32);
/* 2132 */     hash = 37 * hash + Float.floatToIntBits(this.m33);
/*      */     
/* 2134 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 2146 */     if ((!(o instanceof Matrix4f)) || (o == null)) {
/* 2147 */       return false;
/*      */     }
/*      */     
/* 2150 */     if (this == o) {
/* 2151 */       return true;
/*      */     }
/*      */     
/* 2154 */     Matrix4f comp = (Matrix4f)o;
/* 2155 */     if (Float.compare(this.m00, comp.m00) != 0) {
/* 2156 */       return false;
/*      */     }
/* 2158 */     if (Float.compare(this.m01, comp.m01) != 0) {
/* 2159 */       return false;
/*      */     }
/* 2161 */     if (Float.compare(this.m02, comp.m02) != 0) {
/* 2162 */       return false;
/*      */     }
/* 2164 */     if (Float.compare(this.m03, comp.m03) != 0) {
/* 2165 */       return false;
/*      */     }
/*      */     
/* 2168 */     if (Float.compare(this.m10, comp.m10) != 0) {
/* 2169 */       return false;
/*      */     }
/* 2171 */     if (Float.compare(this.m11, comp.m11) != 0) {
/* 2172 */       return false;
/*      */     }
/* 2174 */     if (Float.compare(this.m12, comp.m12) != 0) {
/* 2175 */       return false;
/*      */     }
/* 2177 */     if (Float.compare(this.m13, comp.m13) != 0) {
/* 2178 */       return false;
/*      */     }
/*      */     
/* 2181 */     if (Float.compare(this.m20, comp.m20) != 0) {
/* 2182 */       return false;
/*      */     }
/* 2184 */     if (Float.compare(this.m21, comp.m21) != 0) {
/* 2185 */       return false;
/*      */     }
/* 2187 */     if (Float.compare(this.m22, comp.m22) != 0) {
/* 2188 */       return false;
/*      */     }
/* 2190 */     if (Float.compare(this.m23, comp.m23) != 0) {
/* 2191 */       return false;
/*      */     }
/*      */     
/* 2194 */     if (Float.compare(this.m30, comp.m30) != 0) {
/* 2195 */       return false;
/*      */     }
/* 2197 */     if (Float.compare(this.m31, comp.m31) != 0) {
/* 2198 */       return false;
/*      */     }
/* 2200 */     if (Float.compare(this.m32, comp.m32) != 0) {
/* 2201 */       return false;
/*      */     }
/* 2203 */     if (Float.compare(this.m33, comp.m33) != 0) {
/* 2204 */       return false;
/*      */     }
/*      */     
/* 2207 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIdentity()
/*      */   {
/* 2216 */     return (this.m00 == 1.0F) && (this.m01 == 0.0F) && (this.m02 == 0.0F) && (this.m03 == 0.0F) && 
/* 2217 */       (this.m10 == 0.0F) && (this.m11 == 1.0F) && (this.m12 == 0.0F) && (this.m13 == 0.0F) && 
/* 2218 */       (this.m20 == 0.0F) && (this.m21 == 0.0F) && (this.m22 == 1.0F) && (this.m23 == 0.0F) && 
/* 2219 */       (this.m30 == 0.0F) && (this.m31 == 0.0F) && (this.m32 == 0.0F) && (this.m33 == 1.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void scale(Vector3f scale)
/*      */   {
/* 2229 */     this.m00 *= scale.getX();
/* 2230 */     this.m10 *= scale.getX();
/* 2231 */     this.m20 *= scale.getX();
/* 2232 */     this.m30 *= scale.getX();
/* 2233 */     this.m01 *= scale.getY();
/* 2234 */     this.m11 *= scale.getY();
/* 2235 */     this.m21 *= scale.getY();
/* 2236 */     this.m31 *= scale.getY();
/* 2237 */     this.m02 *= scale.getZ();
/* 2238 */     this.m12 *= scale.getZ();
/* 2239 */     this.m22 *= scale.getZ();
/* 2240 */     this.m32 *= scale.getZ();
/*      */   }
/*      */   
/*      */   static boolean equalIdentity(Matrix4f mat) {
/* 2244 */     if (Math.abs(mat.m00 - 1.0F) > 1.0E-4D) {
/* 2245 */       return false;
/*      */     }
/* 2247 */     if (Math.abs(mat.m11 - 1.0F) > 1.0E-4D) {
/* 2248 */       return false;
/*      */     }
/* 2250 */     if (Math.abs(mat.m22 - 1.0F) > 1.0E-4D) {
/* 2251 */       return false;
/*      */     }
/* 2253 */     if (Math.abs(mat.m33 - 1.0F) > 1.0E-4D) {
/* 2254 */       return false;
/*      */     }
/*      */     
/* 2257 */     if (Math.abs(mat.m01) > 1.0E-4D) {
/* 2258 */       return false;
/*      */     }
/* 2260 */     if (Math.abs(mat.m02) > 1.0E-4D) {
/* 2261 */       return false;
/*      */     }
/* 2263 */     if (Math.abs(mat.m03) > 1.0E-4D) {
/* 2264 */       return false;
/*      */     }
/*      */     
/* 2267 */     if (Math.abs(mat.m10) > 1.0E-4D) {
/* 2268 */       return false;
/*      */     }
/* 2270 */     if (Math.abs(mat.m12) > 1.0E-4D) {
/* 2271 */       return false;
/*      */     }
/* 2273 */     if (Math.abs(mat.m13) > 1.0E-4D) {
/* 2274 */       return false;
/*      */     }
/*      */     
/* 2277 */     if (Math.abs(mat.m20) > 1.0E-4D) {
/* 2278 */       return false;
/*      */     }
/* 2280 */     if (Math.abs(mat.m21) > 1.0E-4D) {
/* 2281 */       return false;
/*      */     }
/* 2283 */     if (Math.abs(mat.m23) > 1.0E-4D) {
/* 2284 */       return false;
/*      */     }
/*      */     
/* 2287 */     if (Math.abs(mat.m30) > 1.0E-4D) {
/* 2288 */       return false;
/*      */     }
/* 2290 */     if (Math.abs(mat.m31) > 1.0E-4D) {
/* 2291 */       return false;
/*      */     }
/* 2293 */     if (Math.abs(mat.m32) > 1.0E-4D) {
/* 2294 */       return false;
/*      */     }
/*      */     
/* 2297 */     return true;
/*      */   }
/*      */   
/*      */   public void multLocal(Quaternion rotation)
/*      */   {
/* 2302 */     Vector3f axis = new Vector3f();
/* 2303 */     float angle = rotation.toAngleAxis(axis);
/* 2304 */     Matrix4f matrix4f = new Matrix4f();
/* 2305 */     matrix4f.fromAngleAxis(angle, axis);
/* 2306 */     multLocal(matrix4f);
/*      */   }
/*      */   
/*      */   public Matrix4f clone()
/*      */   {
/*      */     try {
/* 2312 */       return (Matrix4f)super.clone();
/*      */     } catch (CloneNotSupportedException e) {
/* 2314 */       throw new AssertionError();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Jush\Documents\KudanSDK-Android\kudanar-android\kudanar.jar!\com\jme3\math\Matrix4f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */