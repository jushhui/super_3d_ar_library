﻿
package com.jme3.math;

import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import java.util.Random;

public final class FastMath {
    public static final double DBL_EPSILON = 2.220446049250313E-16D;
    public static final float FLT_EPSILON = 1.1920929E-7F;
    public static final float ZERO_TOLERANCE = 1.0E-4F;
    public static final float ONE_THIRD = 0.33333334F;
    public static final float PI = 3.1415927F;
    public static final float TWO_PI = 6.2831855F;
    public static final float HALF_PI = 1.5707964F;
    public static final float QUARTER_PI = 0.7853982F;
    public static final float INV_PI = 0.31830987F;
    public static final float INV_TWO_PI = 0.15915494F;
    public static final float DEG_TO_RAD = 0.017453292F;
    public static final float RAD_TO_DEG = 57.295776F;
    public static final Random rand = new Random(System.currentTimeMillis());

    private FastMath() {
    }

    public static boolean isPowerOfTwo(int number) {
        return number > 0 && (number & number - 1) == 0;
    }

    public static int nearestPowerOfTwo(int number) {
        return (int)Math.pow(2.0D, Math.ceil(Math.log((double)number) / Math.log(2.0D)));
    }

    public static float interpolateLinear(float scale, float startValue, float endValue) {
        return startValue == endValue?startValue:(scale <= 0.0F?startValue:(scale >= 1.0F?endValue:(1.0F - scale) * startValue + scale * endValue));
    }

    public static Vector3f interpolateLinear(float scale, Vector3f startValue, Vector3f endValue, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.x = interpolateLinear(scale, startValue.x, endValue.x);
        store.y = interpolateLinear(scale, startValue.y, endValue.y);
        store.z = interpolateLinear(scale, startValue.z, endValue.z);
        return store;
    }

    public static Vector3f interpolateLinear(float scale, Vector3f startValue, Vector3f endValue) {
        return interpolateLinear(scale, startValue, endValue, (Vector3f)null);
    }

    public static float extrapolateLinear(float scale, float startValue, float endValue) {
        return (1.0F - scale) * startValue + scale * endValue;
    }

    public static Vector3f extrapolateLinear(float scale, Vector3f startValue, Vector3f endValue, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.x = extrapolateLinear(scale, startValue.x, endValue.x);
        store.y = extrapolateLinear(scale, startValue.y, endValue.y);
        store.z = extrapolateLinear(scale, startValue.z, endValue.z);
        return store;
    }

    public static Vector3f extrapolateLinear(float scale, Vector3f startValue, Vector3f endValue) {
        return extrapolateLinear(scale, startValue, endValue, (Vector3f)null);
    }

    public static float interpolateCatmullRom(float u, float T, float p0, float p1, float p2, float p3) {
        float c2 = -1.0F * T * p0 + T * p2;
        float c3 = 2.0F * T * p0 + (T - 3.0F) * p1 + (3.0F - 2.0F * T) * p2 + -T * p3;
        float c4 = -T * p0 + (2.0F - T) * p1 + (T - 2.0F) * p2 + T * p3;
        return ((c4 * u + c3) * u + c2) * u + p1;
    }

    public static Vector3f interpolateCatmullRom(float u, float T, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.x = interpolateCatmullRom(u, T, p0.x, p1.x, p2.x, p3.x);
        store.y = interpolateCatmullRom(u, T, p0.y, p1.y, p2.y, p3.y);
        store.z = interpolateCatmullRom(u, T, p0.z, p1.z, p2.z, p3.z);
        return store;
    }

    public static Vector3f interpolateCatmullRom(float u, float T, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3) {
        return interpolateCatmullRom(u, T, p0, p1, p2, p3, (Vector3f)null);
    }

    public static float interpolateBezier(float u, float p0, float p1, float p2, float p3) {
        float oneMinusU = 1.0F - u;
        float oneMinusU2 = oneMinusU * oneMinusU;
        float u2 = u * u;
        return p0 * oneMinusU2 * oneMinusU + 3.0F * p1 * u * oneMinusU2 + 3.0F * p2 * u2 * oneMinusU + p3 * u2 * u;
    }

    public static Vector3f interpolateBezier(float u, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.x = interpolateBezier(u, p0.x, p1.x, p2.x, p3.x);
        store.y = interpolateBezier(u, p0.y, p1.y, p2.y, p3.y);
        store.z = interpolateBezier(u, p0.z, p1.z, p2.z, p3.z);
        return store;
    }

    public static Vector3f interpolateBezier(float u, Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3) {
        return interpolateBezier(u, p0, p1, p2, p3, (Vector3f)null);
    }

    public static float getCatmullRomP1toP2Length(Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3, float startRange, float endRange, float curveTension) {
        float epsilon = 0.001F;
        float middleValue = (startRange + endRange) * 0.5F;
        Vector3f start = p1.clone();
        if(startRange != 0.0F) {
            interpolateCatmullRom(startRange, curveTension, p0, p1, p2, p3, start);
        }

        Vector3f end = p2.clone();
        if(endRange != 1.0F) {
            interpolateCatmullRom(endRange, curveTension, p0, p1, p2, p3, end);
        }

        Vector3f middle = interpolateCatmullRom(middleValue, curveTension, p0, p1, p2, p3);
        float l = end.subtract(start).length();
        float l1 = middle.subtract(start).length();
        float l2 = end.subtract(middle).length();
        float len = l1 + l2;
        if(l + epsilon < len) {
            l1 = getCatmullRomP1toP2Length(p0, p1, p2, p3, startRange, middleValue, curveTension);
            l2 = getCatmullRomP1toP2Length(p0, p1, p2, p3, middleValue, endRange, curveTension);
        }

        l = l1 + l2;
        return l;
    }

    public static float getBezierP1toP2Length(Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3) {
        float delta = 0.02F;
        float t = 0.0F;
        float result = 0.0F;
        Vector3f v1 = p0.clone();

        for(Vector3f v2 = new Vector3f(); t <= 1.0F; t += delta) {
            interpolateBezier(t, p0, p1, p2, p3, v2);
            result += v1.subtractLocal(v2).length();
            v1.set(v2);
        }

        return result;
    }

    public static float acos(float fValue) {
        return -1.0F < fValue?(fValue < 1.0F?(float)Math.acos((double)fValue):0.0F):3.1415927F;
    }

    public static float asin(float fValue) {
        return -1.0F < fValue?(fValue < 1.0F?(float)Math.asin((double)fValue):1.5707964F):-1.5707964F;
    }

    public static float atan(float fValue) {
        return (float)Math.atan((double)fValue);
    }

    public static float atan2(float fY, float fX) {
        return (float)Math.atan2((double)fY, (double)fX);
    }

    public static float ceil(float fValue) {
        return (float)Math.ceil((double)fValue);
    }

    public static float cos(float v) {
        return (float)Math.cos((double)v);
    }

    public static float sin(float v) {
        return (float)Math.sin((double)v);
    }

    public static float exp(float fValue) {
        return (float)Math.exp((double)fValue);
    }

    public static float abs(float fValue) {
        return fValue < 0.0F?-fValue:fValue;
    }

    public static float floor(float fValue) {
        return (float)Math.floor((double)fValue);
    }

    public static float invSqrt(float fValue) {
        return (float)(1.0D / Math.sqrt((double)fValue));
    }

    public static float fastInvSqrt(float x) {
        float xhalf = 0.5F * x;
        int i = Float.floatToIntBits(x);
        i = 1597463174 - (i >> 1);
        x = Float.intBitsToFloat(i);
        x *= 1.5F - xhalf * x * x;
        return x;
    }

    public static float log(float fValue) {
        return (float)Math.log((double)fValue);
    }

    public static float log(float value, float base) {
        return (float)(Math.log((double)value) / Math.log((double)base));
    }

    public static float pow(float fBase, float fExponent) {
        return (float)Math.pow((double)fBase, (double)fExponent);
    }

    public static float sqr(float fValue) {
        return fValue * fValue;
    }

    public static float sqrt(float fValue) {
        return (float)Math.sqrt((double)fValue);
    }

    public static float tan(float fValue) {
        return (float)Math.tan((double)fValue);
    }

    public static int sign(int iValue) {
        return iValue > 0?1:(iValue < 0?-1:0);
    }

    public static float sign(float fValue) {
        return Math.signum(fValue);
    }

    public static int counterClockwise(Vector2f p0, Vector2f p1, Vector2f p2) {
        float dx1 = p1.x - p0.x;
        float dy1 = p1.y - p0.y;
        float dx2 = p2.x - p0.x;
        float dy2 = p2.y - p0.y;
        return dx1 * dy2 > dy1 * dx2?1:(dx1 * dy2 < dy1 * dx2?-1:(dx1 * dx2 >= 0.0F && dy1 * dy2 >= 0.0F?(dx1 * dx1 + dy1 * dy1 < dx2 * dx2 + dy2 * dy2?1:0):-1));
    }

    public static int pointInsideTriangle(Vector2f t0, Vector2f t1, Vector2f t2, Vector2f p) {
        int val1 = counterClockwise(t0, t1, p);
        if(val1 == 0) {
            return 1;
        } else {
            int val2 = counterClockwise(t1, t2, p);
            if(val2 == 0) {
                return 1;
            } else if(val2 != val1) {
                return 0;
            } else {
                int val3 = counterClockwise(t2, t0, p);
                return val3 == 0?1:(val3 != val1?0:val3);
            }
        }
    }

    public static Vector3f computeNormal(Vector3f v1, Vector3f v2, Vector3f v3) {
        Vector3f a1 = v1.subtract(v2);
        Vector3f a2 = v3.subtract(v2);
        return a2.crossLocal(a1).normalizeLocal();
    }

    public static float determinant(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33) {
        double det01 = m20 * m31 - m21 * m30;
        double det02 = m20 * m32 - m22 * m30;
        double det03 = m20 * m33 - m23 * m30;
        double det12 = m21 * m32 - m22 * m31;
        double det13 = m21 * m33 - m23 * m31;
        double det23 = m22 * m33 - m23 * m32;
        return (float)(m00 * (m11 * det23 - m12 * det13 + m13 * det12) - m01 * (m10 * det23 - m12 * det03 + m13 * det02) + m02 * (m10 * det13 - m11 * det03 + m13 * det01) - m03 * (m10 * det12 - m11 * det02 + m12 * det01));
    }

    public static float nextRandomFloat() {
        return rand.nextFloat();
    }

    public static int nextRandomInt(int min, int max) {
        return (int)(nextRandomFloat() * (float)(max - min + 1)) + min;
    }

    public static int nextRandomInt() {
        return rand.nextInt();
    }

    public static Vector3f sphericalToCartesian(Vector3f sphereCoords, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.y = sphereCoords.x * sin(sphereCoords.z);
        float a = sphereCoords.x * cos(sphereCoords.z);
        store.x = a * cos(sphereCoords.y);
        store.z = a * sin(sphereCoords.y);
        return store;
    }

    public static Vector3f cartesianToSpherical(Vector3f cartCoords, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        float x = cartCoords.x;
        if(x == 0.0F) {
            x = 1.1920929E-7F;
        }

        store.x = sqrt(x * x + cartCoords.y * cartCoords.y + cartCoords.z * cartCoords.z);
        store.y = atan(cartCoords.z / x);
        if(x < 0.0F) {
            store.y += 3.1415927F;
        }

        store.z = asin(cartCoords.y / store.x);
        return store;
    }

    public static Vector3f sphericalToCartesianZ(Vector3f sphereCoords, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        store.z = sphereCoords.x * sin(sphereCoords.z);
        float a = sphereCoords.x * cos(sphereCoords.z);
        store.x = a * cos(sphereCoords.y);
        store.y = a * sin(sphereCoords.y);
        return store;
    }

    public static Vector3f cartesianZToSpherical(Vector3f cartCoords, Vector3f store) {
        if(store == null) {
            store = new Vector3f();
        }

        float x = cartCoords.x;
        if(x == 0.0F) {
            x = 1.1920929E-7F;
        }

        store.x = sqrt(x * x + cartCoords.y * cartCoords.y + cartCoords.z * cartCoords.z);
        store.z = atan(cartCoords.z / x);
        if(x < 0.0F) {
            store.z += 3.1415927F;
        }

        store.y = asin(cartCoords.y / store.x);
        return store;
    }

    public static float normalize(float val, float min, float max) {
        if(!Float.isInfinite(val) && !Float.isNaN(val)) {
            float range;
            for(range = max - min; val > max; val -= range) {
                ;
            }

            while(val < min) {
                val += range;
            }

            return val;
        } else {
            return 0.0F;
        }
    }

    public static float copysign(float x, float y) {
        return y >= 0.0F && x <= 0.0F?-x:(y < 0.0F && x >= 0.0F?-x:x);
    }

    public static float clamp(float input, float min, float max) {
        return input < min?min:(input > max?max:input);
    }

    public static float saturate(float input) {
        return clamp(input, 0.0F, 1.0F);
    }

    public static float convertHalfToFloat(short half) {
        switch(half) {
            case 0:
                return 0.0F;
            case 31744:
                return (float) (1.0f / 0.0);
            case (short) 32768:
                return -0.0F;
            case (short) 64512:
                return (float) (-1.0F / 0.0);
            default:
                return Float.intBitsToFloat((half & '耀') << 16 | (half & 31744) + 114688 << 13 | (half & 1023) << 13);
        }
    }

    public static short convertFloatToHalf(float flt) {
        if(Float.isNaN(flt)) {
            throw new UnsupportedOperationException("NaN to half conversion not supported!");
        } else if(flt == 1.0F / 0.0) {
            return (short)31744;
        } else if(flt == -1.0F / 0.0) {
            return (short)-1024;
        } else if(flt == 0.0F) {
            return (short)0;
        } else if(flt == -0.0F) {
            return (short)-32768;
        } else if(flt > 65504.0F) {
            return (short)31743;
        } else if(flt < -65504.0F) {
            return (short)-1025;
        } else if(flt > 0.0F && flt < 5.96046E-8F) {
            return (short)1;
        } else if(flt < 0.0F && flt > -5.96046E-8F) {
            return (short)-32767;
        } else {
            int f = Float.floatToIntBits(flt);
            return (short)(f >> 16 & '耀' | (f & 2139095040) - 939524096 >> 13 & 31744 | f >> 13 & 1023);
        }
    }
}
